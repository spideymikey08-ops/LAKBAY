/**
 * Lakbay - Baguio City Tourist Destinations
 * Complete dataset with 20 famous spots and local photography
 */

const sampleDestinations = [
  {
    id: 1,
    name: "Burnham Park",
    category: "Adventure",
    fee: 0,
    rating: 4.8,
    image: "assets/images/burnham-park.jpg",
    location: "Jose Abad Santos Drive, Baguio City",
    description: "The historical green heart of Baguio City designed by master architect Daniel Burnham. Centered around a man-made swan paddleboat lagoon surrounded by century-old pines, roller skating rinks, and lively recreation grounds.",
    activities: [
      "Swan Paddleboat Lagoon Riding",
      "Bicycle Rental & Night Biking",
      "Picnic by the Rose Garden",
      "Outdoor Roller Skating"
    ],
    featured: true
  },
  {
    id: 2,
    name: "Mines View Park",
    category: "Mountains",
    fee: 10,
    rating: 4.7,
    image: "assets/images/mines-view-park.jpeg",
    location: "Mines View Ridge, Baguio City, Benguet",
    description: "A premier tourist observation deck perched on a scenic ridge overlooking the historic abandoned gold and copper mines of Itogon, Benguet and the majestic Cordillera mountain ranges.",
    activities: [
      "Cordillera Mountain Overlook",
      "Traditional Igorot Attire Photo",
      "Silvercraft & Souvenir Shopping",
      "Warm Strawberry Taho Tasting"
    ],
    featured: true
  },
  {
    id: 3,
    name: "Wright Park",
    category: "Adventure",
    fee: 0,
    rating: 4.6,
    image: "assets/images/wright-park.jpg",
    location: "Romulo Drive, Baguio City",
    description: "Celebrated for its 100-meter shallow elongated pond named the 'Pool of Pines', lined with weeping willows and towering pines leading straight down to the horseback riding ring.",
    activities: [
      "Horseback Riding with Local Pony Boys",
      "Pool of Pines Walking Promenade",
      "Pine Tree Landscape Photography",
      "Parkside Souvenir Stalls Browsing"
    ],
    featured: true
  },
  {
    id: 4,
    name: "The Mansion",
    category: "Historical",
    fee: 0,
    rating: 4.6,
    image: "assets/images/the-mansion.jpeg",
    location: "Romulo Drive, Baguio City",
    description: "Built in 1908 as the summer residence of the US Governor-General and now the official summer palace of the Philippine President. Famed for its grand ornate Spanish iron main gate patterned after Buckingham Palace.",
    activities: [
      "Presidential Palace Gate Sightseeing",
      "Manicured Lawn & Garden Viewing",
      "Architectural Heritage Photography",
      "Historical Plaque Exploration"
    ],
    featured: false
  },
  {
    id: 5,
    name: "Baguio Botanical Garden",
    category: "Historical",
    fee: 10,
    rating: 4.7,
    image: "assets/images/botanical-garden.jpeg",
    location: "37 Leonard Wood Road, Baguio City",
    description: "Also known as Centennial Park, showcasing indigenous Cordilleran tribal sculptures, peaceful pocket gardens, diverse pine flora, and an authentic subterranean WWII Japanese military tunnel.",
    activities: [
      "WWII Japanese Peace Tunnel Exploration",
      "Cordillera Tribal Village Sculptures",
      "Pine Flower Nursery Walk",
      "Friendship Gardens Photo-Op"
    ],
    featured: false
  },
  {
    id: 6,
    name: "Camp John Hay",
    category: "Adventure",
    fee: 80,
    rating: 4.9,
    image: "assets/images/camp-john-hay.jpg",
    location: "Loakan Road, Camp John Hay, Baguio City",
    description: "A former US military recreational air station transformed into a premier pine-scented eco-resort. Features serene forest hiking trails, treetop suspension bridges, historical cottages, and coffee patios.",
    activities: [
      "Yellow Trail Forest Pine Hike",
      "Treetop Canopy Adventure",
      "Bell Amphitheater Family Picnic",
      "Historical Core & Secret Garden Tour"
    ],
    featured: false
  },
  {
    id: 7,
    name: "Good Shepherd Convent",
    category: "Historical",
    fee: 0,
    rating: 4.8,
    image: "assets/images/good-shepherd.png",
    location: "Gibraltar Road, Baguio City",
    description: "Operated by the Religious of the Good Shepherd sisters to support youth scholarships. Nationally famed for authentic Mountain Province strawberry jam, signature purple ube jam, peanut brittle, and scenic mountain view deck.",
    activities: [
      "Famous Mountain Ube & Strawberry Jam Buying",
      "Scenic Valley View Deck Sightseeing",
      "Alfajores & Baked Delicacies Tasting",
      "Quiet Convent Grounds Walk"
    ],
    featured: false
  },
  {
    id: 8,
    name: "Igorot Stone Kingdom",
    category: "Historical",
    fee: 100,
    rating: 4.5,
    image: "assets/images/igorot-stone-kingdom.jpeg",
    location: "Long-Long Benguet Road, Baguio City",
    description: "A grand cultural monument constructed using indigenous Riprap interlocking stonework. Showcases the architectural heritage, folklore, and legendary kings of the Cordillera indigenous tribes.",
    activities: [
      "Stone Castle Tower Climbing",
      "Igorot Folklore & Heritage Tour",
      "Panoramic Mountain Valley Photo Ops",
      "Traditional Attire Rental"
    ],
    featured: false
  },
  {
    id: 9,
    name: "Mirador Heritage and Eco Park",
    category: "Mountains",
    fee: 100,
    rating: 4.8,
    image: "assets/images/mirador-park.jpeg",
    location: "Mirador Hill, Baguio City",
    description: "A 5-hectare eco-spirituality park situated atop Mirador Hill. Renowned for its iconic Japanese Torii Gate facing the mountain sunset, Arashiyama-inspired bamboo grove, and historical peace memorial bell.",
    activities: [
      "Torii Gate Mountain Horizon Sunset Photo",
      "Arashiyama Bamboo Grove Walk",
      "Peace Memorial Bell Ringing",
      "Panoramic Cityscape Overlook"
    ],
    featured: false
  },
  {
    id: 10,
    name: "Tam-Awan Village",
    category: "Historical",
    fee: 60,
    rating: 4.5,
    image: "assets/images/tam-awan-village.jpeg",
    location: "366-C Pinsao Proper, Baguio City",
    description: "An artist colony and living eco-cultural sanctuary dedicated to preserving Cordilleran culture. Features authentic reconstructed native Ifugao and Kalinga huts, art galleries, and cultural workshops.",
    activities: [
      "Authentic Ifugao & Kalinga Huts Tour",
      "Cordillera Art Exhibit Viewing",
      "Portrait Sketching by Local Artists",
      "Organic Benguet Coffee Tasting"
    ],
    featured: false
  },
  {
    id: 11,
    name: "BenCab Museum",
    category: "Historical",
    fee: 200,
    rating: 4.9,
    image: "assets/images/bencab-museum.jpeg",
    location: "Km. 6 Asin Road, Tuba, Metro Baguio",
    description: "Houses the personal art collections and masterpiece works of Philippine National Artist Benedicto Cabrera (BenCab), along with indigenous Cordillera wooden relics, contemporary galleries, and an eco-trail.",
    activities: [
      "National Artist Masterpieces Gallery Tour",
      "Indigenous Cordillera Relics & Bulul Statues",
      "Cafe Sabel Organic Dining",
      "Aviary & Duck Pond Eco-Trail Walk"
    ],
    featured: false
  },
  {
    id: 12,
    name: "Old Diplomat Hotel",
    category: "Historical",
    fee: 10,
    rating: 4.4,
    image: "assets/images/diplomat-hotel.jpeg",
    location: "Dominican Hill, Baguio City",
    description: "Originally built in 1913 as a retreat house and seminary for the Dominican Order, later converted into a hotel. Now preserved as a historic cultural landmark and public park atop Dominican Hill.",
    activities: [
      "Historic Stone Ruins Photography",
      "Dominican Hill Skyline Overlook",
      "Heritage Architecture Walk",
      "Heritage Park Breezeway Stroll"
    ],
    featured: false
  },
  {
    id: 13,
    name: "Lourdes Grotto",
    category: "Historical",
    fee: 0,
    rating: 4.6,
    image: "assets/images/lourdes-grotto.jpeg",
    location: "Dominican Hill Road, Baguio City",
    description: "A cherished Catholic pilgrimage site constructed atop Mirador Hill, featuring a 252-step staircase leading to an open-air grotto and sanctuary enshrining the image of Our Lady of Lourdes.",
    activities: [
      "252-Step Stair Climbing Challenge",
      "Pilgrimage Candle Lighting & Prayer",
      "Panoramic Baguio Cityscape Viewing",
      "Hilltop Meditation"
    ],
    featured: false
  },
  {
    id: 14,
    name: "Lion's Head",
    category: "Mountains",
    fee: 0,
    rating: 4.3,
    image: "assets/images/lions-head.jpeg",
    location: "Kennon Road, Camp 6, Baguio City",
    description: "A monumental 40-foot limestone lion sculpture carved in 1972 by Lions Club Baguio. A beloved historic landmark welcoming road travelers ascending into Baguio via the winding scenic Kennon Road.",
    activities: [
      "Iconic Welcome Milestone Photo-Op",
      "Kennon Road Mountain Viewing",
      "Baguio Souvenir & Snack Stall Browsing",
      "Mountain Gorge Scenic Stop"
    ],
    featured: false
  },
  {
    id: 15,
    name: "Baguio Night Market",
    category: "Adventure",
    fee: 0,
    rating: 4.7,
    image: "assets/images/night-market.jpeg",
    location: "Harrison Road, Burnham Park perimeter, Baguio City",
    description: "Every night starting at 9:00 PM, a stretch of Harrison Road closes to vehicular traffic and transforms into a lively open-air market packed with vintage apparel, winter jackets, pine souvenirs, and piping-hot street delicacies.",
    activities: [
      "Thrift Ukay-Ukay Jacket Bargain Hunting",
      "Steaming Street Food Tasting (Balut & Kwek-kwek)",
      "Local Handcrafted Souvenir Shopping",
      "Nighttime Baguio Street Vibe Stroll"
    ],
    featured: false
  },
  {
    id: 16,
    name: "Baguio Cathedral",
    category: "Historical",
    fee: 0,
    rating: 4.7,
    image: "assets/images/baguio-cathedral.png",
    location: "Cathedral Loop, Mount Mary, Session Road, Baguio City",
    description: "Dedicated to Our Lady of the Atonement, this twin-spire rose-colored neo-Gothic cathedral commands the skyline from Mount Mary Hill. It famously served as an evacuation center during World War II.",
    activities: [
      "Rose-Pink Twin Spire Architecture Viewing",
      "Quiet Prayer & Catholic Mass Attendance",
      "Scenic Overlook of Downtown Session Road",
      "Stained Glass Window Art Appreciation"
    ],
    featured: false
  },
  {
    id: 17,
    name: "Session Road",
    category: "Adventure",
    fee: 0,
    rating: 4.6,
    image: "assets/images/session-road.jpeg",
    location: "Session Road, Downtown Baguio City",
    description: "The bustling commercial and cultural backbone of Baguio, lined with historic art deco edifices, homegrown bakeries, craft breweries, boutique bookshops, and car-free pedestrian Sundays with street chalk art.",
    activities: [
      "Session Road Heritage Walk",
      "Cozy Mountain Cafe Hopping",
      "Baguio Craft Beer & Dinner",
      "Sunday Car-Free Street Art & Music"
    ],
    featured: false
  },
  {
    id: 18,
    name: "Philippine Military Academy (PMA)",
    category: "Historical",
    fee: 20,
    rating: 4.8,
    image: "assets/images/pma.jpeg",
    location: "Fort Gregorio del Pilar, Loakan Road, Baguio City",
    description: "The premier military training academy for commissioned officers of the Armed Forces of the Philippines, situated on a sprawling 373-hectare scenic reservation with military relics, pine trees, and cadet drills.",
    activities: [
      "PMA Military Museum & Hall of Fame Tour",
      "Relics Point Tanks, Artillery & Fighter Jets",
      "Cadet Silent Drill Watching (Saturdays)",
      "Manicured Pine Campus Walking"
    ],
    featured: false
  },
  {
    id: 19,
    name: "Sky Ranch Baguio",
    category: "Adventure",
    fee: 100,
    rating: 4.5,
    image: "assets/images/sky-ranch.jpeg",
    location: "Luneta Hill, Upper Session Road, Baguio City",
    description: "A fun-filled outdoor amusement theme park situated on Luneta Hill beside SM City Baguio. Known for the Baguio Eye giant Ferris wheel that lifts riders above the city for breathtaking mountain skyline vistas.",
    activities: [
      "Baguio Eye Giant Ferris Wheel Ride",
      "Flying Fiesta Swing & Double Decker Carousel",
      "Sunset Mountain Skyline Views",
      "Carnival Games & Family Fun"
    ],
    featured: false
  },
  {
    id: 20,
    name: "Bell Church",
    category: "Historical",
    fee: 0,
    rating: 4.6,
    image: "assets/images/bell-church.jpeg",
    location: "KM 3, La Trinidad - Baguio Border, Benguet",
    description: "An ornate Chinese Taoist and Buddhist temple complex situated against a verdant pine hillside. Features multi-tiered green and red pagodas, dragon arches, koi ponds, and traditional Chinese garden courtyards.",
    activities: [
      "Traditional Chinese Pagoda Tour",
      "Dragon Gate & Archway Photography",
      "Koi Pond & Lotus Fountain Viewing",
      "Peaceful Hillside Garden Exploration"
    ],
    featured: false
  }
];
