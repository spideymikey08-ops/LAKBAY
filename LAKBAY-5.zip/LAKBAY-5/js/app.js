/**
 * ==============================================================================
 * Lakbay - Baguio City Travel Destination Explorer & Itinerary Planner
 * ==============================================================================
 */

// Application State Object
const appState = {
  currentSection: 'home',
  activeCategory: 'All',
  priceFilter: 'all', // 'all' | 'free' | '50' | '100'
  searchQuery: '',
  sortOrder: 'name-asc',
  favorites: [], // Array of destination IDs: [1, 3, 5]
  itinerary: [], // Array of stop objects: [{ id, destinationId, destinationName, date, time, activity, fee }]
  budget: {
    days: 1,
    travelers: 1,
    transportation: 0,
    accommodation: 0,
    food: 0,
    activities: 0,
    total: 0,
    perPerson: 0
  },
  modalDestinationId: null,
  editingStopId: null,
  lastDeletedStop: null // For undo delete
};

// LocalStorage Keys
const STORAGE_KEYS = {
  FAVORITES: 'lakbay_favorites',
  ITINERARY: 'lakbay_itinerary',
  BUDGET: 'lakbay_budget'
};

/* ==========================================================================
   INITIALIZATION & DATA RESTORATION (DOMContentLoaded)
   ========================================================================== */
function init() {
  // 1. Restore persistent user data from localStorage
  loadData();

  // 2. Setup Navigation and Section Switching Listeners
  setupNavigation();

  // 3. Populate Itinerary Destination Dropdown
  populateDestinationSelect();

  // 4. Configure Minimum Dates (Prevents past dates)
  setupDateConstraints();

  // 5. Render Initial Views
  renderHomeStats();
  renderHomeProgress();
  renderFeaturedDestinations();
  renderExploreGallery();
  renderFavoritesList();
  renderItineraryList();
  restoreBudgetInputs();
  calculateBudget(false); // Don't re-save during init

  // 6. Setup Explore Search, Filter, Price, and Sort Listeners
  setupExploreControls();

  // 7. Setup Modal and Confirmation Dialog Listeners
  setupModalControls();
  setupConfirmDialog();
  setupQuickAddPopover();

  // 8. Setup Itinerary Form Listeners
  setupItineraryControls();
  setupDestinationDropdown();

  // 9. Setup Budget Calculator Listeners
  setupBudgetControls();

  // 10. Setup Summary Actions
  setupSummaryControls();

  // Check URL Hash for deep linking (e.g. #summary or #explore)
  handleInitialHash();
}

/* ==========================================================================
   LOCALSTORAGE PERSISTENCE
   ========================================================================== */
function loadData() {
  try {
    const savedFavs = localStorage.getItem(STORAGE_KEYS.FAVORITES);
    if (savedFavs) {
      appState.favorites = JSON.parse(savedFavs);
    }

    const savedItinerary = localStorage.getItem(STORAGE_KEYS.ITINERARY);
    if (savedItinerary) {
      appState.itinerary = JSON.parse(savedItinerary);
    }

    const savedBudget = localStorage.getItem(STORAGE_KEYS.BUDGET);
    if (savedBudget) {
      appState.budget = { ...appState.budget, ...JSON.parse(savedBudget) };
    }
  } catch (err) {
    console.error('[Lakbay] Error loading saved data:', err);
  }
}

function saveData() {
  try {
    localStorage.setItem(STORAGE_KEYS.FAVORITES, JSON.stringify(appState.favorites));
    localStorage.setItem(STORAGE_KEYS.ITINERARY, JSON.stringify(appState.itinerary));
    localStorage.setItem(STORAGE_KEYS.BUDGET, JSON.stringify(appState.budget));
    renderHomeStats();
    renderHomeProgress();
    updateFavoritesBadge();
  } catch (err) {
    console.error('[Lakbay] Error saving data:', err);
  }
}

/* ==========================================================================
   DATE HELPERS (No past dates)
   ========================================================================== */
function getTodayDateString() {
  const today = new Date();
  const year = today.getFullYear();
  const month = String(today.getMonth() + 1).padStart(2, '0');
  const day = String(today.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function setupDateConstraints() {
  const todayStr = getTodayDateString();
  const dateInput = document.getElementById('itinerary-date');
  const quickDateInput = document.getElementById('quick-add-date');

  if (dateInput) {
    dateInput.min = todayStr;
    if (!dateInput.value) {
      dateInput.value = todayStr;
    }
  }

  if (quickDateInput) {
    quickDateInput.min = todayStr;
    if (!quickDateInput.value) {
      quickDateInput.value = todayStr;
    }
  }
}

/* ==========================================================================
   NAVIGATION (showSection)
   ========================================================================== */
function showSection(sectionName) {
  const targetSectionId = `section-${sectionName}`;
  const targetElement = document.getElementById(targetSectionId);

  if (!targetElement) {
    console.warn(`[Lakbay] Section "${sectionName}" not found.`);
    return;
  }

  // Hide all screens
  document.querySelectorAll('.app-screen').forEach(screen => {
    screen.classList.remove('active');
  });

  // Activate selected screen
  targetElement.classList.add('active');
  appState.currentSection = sectionName;

  // Update Navigation menu active styles
  document.querySelectorAll('.nav-item').forEach(btn => {
    if (btn.getAttribute('data-section') === sectionName) {
      btn.classList.add('active');
    } else {
      btn.classList.remove('active');
    }
  });

  // Close mobile nav menu if open
  const navLinks = document.getElementById('nav-links');
  if (navLinks && navLinks.classList.contains('open')) {
    navLinks.classList.remove('open');
  }

  // Smooth scroll to top of page
  window.scrollTo({ top: 0, behavior: 'smooth' });

  // Update browser address bar hash without reloading
  if (window.location.hash !== `#${sectionName}`) {
    history.replaceState(null, '', `#${sectionName}`);
  }

  // Refresh section-specific data on arrival
  if (sectionName === 'favorites') {
    renderFavoritesList();
  } else if (sectionName === 'itinerary') {
    renderItineraryList();
  } else if (sectionName === 'home') {
    renderHomeStats();
    renderHomeProgress();
  } else if (sectionName === 'explore') {
    renderExploreGallery();
  } else if (sectionName === 'summary') {
    // FIX: Automatically build summary whenever navigated to by link or hash
    buildSummary();
  }
}

function setupNavigation() {
  const navContainer = document.getElementById('main-nav');
  if (navContainer) {
    navContainer.addEventListener('click', (e) => {
      const navBtn = e.target.closest('[data-section]');
      if (navBtn) {
        e.preventDefault();
        const section = navBtn.getAttribute('data-section');
        showSection(section);
      }
    });
  }

  // Page clicks with data-section (e.g. Hero buttons, quick-links)
  document.addEventListener('click', (e) => {
    const trigger = e.target.closest('[data-section]');
    if (trigger && !trigger.closest('#main-nav')) {
      e.preventDefault();
      const section = trigger.getAttribute('data-section');
      showSection(section);
    }
  });

  // Mobile hamburger toggle
  const mobileToggle = document.getElementById('mobile-toggle');
  const navLinks = document.getElementById('nav-links');
  if (mobileToggle && navLinks) {
    mobileToggle.addEventListener('click', () => {
      navLinks.classList.toggle('open');
    });
  }
}

function handleInitialHash() {
  const hash = window.location.hash.replace('#', '');
  const validSections = ['home', 'explore', 'itinerary', 'favorites', 'budget', 'summary'];
  if (validSections.includes(hash)) {
    showSection(hash);
  } else {
    showSection('home');
  }
}

/* ==========================================================================
   SCREEN 1: HOME DASHBOARD & PROGRESS PANEL
   ========================================================================== */
function renderHomeStats() {
  const favCountEl = document.getElementById('home-stat-favorites');
  const stopsCountEl = document.getElementById('home-stat-stops');
  const budgetEl = document.getElementById('home-stat-budget');

  if (favCountEl) favCountEl.textContent = appState.favorites.length;
  if (stopsCountEl) stopsCountEl.textContent = appState.itinerary.length;
  if (budgetEl) {
    budgetEl.textContent = formatCurrency(appState.budget.total || 0);
  }

  updateFavoritesBadge();
}

function renderHomeProgress() {
  const favCount = appState.favorites.length;
  const stopsCount = appState.itinerary.length;
  const hasBudget = (appState.budget.total || 0) > 0;

  let completedSteps = 0;
  if (favCount > 0) completedSteps++;
  if (stopsCount > 0) completedSteps++;
  if (hasBudget) completedSteps++;

  const percentage = Math.round((completedSteps / 3) * 100);

  const percentEl = document.getElementById('hero-progress-percent');
  const barEl = document.getElementById('hero-progress-bar');
  if (percentEl) percentEl.textContent = `${percentage}%`;
  if (barEl) barEl.style.width = `${percentage}%`;

  // Step 1: Favorites
  const stepFavs = document.getElementById('step-favs');
  const stepFavsStatus = document.getElementById('step-favs-status');
  if (stepFavs) {
    stepFavs.classList.toggle('is-complete', favCount > 0);
    if (stepFavsStatus) {
      stepFavsStatus.textContent = favCount === 1 ? '1 place saved' : `${favCount} places saved`;
    }
  }

  // Step 2: Stops
  const stepStops = document.getElementById('step-stops');
  const stepStopsStatus = document.getElementById('step-stops-status');
  if (stepStops) {
    stepStops.classList.toggle('is-complete', stopsCount > 0);
    if (stepStopsStatus) {
      stepStopsStatus.textContent = stopsCount === 1 ? '1 stop scheduled' : `${stopsCount} stops scheduled`;
    }
  }

  // Step 3: Budget
  const stepBudget = document.getElementById('step-budget');
  const stepBudgetStatus = document.getElementById('step-budget-status');
  if (stepBudget) {
    stepBudget.classList.toggle('is-complete', hasBudget);
    if (stepBudgetStatus) {
      stepBudgetStatus.textContent = hasBudget ? `${formatCurrency(appState.budget.total)} total` : 'Not estimated yet';
    }
  }

  // Dynamic "Next Step" Prompt Box
  const nextStepText = document.getElementById('hero-next-step-text');
  const nextStepBtn = document.getElementById('hero-next-step-btn');
  if (nextStepText && nextStepBtn) {
    if (favCount === 0) {
      nextStepText.textContent = 'Explore destinations and save your favorite spots.';
      nextStepBtn.textContent = 'Browse places →';
      nextStepBtn.setAttribute('data-section', 'explore');
    } else if (stopsCount === 0) {
      nextStepText.textContent = 'Schedule your saved places into daily itinerary stops.';
      nextStepBtn.textContent = 'Schedule stops →';
      nextStepBtn.setAttribute('data-section', 'itinerary');
    } else if (!hasBudget) {
      nextStepText.textContent = 'Estimate travel costs in the Budget calculator.';
      nextStepBtn.textContent = 'Estimate budget →';
      nextStepBtn.setAttribute('data-section', 'budget');
    } else {
      nextStepText.textContent = 'Trip plan ready! Review and print your summary report.';
      nextStepBtn.textContent = 'View summary →';
      nextStepBtn.setAttribute('data-section', 'summary');
    }
  }
}

function updateFavoritesBadge() {
  const badge = document.getElementById('nav-fav-badge');
  const favHeader = document.getElementById('favorites-count-header');
  const count = appState.favorites.length;
  if (badge) badge.textContent = count;
  if (favHeader) favHeader.textContent = count;
}

function renderFeaturedDestinations() {
  const grid = document.getElementById('home-featured-grid');
  if (!grid) return;

  const featured = sampleDestinations.filter(d => d.featured).slice(0, 3);
  grid.innerHTML = featured.map(dest => createDestinationCardHTML(dest, true)).join('');
}

/* ==========================================================================
   SCREEN 2: EXPLORE GALLERY & FILTERS
   ========================================================================== */
function setupExploreControls() {
  // Search input
  const searchInput = document.getElementById('search-input');
  const searchClearBtn = document.getElementById('search-clear-btn');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      appState.searchQuery = e.target.value.trim().toLowerCase();
      if (searchClearBtn) {
        searchClearBtn.style.display = appState.searchQuery ? 'block' : 'none';
      }
      renderExploreGallery();
    });
  }

  if (searchClearBtn) {
    searchClearBtn.addEventListener('click', () => {
      if (searchInput) {
        searchInput.value = '';
        searchInput.focus();
      }
      appState.searchQuery = '';
      searchClearBtn.style.display = 'none';
      renderExploreGallery();
    });
  }

  // Category chips
  const chipsContainer = document.getElementById('category-chips-container');
  if (chipsContainer) {
    chipsContainer.addEventListener('click', (e) => {
      const chip = e.target.closest('.chip');
      if (chip) {
        chipsContainer.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
        appState.activeCategory = chip.getAttribute('data-category');
        renderExploreGallery();
      }
    });
  }

  // Price filters (All, Free Only, Under 50, Under 100)
  const priceContainer = document.getElementById('price-filters-container');
  if (priceContainer) {
    priceContainer.addEventListener('click', (e) => {
      const btn = e.target.closest('.price-chip');
      if (btn) {
        priceContainer.querySelectorAll('.price-chip').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        appState.priceFilter = btn.getAttribute('data-price');
        renderExploreGallery();
      }
    });
  }

  // Sort dropdown
  const sortDropdown = document.getElementById('sort-dropdown');
  if (sortDropdown) {
    sortDropdown.addEventListener('change', (e) => {
      appState.sortOrder = e.target.value;
      renderExploreGallery();
    });
  }

  // Clear filters helper buttons
  const clearBtn = document.getElementById('btn-clear-explore-filters');
  const resetBtn = document.getElementById('btn-reset-explore-filters');
  const resetAllFilters = () => {
    if (searchInput) searchInput.value = '';
    if (searchClearBtn) searchClearBtn.style.display = 'none';
    appState.searchQuery = '';
    appState.activeCategory = 'All';
    appState.priceFilter = 'all';
    appState.sortOrder = 'name-asc';

    if (chipsContainer) {
      chipsContainer.querySelectorAll('.chip').forEach(c => {
        c.classList.toggle('active', c.getAttribute('data-category') === 'All');
      });
    }

    if (priceContainer) {
      priceContainer.querySelectorAll('.price-chip').forEach(b => {
        b.classList.toggle('active', b.getAttribute('data-price') === 'all');
      });
    }

    if (sortDropdown) sortDropdown.value = 'name-asc';
    renderExploreGallery();
  };

  if (clearBtn) clearBtn.addEventListener('click', resetAllFilters);
  if (resetBtn) resetBtn.addEventListener('click', resetAllFilters);

  // Gallery Card Event Delegation
  const exploreGrid = document.getElementById('explore-cards-grid');
  if (exploreGrid) {
    exploreGrid.addEventListener('click', handleCardActions);
  }

  // Home Featured Grid Event Delegation
  const homeGrid = document.getElementById('home-featured-grid');
  if (homeGrid) {
    homeGrid.addEventListener('click', handleCardActions);
  }
}

function handleCardActions(e) {
  // 1. Favorite Heart
  const heartBtn = e.target.closest('.card-heart-btn');
  if (heartBtn) {
    e.stopPropagation();
    const id = parseInt(heartBtn.getAttribute('data-id'), 10);
    toggleFavorite(id);
    return;
  }

  // 2. Details Modal
  const detailsBtn = e.target.closest('.btn-show-details');
  if (detailsBtn) {
    e.stopPropagation();
    const id = parseInt(detailsBtn.getAttribute('data-id'), 10);
    showDetails(id);
    return;
  }

  // 3. Quick-Add Popover for "+ Itinerary" (Keeps user on the page!)
  const quickItineraryBtn = e.target.closest('.btn-quick-itinerary');
  if (quickItineraryBtn) {
    e.stopPropagation();
    const id = parseInt(quickItineraryBtn.getAttribute('data-id'), 10);
    openQuickAddPopover(id, quickItineraryBtn);
  }
}

function renderExploreGallery() {
  const grid = document.getElementById('explore-cards-grid');
  const emptyState = document.getElementById('explore-empty-state');
  const countText = document.getElementById('results-count-text');
  if (!grid) return;

  // 1. Category Filter
  let list = sampleDestinations.filter(item => {
    if (appState.activeCategory === 'All') return true;
    return item.category.toLowerCase() === appState.activeCategory.toLowerCase();
  });

  // 2. Price Filter
  if (appState.priceFilter === 'free') {
    list = list.filter(item => item.fee === 0);
  } else if (appState.priceFilter === '50') {
    list = list.filter(item => item.fee <= 50);
  } else if (appState.priceFilter === '100') {
    list = list.filter(item => item.fee <= 100);
  }

  // 3. Search Query Filter
  if (appState.searchQuery) {
    const q = appState.searchQuery;
    list = list.filter(item => {
      const matchName = item.name.toLowerCase().includes(q);
      const matchLocation = item.location.toLowerCase().includes(q);
      const matchDesc = item.description.toLowerCase().includes(q);
      const matchActivities = item.activities.some(act => act.toLowerCase().includes(q));
      return matchName || matchLocation || matchDesc || matchActivities;
    });
  }

  // 4. Sort
  list.sort((a, b) => {
    if (appState.sortOrder === 'name-asc') {
      return a.name.localeCompare(b.name);
    } else if (appState.sortOrder === 'name-desc') {
      return b.name.localeCompare(a.name);
    } else if (appState.sortOrder === 'rating-desc') {
      return b.rating - a.rating;
    } else if (appState.sortOrder === 'fee-asc') {
      return a.fee - b.fee;
    } else if (appState.sortOrder === 'fee-desc') {
      return b.fee - a.fee;
    }
    return 0;
  });

  // 5. Results Counter
  if (countText) {
    countText.textContent = `Showing ${list.length} destination${list.length === 1 ? '' : 's'}`;
  }

  // 6. Output
  if (list.length === 0) {
    grid.innerHTML = '';
    if (emptyState) emptyState.style.display = 'block';
  } else {
    if (emptyState) emptyState.style.display = 'none';
    grid.innerHTML = list.map(dest => createDestinationCardHTML(dest)).join('');
  }
}

/**
 * Creates destination card HTML with rating, category, fee, planned status, and heart toggle.
 */
function createDestinationCardHTML(dest, isFeatured = false) {
  const isFav = appState.favorites.includes(dest.id);
  const isPlanned = appState.itinerary.some(s => s.destinationId === dest.id);

  // Category badge slug
  const categorySlug = dest.category.toLowerCase().replace(/[^a-z0-9]+/g, '-');
  const badgeClass = `badge-${categorySlug}`;

  // Clean label spacing: "Free Entry" or "₱10"
  const feeText = dest.fee === 0 ? 'Free Entry' : `&#8369;${dest.fee}`;

  return `
    <article class="destination-card" data-id="${dest.id}">
      <div class="card-image-wrap">
        <img 
          src="${dest.image}" 
          alt="${dest.name}" 
          class="card-img" 
          loading="lazy"
          onerror="this.src='assets/images/burnham-park.jpg'"
        >
        ${isPlanned ? `<span class="card-planned-indicator"><svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"></polyline></svg> In itinerary</span>` : ''}
        <button 
          type="button" 
          class="card-heart-btn ${isFav ? 'active' : ''}" 
          data-id="${dest.id}" 
          aria-label="${isFav ? 'Remove from favorites' : 'Add to favorites'}"
          title="${isFav ? 'Remove from favorites' : 'Add to favorites'}"
        >
          <svg viewBox="0 0 24 24" width="18" height="18" fill="${isFav ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2">
            <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
          </svg>
        </button>
      </div>
      <div class="card-content">
        <div class="card-meta-row">
          <div class="card-meta-badges">
            <span class="badge ${badgeClass}">${dest.category}</span>
            <span class="badge rating-badge">
              <svg viewBox="0 0 24 24" width="12" height="12" fill="#f59e0b" stroke="#f59e0b"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
              ${dest.rating}
            </span>
          </div>
          <span class="card-fee-text ${dest.fee === 0 ? '' : 'card-fee-highlight'}">${feeText}</span>
        </div>
        <h3 class="card-title">${dest.name}</h3>
        <p class="card-location">
          <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
          ${dest.location}
        </p>
        <div class="card-actions">
          <button type="button" class="btn btn-outline btn-sm btn-show-details" data-id="${dest.id}">
            Details
          </button>
          <button type="button" class="btn btn-primary btn-sm btn-quick-itinerary ${isPlanned ? 'btn-outline' : ''}" data-id="${dest.id}">
            ${isPlanned ? 'Added' : '+ Itinerary'}
          </button>
        </div>
      </div>
    </article>
  `;
}

/* ==========================================================================
   SCREEN 3: DESTINATION DETAILS MODAL (Scrollable Body & Pinned Footer)
   ========================================================================== */
let modalLastFocusedElement = null;

function setupModalControls() {
  const modal = document.getElementById('destination-modal');
  const closeBtn = document.getElementById('modal-close-btn');
  const backdrop = document.getElementById('modal-backdrop');
  const favBtn = document.getElementById('modal-fav-btn');
  const itineraryBtn = document.getElementById('modal-itinerary-btn');

  if (closeBtn) closeBtn.addEventListener('click', closeDetails);
  if (backdrop) backdrop.addEventListener('click', closeDetails);

  // Esc key and focus trap
  document.addEventListener('keydown', (e) => {
    if (modal && modal.style.display !== 'none') {
      if (e.key === 'Escape' || e.key === 'Esc') {
        closeDetails();
        return;
      }

      // Accessible Focus Trap inside modal
      if (e.key === 'Tab') {
        trapFocusInDialog(modal, e);
      }
    }
  });

  // Modal Favorite Toggle
  if (favBtn) {
    favBtn.addEventListener('click', () => {
      if (appState.modalDestinationId !== null) {
        toggleFavorite(appState.modalDestinationId);
        updateModalFavoriteButtonState(appState.modalDestinationId);
      }
    });
  }

  // Modal Add to Itinerary
  if (itineraryBtn) {
    itineraryBtn.addEventListener('click', () => {
      if (appState.modalDestinationId !== null) {
        const destId = appState.modalDestinationId;
        closeDetails();
        prefillItineraryForm(destId);
      }
    });
  }
}

function trapFocusInDialog(dialogElement, e) {
  const focusable = dialogElement.querySelectorAll(
    'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
  );
  if (focusable.length === 0) return;

  const firstFocusable = focusable[0];
  const lastFocusable = focusable[focusable.length - 1];

  if (e.shiftKey) {
    if (document.activeElement === firstFocusable) {
      lastFocusable.focus();
      e.preventDefault();
    }
  } else {
    if (document.activeElement === lastFocusable) {
      firstFocusable.focus();
      e.preventDefault();
    }
  }
}

function showDetails(id) {
  const dest = sampleDestinations.find(d => d.id === id);
  if (!dest) return;

  modalLastFocusedElement = document.activeElement;
  appState.modalDestinationId = id;
  const modal = document.getElementById('destination-modal');

  // Fields
  const img = document.getElementById('modal-img');
  const title = document.getElementById('modal-title');
  const categoryBadge = document.getElementById('modal-category');
  const feeBadge = document.getElementById('modal-fee');
  const ratingText = document.getElementById('modal-rating-text');
  const locText = document.getElementById('modal-location-text');
  const desc = document.getElementById('modal-description');
  const activitiesWrap = document.getElementById('modal-activities');

  if (img) {
    img.src = dest.image;
    img.alt = dest.name;
  }
  if (title) title.textContent = dest.name;
  if (locText) locText.textContent = dest.location;
  if (desc) desc.textContent = dest.description;
  if (ratingText) ratingText.textContent = dest.rating;

  if (categoryBadge) {
    categoryBadge.textContent = dest.category;
    const categorySlug = dest.category.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    categoryBadge.className = `badge badge-${categorySlug}`;
  }

  if (feeBadge) {
    feeBadge.textContent = dest.fee === 0 ? 'Free Entry' : `Entrance Fee: ₱${dest.fee}`;
  }

  if (activitiesWrap) {
    activitiesWrap.innerHTML = dest.activities
      .map(act => `<span class="activity-tag">${escapeHTML(act)}</span>`)
      .join('');
  }

  updateModalFavoriteButtonState(id);

  if (modal) {
    modal.style.display = 'flex';
    modal.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';

    // Set focus inside modal
    const closeBtn = document.getElementById('modal-close-btn');
    if (closeBtn) closeBtn.focus();
  }
}

function closeDetails() {
  const modal = document.getElementById('destination-modal');
  if (modal) {
    modal.style.display = 'none';
    modal.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  }
  appState.modalDestinationId = null;

  if (modalLastFocusedElement && typeof modalLastFocusedElement.focus === 'function') {
    modalLastFocusedElement.focus();
  }
}

function updateModalFavoriteButtonState(id) {
  const favBtn = document.getElementById('modal-fav-btn');
  const favBtnText = document.getElementById('modal-fav-btn-text');
  if (!favBtn || !favBtnText) return;

  const isFav = appState.favorites.includes(id);
  const heartSvg = favBtn.querySelector('svg');

  if (isFav) {
    favBtnText.textContent = 'Remove favorite';
    favBtn.classList.add('btn-outline-danger');
    favBtn.classList.remove('btn-outline');
    if (heartSvg) {
      heartSvg.setAttribute('fill', '#ef4444');
      heartSvg.setAttribute('stroke', '#ef4444');
    }
  } else {
    favBtnText.textContent = 'Save to favorites';
    favBtn.classList.remove('btn-outline-danger');
    favBtn.classList.add('btn-outline');
    if (heartSvg) {
      heartSvg.setAttribute('fill', 'none');
      heartSvg.setAttribute('stroke', 'currentColor');
    }
  }
}

/* ==========================================================================
   QUICK-ADD POPOVER FOR "+ ITINERARY" (Keeps user on Explore)
   ========================================================================== */
function setupQuickAddPopover() {
  const popover = document.getElementById('quick-add-popover');
  const closeBtn = document.getElementById('quick-add-close');
  const cancelBtn = document.getElementById('quick-add-cancel');
  const form = document.getElementById('quick-add-form');

  if (closeBtn) closeBtn.addEventListener('click', closeQuickAddPopover);
  if (cancelBtn) cancelBtn.addEventListener('click', closeQuickAddPopover);

  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      handleQuickAddSubmit();
    });
  }

  // Close when clicking outside
  document.addEventListener('click', (e) => {
    if (popover && !popover.hidden) {
      if (!popover.contains(e.target) && !e.target.closest('.btn-quick-itinerary')) {
        closeQuickAddPopover();
      }
    }
  });

  // Escape to close
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && popover && !popover.hidden) {
      closeQuickAddPopover();
    }
  });
}

function openQuickAddPopover(destinationId, triggerBtn) {
  const popover = document.getElementById('quick-add-popover');
  const dest = sampleDestinations.find(d => d.id === destinationId);
  if (!popover || !dest) return;

  const destIdInput = document.getElementById('quick-add-dest-id');
  const titleEl = document.getElementById('quick-add-title');
  const dateInput = document.getElementById('quick-add-date');
  const timeInput = document.getElementById('quick-add-time');
  const actInput = document.getElementById('quick-add-activity');

  if (destIdInput) destIdInput.value = destinationId;
  if (titleEl) titleEl.textContent = `Schedule: ${dest.name}`;

  const todayStr = getTodayDateString();
  if (dateInput) {
    dateInput.min = todayStr;
    if (!dateInput.value || dateInput.value < todayStr) {
      dateInput.value = todayStr;
    }
  }

  if (timeInput && !timeInput.value) {
    timeInput.value = '09:00';
  }

  if (actInput) {
    actInput.value = dest.activities.length > 0 ? dest.activities[0] : 'Sightseeing';
  }

  // Clear previous field errors
  ['quick-add-date', 'quick-add-time', 'quick-add-activity'].forEach(id => {
    const el = document.getElementById(id);
    const err = document.getElementById(`error-${id}`);
    if (el) el.classList.remove('is-invalid');
    if (err) err.textContent = '';
  });

  // Position popover relative to button
  const rect = triggerBtn.getBoundingClientRect();
  const popoverWidth = 290;
  let left = rect.left + window.scrollX - 100;
  let top = rect.bottom + window.scrollY + 8;

  // Boundary checks
  if (left + popoverWidth > window.innerWidth - 20) {
    left = window.innerWidth - popoverWidth - 20;
  }
  if (left < 10) left = 10;

  popover.style.left = `${left}px`;
  popover.style.top = `${top}px`;
  popover.hidden = false;

  if (timeInput) timeInput.focus();
}

function closeQuickAddPopover() {
  const popover = document.getElementById('quick-add-popover');
  if (popover) popover.hidden = true;
}

function handleQuickAddSubmit() {
  const destIdInput = document.getElementById('quick-add-dest-id');
  const dateInput = document.getElementById('quick-add-date');
  const timeInput = document.getElementById('quick-add-time');
  const actInput = document.getElementById('quick-add-activity');

  const destId = parseInt(destIdInput.value, 10);
  const destObj = sampleDestinations.find(d => d.id === destId);
  const todayStr = getTodayDateString();

  let isValid = true;

  if (!dateInput.value) {
    dateInput.classList.add('is-invalid');
    document.getElementById('error-quick-add-date').textContent = 'Please choose a date.';
    isValid = false;
  } else if (dateInput.value < todayStr) {
    dateInput.classList.add('is-invalid');
    document.getElementById('error-quick-add-date').textContent = 'Date cannot be in the past.';
    isValid = false;
  }

  if (!timeInput.value) {
    timeInput.classList.add('is-invalid');
    document.getElementById('error-quick-add-time').textContent = 'Please select a time.';
    isValid = false;
  }

  if (!actInput.value.trim()) {
    actInput.classList.add('is-invalid');
    document.getElementById('error-quick-add-activity').textContent = 'Please enter an activity.';
    isValid = false;
  }

  if (!isValid) return;

  // Exact duplicate check
  const isExactDuplicate = appState.itinerary.some(stop =>
    stop.destinationId === destId &&
    stop.date === dateInput.value &&
    stop.time === timeInput.value
  );

  if (isExactDuplicate) {
    document.getElementById('error-quick-add-time').textContent = 'Destination already scheduled at this exact time.';
    return;
  }

  // Time clash check
  const clashingStop = appState.itinerary.find(stop =>
    stop.date === dateInput.value &&
    stop.time === timeInput.value
  );

  if (clashingStop) {
    document.getElementById('error-quick-add-time').textContent = `Clashes with "${clashingStop.destinationName}" at ${timeInput.value}.`;
    return;
  }

  // Add stop
  const newStop = {
    id: Date.now(),
    destinationId: destId,
    destinationName: destObj ? destObj.name : 'Destination',
    category: destObj ? destObj.category : '',
    fee: destObj ? destObj.fee : 0,
    date: dateInput.value,
    time: timeInput.value,
    activity: actInput.value.trim()
  };

  appState.itinerary.push(newStop);
  sortItineraryChronologically();
  saveData();

  closeQuickAddPopover();
  renderExploreGallery();
  renderItineraryList();
  renderHomeStats();

  showToast(`Added "${newStop.destinationName}" to itinerary.`, 'success');
}

/* ==========================================================================
   SCREEN 5: FAVORITES
   ========================================================================== */
function toggleFavorite(id) {
  const index = appState.favorites.indexOf(id);
  const dest = sampleDestinations.find(d => d.id === id);
  const destName = dest ? dest.name : 'Destination';

  if (index > -1) {
    appState.favorites.splice(index, 1);
    showToast(`Removed "${destName}" from favorites.`, 'info');
  } else {
    appState.favorites.push(id);
    showToast(`Saved "${destName}" to favorites.`, 'success');
  }

  saveData();

  renderHomeStats();
  renderHomeProgress();
  renderExploreGallery();
  renderFeaturedDestinations();
  renderFavoritesList();
}

function removeFavorite(id) {
  const index = appState.favorites.indexOf(id);
  if (index > -1) {
    const dest = sampleDestinations.find(d => d.id === id);
    appState.favorites.splice(index, 1);
    saveData();
    renderFavoritesList();
    renderHomeStats();
    renderHomeProgress();
    renderExploreGallery();
    renderFeaturedDestinations();
    showToast(`Removed "${dest ? dest.name : 'Destination'}" from favorites.`, 'info');
  }
}

function renderFavoritesList() {
  const grid = document.getElementById('favorites-grid');
  const emptyState = document.getElementById('favorites-empty-state');
  const toolbar = document.getElementById('favorites-toolbar');
  if (!grid) return;

  const favList = sampleDestinations.filter(d => appState.favorites.includes(d.id));

  if (favList.length === 0) {
    grid.innerHTML = '';
    if (emptyState) emptyState.style.display = 'block';
    if (toolbar) toolbar.style.display = 'none';
  } else {
    if (emptyState) emptyState.style.display = 'none';
    if (toolbar) toolbar.style.display = 'flex';

    grid.innerHTML = favList.map(dest => {
      const isPlanned = appState.itinerary.some(s => s.destinationId === dest.id);
      const categorySlug = dest.category.toLowerCase().replace(/[^a-z0-9]+/g, '-');
      const badgeClass = `badge-${categorySlug}`;
      const feeText = dest.fee === 0 ? 'Free Entry' : `₱${dest.fee}`;

      return `
        <article class="destination-card favorite-card" data-id="${dest.id}">
          <div class="card-image-wrap">
            <img src="${dest.image}" alt="${dest.name}" class="card-img" loading="lazy">
            ${isPlanned ? `<span class="card-planned-indicator"><svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"></polyline></svg> In itinerary</span>` : ''}
          </div>
          <div class="card-content">
            <div class="card-meta-row">
              <div class="card-meta-badges">
                <span class="badge ${badgeClass}">${dest.category}</span>
                <span class="badge rating-badge">
                  <svg viewBox="0 0 24 24" width="12" height="12" fill="#f59e0b" stroke="#f59e0b"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
                  ${dest.rating}
                </span>
              </div>
              <span class="card-fee-text ${dest.fee === 0 ? '' : 'card-fee-highlight'}">${feeText}</span>
            </div>
            <h3 class="card-title">${dest.name}</h3>
            <p class="card-location">${dest.location}</p>
            <div class="favorite-actions">
              <button type="button" class="btn btn-outline btn-sm btn-fav-details" data-id="${dest.id}">
                Details
              </button>
              <button type="button" class="btn btn-outline-danger btn-sm btn-remove-fav" data-id="${dest.id}">
                Remove
              </button>
              <button type="button" class="btn btn-primary btn-sm btn-fav-itinerary" data-id="${dest.id}">
                ${isPlanned ? 'Added' : '+ Itinerary'}
              </button>
            </div>
          </div>
        </article>
      `;
    }).join('');
  }

  // Bind Actions inside Favorites section
  grid.onclick = (e) => {
    const detailsBtn = e.target.closest('.btn-fav-details');
    if (detailsBtn) {
      const id = parseInt(detailsBtn.getAttribute('data-id'), 10);
      showDetails(id);
      return;
    }

    const removeBtn = e.target.closest('.btn-remove-fav');
    if (removeBtn) {
      const id = parseInt(removeBtn.getAttribute('data-id'), 10);
      removeFavorite(id);
      return;
    }

    const itBtn = e.target.closest('.btn-fav-itinerary');
    if (itBtn) {
      const id = parseInt(itBtn.getAttribute('data-id'), 10);
      openQuickAddPopover(id, itBtn);
    }
  };

  // "Plan these places" action button
  const planBtn = document.getElementById('btn-plan-favorites');
  if (planBtn) {
    planBtn.onclick = () => {
      planAllFavorites();
    };
  }
}

/**
 * Guides user to plan all bookmarked favorites sequentially
 */
function planAllFavorites() {
  const unaddedFavs = appState.favorites.filter(id =>
    !appState.itinerary.some(s => s.destinationId === id)
  );

  if (unaddedFavs.length === 0) {
    showToast('All your favorite places are already in your itinerary!', 'info');
    showSection('itinerary');
    return;
  }

  // Pre-fill the itinerary form with the first unadded favorite
  prefillItineraryForm(unaddedFavs[0]);
  showToast(`Ready to schedule "${sampleDestinations.find(d => d.id === unaddedFavs[0])?.name}".`, 'info');
}

/* ==========================================================================
   SCREEN 4: ITINERARY PLANNER (Grouping, Edit, Validation, Clashes)
   ========================================================================== */
function populateDestinationSelect() {
  const select = document.getElementById('itinerary-destination');
  if (!select) return;

  select.innerHTML = '<option value="" disabled selected>Choose a destination</option>';

  sampleDestinations.forEach(dest => {
    const option = document.createElement('option');
    option.value = dest.id;
    option.textContent = `${dest.name} (${dest.category} - ${dest.fee === 0 ? 'Free' : '₱' + dest.fee})`;
    select.appendChild(option);
  });

  renderDestinationDropdownOptions();
  syncDestinationDropdown();
}

function prefillItineraryForm(destinationId) {
  showSection('itinerary');

  const select = document.getElementById('itinerary-destination');
  if (select) {
    select.value = destinationId;
    syncDestinationDropdown();
  }

  const actInput = document.getElementById('itinerary-activity');
  const dest = sampleDestinations.find(d => d.id === destinationId);
  if (actInput && dest && dest.activities.length > 0 && !actInput.value.trim()) {
    actInput.value = dest.activities[0];
  }

  const dateInput = document.getElementById('itinerary-date');
  const todayStr = getTodayDateString();
  if (dateInput && (!dateInput.value || dateInput.value < todayStr)) {
    dateInput.value = todayStr;
  }

  const timeInput = document.getElementById('itinerary-time');
  if (timeInput && !timeInput.value) {
    timeInput.value = '09:00';
    timeInput.focus();
  }
}

function setupItineraryControls() {
  const form = document.getElementById('itinerary-form');
  const clearBtn = document.getElementById('btn-clear-itinerary');
  const itemsList = document.getElementById('itinerary-items-list');
  const cancelEditBtn = document.getElementById('btn-cancel-edit');

  // Submit Itinerary Form (Add or Edit)
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      if (validateItineraryForm()) {
        saveItineraryStop();
      }
    });
  }

  // Cancel Edit
  if (cancelEditBtn) {
    cancelEditBtn.addEventListener('click', resetItineraryFormToCreate);
  }

  // Clear all stops (triggers custom confirmation dialog)
  if (clearBtn) {
    clearBtn.addEventListener('click', () => {
      if (appState.itinerary.length === 0) {
        showToast('Your itinerary is already empty.', 'info');
        return;
      }
      openConfirmDialog(
        'Clear all stops?',
        'Are you sure you want to remove all planned itinerary stops? This action cannot be undone.',
        clearItineraryConfirmed
      );
    });
  }

  // Stop Action delegation (Edit & Delete)
  if (itemsList) {
    itemsList.addEventListener('click', (e) => {
      const editBtn = e.target.closest('.stop-edit-btn');
      if (editBtn) {
        const stopId = parseInt(editBtn.getAttribute('data-id'), 10);
        editStop(stopId);
        return;
      }

      const delBtn = e.target.closest('.stop-delete-btn');
      if (delBtn) {
        const stopId = parseInt(delBtn.getAttribute('data-id'), 10);
        deleteStop(stopId);
      }
    });
  }

  // Clear field errors on input
  ['itinerary-destination', 'itinerary-date', 'itinerary-time', 'itinerary-activity'].forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      el.addEventListener('input', () => {
        el.classList.remove('is-invalid');
        const errSpan = document.getElementById(`error-${id}`);
        if (errSpan) errSpan.textContent = '';
      });
    }
  });
}

/**
 * Validates date (no past dates), required fields, exact duplicates, and time clashes
 */
function validateItineraryForm() {
  let isValid = true;

  const destSelect = document.getElementById('itinerary-destination');
  const dateInput = document.getElementById('itinerary-date');
  const timeInput = document.getElementById('itinerary-time');
  const actInput = document.getElementById('itinerary-activity');

  const errorDest = document.getElementById('error-itinerary-destination');
  const errorDate = document.getElementById('error-itinerary-date');
  const errorTime = document.getElementById('error-itinerary-time');
  const errorAct = document.getElementById('error-itinerary-activity');
  const bannerError = document.getElementById('itinerary-form-error');

  [destSelect, dateInput, timeInput, actInput].forEach(el => el.classList.remove('is-invalid'));
  [errorDest, errorDate, errorTime, errorAct].forEach(el => el.textContent = '');
  if (bannerError) bannerError.style.display = 'none';

  // 1. Destination check
  if (!destSelect.value) {
    destSelect.classList.add('is-invalid');
    if (errorDest) errorDest.textContent = 'Please choose a destination.';
    isValid = false;
  }

  // 2. Date check & No past dates validation
  const todayStr = getTodayDateString();
  if (!dateInput.value) {
    dateInput.classList.add('is-invalid');
    if (errorDate) errorDate.textContent = 'Please choose a date.';
    isValid = false;
  } else if (dateInput.value < todayStr) {
    dateInput.classList.add('is-invalid');
    if (errorDate) errorDate.textContent = 'Please select today or a future date.';
    isValid = false;
  }

  // 3. Time check
  if (!timeInput.value) {
    timeInput.classList.add('is-invalid');
    if (errorTime) errorTime.textContent = 'Please select a planned time.';
    isValid = false;
  }

  // 4. Activity check
  if (!actInput.value.trim()) {
    actInput.classList.add('is-invalid');
    if (errorAct) errorAct.textContent = 'Please describe the planned activity.';
    isValid = false;
  }

  if (!isValid) {
    if (bannerError) {
      bannerError.textContent = 'Please complete all required fields correctly.';
      bannerError.style.display = 'block';
    }
    return false;
  }

  // 5. Duplicates and Clashes Validation
  const destId = parseInt(destSelect.value, 10);
  const destObj = sampleDestinations.find(d => d.id === destId);
  const editingId = appState.editingStopId;

  // Exact duplicate: same destination, same date, same time
  const isExactDuplicate = appState.itinerary.some(stop =>
    stop.id !== editingId &&
    stop.destinationId === destId &&
    stop.date === dateInput.value &&
    stop.time === timeInput.value
  );

  if (isExactDuplicate) {
    if (bannerError) {
      bannerError.textContent = `"${destObj ? destObj.name : 'Destination'}" is already scheduled on ${formatDate(dateInput.value)} at ${timeInput.value}.`;
      bannerError.style.display = 'block';
    }
    timeInput.classList.add('is-invalid');
    if (errorTime) errorTime.textContent = 'Exact duplicate schedule exists.';
    return false;
  }

  // Time clash: different destination, same date, same time
  const clashingStop = appState.itinerary.find(stop =>
    stop.id !== editingId &&
    stop.date === dateInput.value &&
    stop.time === timeInput.value
  );

  if (clashingStop) {
    if (bannerError) {
      bannerError.textContent = `Schedule conflict: You already have "${clashingStop.destinationName}" planned at ${timeInput.value} on ${formatDate(dateInput.value)}.`;
      bannerError.style.display = 'block';
    }
    timeInput.classList.add('is-invalid');
    if (errorTime) errorTime.textContent = `Overlaps with "${clashingStop.destinationName}".`;
    return false;
  }

  return true;
}

function saveItineraryStop() {
  const destSelect = document.getElementById('itinerary-destination');
  const dateInput = document.getElementById('itinerary-date');
  const timeInput = document.getElementById('itinerary-time');
  const actInput = document.getElementById('itinerary-activity');
  const bannerSuccess = document.getElementById('itinerary-form-success');

  const destId = parseInt(destSelect.value, 10);
  const destObj = sampleDestinations.find(d => d.id === destId);

  if (appState.editingStopId) {
    // Update existing stop
    const stopIndex = appState.itinerary.findIndex(s => s.id === appState.editingStopId);
    if (stopIndex > -1) {
      appState.itinerary[stopIndex] = {
        ...appState.itinerary[stopIndex],
        destinationId: destId,
        destinationName: destObj ? destObj.name : 'Destination',
        category: destObj ? destObj.category : '',
        fee: destObj ? destObj.fee : 0,
        date: dateInput.value,
        time: timeInput.value,
        activity: actInput.value.trim()
      };
      showToast(`Updated "${destObj ? destObj.name : 'stop'}".`, 'success');
    }
    resetItineraryFormToCreate();
  } else {
    // Create new stop
    const newStop = {
      id: Date.now(),
      destinationId: destId,
      destinationName: destObj ? destObj.name : 'Destination',
      category: destObj ? destObj.category : '',
      fee: destObj ? destObj.fee : 0,
      date: dateInput.value,
      time: timeInput.value,
      activity: actInput.value.trim()
    };
    appState.itinerary.push(newStop);
    showToast(`Added stop: "${newStop.destinationName}"`, 'success');
  }

  sortItineraryChronologically();
  saveData();

  renderItineraryList();
  renderHomeStats();
  renderExploreGallery();
  autoSyncBudgetFromStops();

  if (bannerSuccess) {
    bannerSuccess.textContent = 'Stop added to your itinerary.';
    bannerSuccess.style.display = 'block';
    setTimeout(() => {
      bannerSuccess.style.display = 'none';
    }, 3500);
  }

  actInput.value = '';
}

function editStop(stopId) {
  const stop = appState.itinerary.find(s => s.id === stopId);
  if (!stop) return;

  appState.editingStopId = stopId;

  const destSelect = document.getElementById('itinerary-destination');
  const dateInput = document.getElementById('itinerary-date');
  const timeInput = document.getElementById('itinerary-time');
  const actInput = document.getElementById('itinerary-activity');
  const heading = document.getElementById('itinerary-form-heading');
  const subtext = document.getElementById('itinerary-form-subtext');
  const btnText = document.getElementById('btn-add-itinerary-text');
  const cancelBtn = document.getElementById('btn-cancel-edit');

  if (destSelect) {
    destSelect.value = stop.destinationId;
    syncDestinationDropdown();
  }
  if (dateInput) dateInput.value = stop.date;
  if (timeInput) timeInput.value = stop.time;
  if (actInput) actInput.value = stop.activity;

  if (heading) heading.textContent = 'Edit scheduled stop';
  if (subtext) subtext.textContent = 'Update stop time, date, or activity';
  if (btnText) btnText.textContent = 'Update stop';
  if (cancelBtn) cancelBtn.style.display = 'inline-flex';

  // Smooth scroll form into view
  const formCard = document.querySelector('.form-card');
  if (formCard) {
    formCard.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
}

function resetItineraryFormToCreate() {
  appState.editingStopId = null;

  const heading = document.getElementById('itinerary-form-heading');
  const subtext = document.getElementById('itinerary-form-subtext');
  const btnText = document.getElementById('btn-add-itinerary-text');
  const cancelBtn = document.getElementById('btn-cancel-edit');
  const bannerError = document.getElementById('itinerary-form-error');

  if (heading) heading.textContent = 'Schedule a stop';
  if (subtext) subtext.textContent = 'Add destination details and planned time';
  if (btnText) btnText.textContent = 'Add to itinerary';
  if (cancelBtn) cancelBtn.style.display = 'none';
  if (bannerError) bannerError.style.display = 'none';
}

function deleteStop(stopId) {
  const index = appState.itinerary.findIndex(s => s.id === stopId);
  if (index > -1) {
    const deleted = appState.itinerary.splice(index, 1)[0];
    appState.lastDeletedStop = { stop: deleted, index };

    saveData();
    renderItineraryList();
    renderHomeStats();
    renderExploreGallery();
    autoSyncBudgetFromStops();

    showToast(`Removed "${deleted.destinationName}" from itinerary.`, 'info', true);
  }
}

function undoDeleteStop() {
  if (!appState.lastDeletedStop) return;

  const { stop, index } = appState.lastDeletedStop;
  appState.itinerary.splice(index, 0, stop);
  appState.lastDeletedStop = null;

  sortItineraryChronologically();
  saveData();

  renderItineraryList();
  renderHomeStats();
  renderExploreGallery();
  autoSyncBudgetFromStops();

  showToast(`Restored "${stop.destinationName}" to itinerary.`, 'success');
}

function clearItineraryConfirmed() {
  const previousStops = [...appState.itinerary];
  appState.itinerary = [];
  saveData();
  renderItineraryList();
  renderHomeStats();
  renderExploreGallery();
  autoSyncBudgetFromStops();

  showToast('All itinerary stops cleared.', 'info');
}

function sortItineraryChronologically() {
  appState.itinerary.sort((a, b) => {
    const dateTimeA = new Date(`${a.date}T${a.time}`);
    const dateTimeB = new Date(`${b.date}T${b.time}`);
    return dateTimeA - dateTimeB;
  });
}

/**
 * Renders the itinerary list grouped by day with counts
 */
function renderItineraryList() {
  const container = document.getElementById('itinerary-items-list');
  const emptyState = document.getElementById('itinerary-empty-state');
  const countSpan = document.getElementById('itinerary-count');

  if (!container) return;

  const count = appState.itinerary.length;
  if (countSpan) countSpan.textContent = count;

  if (count === 0) {
    container.innerHTML = '';
    if (emptyState) emptyState.style.display = 'block';
    return;
  }

  if (emptyState) emptyState.style.display = 'none';

  // Group stops by date
  const uniqueDates = [...new Set(appState.itinerary.map(s => s.date))].sort();

  container.innerHTML = uniqueDates.map((dateStr, idx) => {
    const dayStops = appState.itinerary.filter(s => s.date === dateStr);
    const dayNumber = idx + 1;
    const formattedDate = formatDate(dateStr);

    return `
      <div class="itinerary-day-group">
        <div class="itinerary-day-header">
          <span class="itinerary-day-title">Day ${dayNumber} · ${formattedDate}</span>
          <span class="itinerary-day-count">${dayStops.length} stop${dayStops.length === 1 ? '' : 's'}</span>
        </div>
        ${dayStops.map(stop => `
          <div class="itinerary-stop-card" data-id="${stop.id}">
            <div class="stop-time-badge">
              <span class="stop-clock">${stop.time}</span>
              <span class="stop-fee-pill">${stop.fee === 0 ? 'Free' : '₱' + stop.fee}</span>
            </div>
            <div class="stop-details">
              <h4>${escapeHTML(stop.destinationName)}</h4>
              <p class="stop-activity">${escapeHTML(stop.activity)}</p>
            </div>
            <div class="stop-actions-group">
              <button type="button" class="stop-edit-btn" data-id="${stop.id}" title="Edit this stop">
                Edit
              </button>
              <button type="button" class="stop-delete-btn" data-id="${stop.id}" title="Delete stop">
                Delete
              </button>
            </div>
          </div>
        `).join('')}
      </div>
    `;
  }).join('');
}

/* ==========================================================================
   CUSTOM DESTINATION DROPDOWN (Accessible with keyboard arrow keys)
   ========================================================================== */
let highlightedDropdownIndex = -1;

function setupDestinationDropdown() {
  const dropdown = document.getElementById('destination-dropdown');
  const trigger = document.getElementById('destination-dropdown-trigger');
  const panel = document.getElementById('destination-dropdown-panel');
  const searchInput = document.getElementById('destination-search');
  const select = document.getElementById('itinerary-destination');

  if (!dropdown || !trigger || !panel || !searchInput || !select) return;

  trigger.addEventListener('click', () => {
    if (dropdown.classList.contains('is-open')) {
      closeDestinationDropdown();
    } else {
      openDestinationDropdown();
    }
  });

  searchInput.addEventListener('input', () => {
    highlightedDropdownIndex = -1;
    renderDestinationDropdownOptions(searchInput.value);
  });

  document.addEventListener('click', event => {
    if (!dropdown.contains(event.target)) {
      closeDestinationDropdown();
    }
  });

  // Accessible Keyboard Navigation (Arrow keys, Enter, Escape, Home, End)
  dropdown.addEventListener('keydown', event => {
    const options = panel.querySelectorAll('.destination-option');
    if (!options.length) return;

    if (event.key === 'ArrowDown') {
      event.preventDefault();
      if (panel.hidden) {
        openDestinationDropdown();
      } else {
        highlightedDropdownIndex = (highlightedDropdownIndex + 1) % options.length;
        updateHighlightedDropdownOption(options);
      }
    } else if (event.key === 'ArrowUp') {
      event.preventDefault();
      if (!panel.hidden) {
        highlightedDropdownIndex = (highlightedDropdownIndex - 1 + options.length) % options.length;
        updateHighlightedDropdownOption(options);
      }
    } else if (event.key === 'Home') {
      event.preventDefault();
      highlightedDropdownIndex = 0;
      updateHighlightedDropdownOption(options);
    } else if (event.key === 'End') {
      event.preventDefault();
      highlightedDropdownIndex = options.length - 1;
      updateHighlightedDropdownOption(options);
    } else if (event.key === 'Enter') {
      if (!panel.hidden && highlightedDropdownIndex >= 0 && highlightedDropdownIndex < options.length) {
        event.preventDefault();
        options[highlightedDropdownIndex].click();
      }
    } else if (event.key === 'Escape') {
      closeDestinationDropdown();
      trigger.focus();
    }
  });

  select.addEventListener('change', syncDestinationDropdown);
}

function updateHighlightedDropdownOption(options) {
  options.forEach((opt, idx) => {
    if (idx === highlightedDropdownIndex) {
      opt.classList.add('is-highlighted');
      opt.scrollIntoView({ block: 'nearest' });
      opt.focus();
    } else {
      opt.classList.remove('is-highlighted');
    }
  });
}

function openDestinationDropdown() {
  const dropdown = document.getElementById('destination-dropdown');
  const trigger = document.getElementById('destination-dropdown-trigger');
  const panel = document.getElementById('destination-dropdown-panel');
  const searchInput = document.getElementById('destination-search');

  if (!dropdown || !trigger || !panel) return;

  dropdown.classList.add('is-open');
  panel.hidden = false;
  trigger.setAttribute('aria-expanded', 'true');
  highlightedDropdownIndex = -1;

  if (searchInput) {
    searchInput.value = '';
    renderDestinationDropdownOptions();
    searchInput.focus();
  }
}

function closeDestinationDropdown() {
  const dropdown = document.getElementById('destination-dropdown');
  const trigger = document.getElementById('destination-dropdown-trigger');
  const panel = document.getElementById('destination-dropdown-panel');

  if (!dropdown || !trigger || !panel) return;

  dropdown.classList.remove('is-open');
  panel.hidden = true;
  trigger.setAttribute('aria-expanded', 'false');
  highlightedDropdownIndex = -1;
}

function renderDestinationDropdownOptions(searchTerm = '') {
  const container = document.getElementById('destination-options');
  const noResults = document.getElementById('destination-no-results');
  const select = document.getElementById('itinerary-destination');

  if (!container || !select) return;

  const selectedId = select.value;
  const search = searchTerm.trim().toLowerCase();

  const filtered = sampleDestinations.filter(dest => {
    const text = `${dest.name} ${dest.category} ${dest.location}`.toLowerCase();
    return text.includes(search);
  });

  container.innerHTML = '';

  filtered.forEach(dest => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'destination-option';
    button.setAttribute('data-id', dest.id);

    const isSelected = String(dest.id) === String(selectedId);
    if (isSelected) {
      button.classList.add('is-selected');
    }

    button.setAttribute('role', 'option');
    button.setAttribute('aria-selected', String(isSelected));

    const main = document.createElement('span');
    main.className = 'destination-option-main';

    const name = document.createElement('span');
    name.className = 'destination-option-name';
    name.textContent = dest.name;

    const category = document.createElement('span');
    category.className = 'destination-option-category';
    category.textContent = dest.category;

    const fee = document.createElement('span');
    fee.className = 'destination-option-fee';
    fee.textContent = dest.fee === 0 ? 'Free' : `₱${dest.fee}`;

    main.append(name, category);
    button.append(main, fee);

    button.addEventListener('click', () => {
      selectDestinationFromDropdown(dest.id);
    });

    container.appendChild(button);
  });

  if (noResults) {
    noResults.hidden = filtered.length > 0;
  }
}

function selectDestinationFromDropdown(destinationId) {
  const select = document.getElementById('itinerary-destination');
  if (!select) return;

  select.value = String(destinationId);
  syncDestinationDropdown();

  select.dispatchEvent(new Event('change', { bubbles: true }));

  const errSpan = document.getElementById('error-itinerary-destination');
  if (errSpan) errSpan.textContent = '';
  select.classList.remove('is-invalid');

  closeDestinationDropdown();
}

function syncDestinationDropdown() {
  const select = document.getElementById('itinerary-destination');
  const label = document.getElementById('destination-selected-label');
  if (!select || !label) return;

  const destination = sampleDestinations.find(dest => String(dest.id) === String(select.value));
  label.textContent = destination ? destination.name : 'Choose a destination';

  renderDestinationDropdownOptions(
    document.getElementById('destination-search')?.value || ''
  );
}

/* ==========================================================================
   SCREEN 6: BUDGET CALCULATOR (Autosave, Partial Budget, Linked to Itinerary)
   ========================================================================== */
function setupBudgetControls() {
  const calcInputs = document.querySelectorAll('.budget-calc-input');
  const saveBtn = document.getElementById('btn-save-budget');
  const resetBtn = document.getElementById('btn-reset-budget');
  const autoFillBtn = document.getElementById('budget-recalc-stops-btn');

  // Autosave on every input change: calculate and persist live
  calcInputs.forEach(input => {
    input.addEventListener('input', () => {
      calculateBudget(true); // Persist automatically
    });
  });

  // Save budget button (manual trigger with visual feedback)
  if (saveBtn) {
    saveBtn.addEventListener('click', () => {
      if (validateBudget()) {
        calculateBudget(true);
        const successBanner = document.getElementById('budget-success-msg');
        if (successBanner) {
          successBanner.textContent = 'Budget saved.';
          successBanner.style.display = 'block';
          setTimeout(() => {
            successBanner.style.display = 'none';
          }, 3000);
        }
        showToast('Budget successfully saved.', 'success');
      }
    });
  }

  // Reset button
  if (resetBtn) {
    resetBtn.addEventListener('click', resetBudget);
  }

  // Auto-fill from stops button
  if (autoFillBtn) {
    autoFillBtn.addEventListener('click', () => {
      syncActivitiesFeeFromStops(true);
    });
  }
}

function restoreBudgetInputs() {
  const b = appState.budget;
  const days = document.getElementById('budget-days');
  const trav = document.getElementById('budget-travelers');
  const trans = document.getElementById('budget-transportation');
  const acc = document.getElementById('budget-accommodation');
  const food = document.getElementById('budget-food');
  const act = document.getElementById('budget-activities');

  if (days) days.value = b.days || 1;
  if (trav) trav.value = b.travelers || 1;
  if (trans) trans.value = b.transportation || '';
  if (acc) acc.value = b.accommodation || '';
  if (food) food.value = b.food || '';
  if (act) act.value = b.activities || '';

  // Initial link to stops if activities is 0
  if (!b.activities || b.activities === 0) {
    syncActivitiesFeeFromStops(false);
  } else {
    updateActivitiesNote();
  }
}

/**
 * Calculates entrance fees from planned stops: sum(fee) * travelers
 */
function syncActivitiesFeeFromStops(notify = false) {
  const actInput = document.getElementById('budget-activities');
  const travInput = document.getElementById('budget-travelers');
  const travelers = Math.max(1, parseInt(travInput ? travInput.value : 1, 10) || 1);

  const stopsFeeSum = appState.itinerary.reduce((sum, stop) => sum + (Number(stop.fee) || 0), 0);
  const totalActFee = stopsFeeSum * travelers;

  if (actInput) {
    actInput.value = totalActFee > 0 ? totalActFee : '';
  }

  updateActivitiesNote();
  calculateBudget(true);

  if (notify) {
    showToast(`Activities fee auto-calculated: ₱${totalActFee.toFixed(2)} from ${appState.itinerary.length} stops.`, 'info');
  }
}

function updateActivitiesNote() {
  const noteEl = document.getElementById('budget-activities-note');
  const travInput = document.getElementById('budget-travelers');
  const travelers = Math.max(1, parseInt(travInput ? travInput.value : 1, 10) || 1);
  const count = appState.itinerary.length;
  const stopsFeeSum = appState.itinerary.reduce((sum, stop) => sum + (Number(stop.fee) || 0), 0);

  if (noteEl) {
    noteEl.textContent = `Based on ${count} stop${count === 1 ? '' : 's'} (₱${stopsFeeSum.toFixed(2)} fees × ${travelers} traveler${travelers === 1 ? '' : 's'}).`;
  }
}

function autoSyncBudgetFromStops() {
  // If user is currently editing or has budget active, keep activities synced if matching
  updateActivitiesNote();
}

/**
 * Computes budget totals live, treats empty inputs as 0, and autosaves
 */
function calculateBudget(shouldSave = true) {
  const daysInput = document.getElementById('budget-days');
  const travInput = document.getElementById('budget-travelers');
  const transInput = document.getElementById('budget-transportation');
  const accInput = document.getElementById('budget-accommodation');
  const foodInput = document.getElementById('budget-food');
  const actInput = document.getElementById('budget-activities');

  const days = Math.max(1, parseInt(daysInput ? daysInput.value : 1, 10) || 1);
  const travelers = Math.max(1, parseInt(travInput ? travInput.value : 1, 10) || 1);

  // Treat empty as 0
  const transVal = Math.max(0, parseFloat(transInput ? transInput.value : 0) || 0);
  const accVal = Math.max(0, parseFloat(accInput ? accInput.value : 0) || 0);
  const foodVal = Math.max(0, parseFloat(foodInput ? foodInput.value : 0) || 0);
  const actVal = Math.max(0, parseFloat(actInput ? actInput.value : 0) || 0);

  const total = transVal + accVal + foodVal + actVal;
  const perTraveler = total / travelers;

  // Accommodation per night hint
  const accHint = document.getElementById('budget-accommodation-calc-hint');
  if (accHint) {
    const perNight = accVal / days;
    accHint.textContent = `₱${perNight.toFixed(2)} / night (${days} day${days === 1 ? '' : 's'})`;
  }

  // Update State
  appState.budget = {
    days,
    travelers,
    transportation: transVal,
    accommodation: accVal,
    food: foodVal,
    activities: actVal,
    total,
    perPerson: perTraveler
  };

  // Update Displays
  const totalDisplay = document.getElementById('display-total-budget');
  const perTravelerDisplay = document.getElementById('display-per-traveler');
  const bdTrans = document.getElementById('summary-breakdown-trans');
  const bdAcc = document.getElementById('summary-breakdown-acc');
  const bdFood = document.getElementById('summary-breakdown-food');
  const bdAct = document.getElementById('summary-breakdown-act');
  const bdCount = document.getElementById('summary-breakdown-count');

  if (totalDisplay) totalDisplay.textContent = formatCurrency(total);
  if (perTravelerDisplay) perTravelerDisplay.textContent = formatCurrency(perTraveler);
  if (bdTrans) bdTrans.textContent = formatCurrency(transVal);
  if (bdAcc) bdAcc.textContent = formatCurrency(accVal);
  if (bdFood) bdFood.textContent = formatCurrency(foodVal);
  if (bdAct) bdAct.textContent = formatCurrency(actVal);
  if (bdCount) bdCount.textContent = `${travelers} traveler${travelers > 1 ? 's' : ''} · ${days} day${days > 1 ? 's' : ''}`;

  if (shouldSave) {
    saveData();
  }
}

/**
 * Validates budget. Partial budgets are ALLOWED (empty treated as 0).
 * Fails only on negative or invalid numbers.
 */
function validateBudget() {
  const transInput = document.getElementById('budget-transportation');
  const accInput = document.getElementById('budget-accommodation');
  const foodInput = document.getElementById('budget-food');
  const actInput = document.getElementById('budget-activities');
  const travInput = document.getElementById('budget-travelers');
  const daysInput = document.getElementById('budget-days');
  const errorBanner = document.getElementById('budget-error-msg');

  if (errorBanner) errorBanner.style.display = 'none';

  let isValid = true;
  const costInputs = [transInput, accInput, foodInput, actInput];

  ['budget-transportation', 'budget-accommodation', 'budget-food', 'budget-activities', 'budget-travelers', 'budget-days'].forEach(id => {
    const el = document.getElementById(id);
    const err = document.getElementById(`error-${id}`);
    if (el) el.classList.remove('is-invalid');
    if (err) err.textContent = '';
  });

  // Empty fields treat as 0 without failing! Check only negative numbers.
  costInputs.forEach(input => {
    if (!input) return;
    const valStr = input.value.trim();
    if (valStr !== '') {
      const valNum = Number(valStr);
      if (isNaN(valNum) || valNum < 0) {
        isValid = false;
        input.classList.add('is-invalid');
        const errSpan = document.getElementById(`error-${input.id}`);
        if (errSpan) errSpan.textContent = 'Enter a valid amount of 0 or more.';
      }
    }
  });

  // Travelers must be >= 1
  if (travInput) {
    const travNum = Number(travInput.value.trim());
    if (isNaN(travNum) || travNum < 1) {
      isValid = false;
      travInput.classList.add('is-invalid');
      const errSpan = document.getElementById('error-budget-travelers');
      if (errSpan) errSpan.textContent = 'Enter at least 1 traveler.';
    }
  }

  // Days must be >= 1
  if (daysInput) {
    const daysNum = Number(daysInput.value.trim());
    if (isNaN(daysNum) || daysNum < 1) {
      isValid = false;
      daysInput.classList.add('is-invalid');
      const errSpan = document.getElementById('error-budget-days');
      if (errSpan) errSpan.textContent = 'Enter at least 1 day.';
    }
  }

  if (!isValid && errorBanner) {
    errorBanner.textContent = 'Please check your inputs.';
    errorBanner.style.display = 'block';
  }

  return isValid;
}

function resetBudget() {
  const inputs = [
    'budget-transportation',
    'budget-accommodation',
    'budget-food',
    'budget-activities'
  ];

  inputs.forEach(id => {
    const el = document.getElementById(id);
    const err = document.getElementById(`error-${id}`);
    if (el) {
      el.value = '';
      el.classList.remove('is-invalid');
    }
    if (err) err.textContent = '';
  });

  const travInput = document.getElementById('budget-travelers');
  const daysInput = document.getElementById('budget-days');
  if (travInput) travInput.value = '1';
  if (daysInput) daysInput.value = '1';

  localStorage.removeItem(STORAGE_KEYS.BUDGET);
  appState.budget = {
    days: 1,
    travelers: 1,
    transportation: 0,
    accommodation: 0,
    food: 0,
    activities: 0,
    total: 0,
    perPerson: 0
  };

  calculateBudget(true);
  updateActivitiesNote();

  showToast('Budget inputs reset to zero.', 'info');
}

/* ==========================================================================
   SCREEN 7: TRAVEL PLAN SUMMARY
   ========================================================================== */
function setupSummaryControls() {
  const printBtn = document.getElementById('btn-print-summary');
  if (printBtn) {
    printBtn.addEventListener('click', () => {
      window.print();
    });
  }
}

/**
 * Builds Summary report with trip overview, favorites, day-by-day stops,
 * itemized budget breakdown, and clean print layout.
 */
function buildSummary() {
  const reportCard = document.getElementById('summary-report-card');
  const emptyState = document.getElementById('summary-empty-state');
  const printBtn = document.getElementById('btn-print-summary');

  const favs = sampleDestinations.filter(d => appState.favorites.includes(d.id));
  const stops = appState.itinerary;
  const budget = appState.budget;

  const hasData = favs.length > 0 || stops.length > 0 || (budget && budget.total > 0);

  if (!hasData) {
    if (reportCard) reportCard.style.display = 'none';
    if (printBtn) printBtn.style.display = 'none';
    if (emptyState) emptyState.style.display = 'block';
    return;
  }

  if (emptyState) emptyState.style.display = 'none';
  if (reportCard) reportCard.style.display = 'block';
  if (printBtn) printBtn.style.display = 'inline-flex';

  // 1. Meta Details at Top
  const metaDays = document.getElementById('summary-meta-days');
  const metaTravelers = document.getElementById('summary-meta-travelers');
  const metaStops = document.getElementById('summary-meta-stops-count');

  const daysCount = budget.days || 1;
  const travelersCount = budget.travelers || 1;

  if (metaDays) metaDays.textContent = `${daysCount} Day${daysCount === 1 ? '' : 's'}`;
  if (metaTravelers) metaTravelers.textContent = `${travelersCount} Person${travelersCount === 1 ? '' : 's'}`;
  if (metaStops) metaStops.textContent = `${stops.length} Stop${stops.length === 1 ? '' : 's'}`;

  // 2. Favorites List (No emoji, clean pills)
  const favTagsContainer = document.getElementById('summary-fav-tags');
  if (favTagsContainer) {
    if (favs.length === 0) {
      favTagsContainer.innerHTML = '<span style="color: #94a3b8; font-style: italic;">No favorite places bookmarked.</span>';
    } else {
      favTagsContainer.innerHTML = favs.map(f => `
        <span class="summary-fav-pill">${escapeHTML(f.name)} (${f.category})</span>
      `).join('');
    }
  }

  // 3. Day-by-Day Itinerary Schedule
  const itineraryContainer = document.getElementById('summary-itinerary-list');
  if (itineraryContainer) {
    if (stops.length === 0) {
      itineraryContainer.innerHTML = '<span style="color: #94a3b8; font-style: italic;">No planned stops yet.</span>';
    } else {
      const uniqueDates = [...new Set(stops.map(s => s.date))].sort();
      itineraryContainer.innerHTML = uniqueDates.map((dateStr, idx) => {
        const dayStops = stops.filter(s => s.date === dateStr);
        const dayNumber = idx + 1;
        const formattedDate = formatDate(dateStr);

        return `
          <div class="summary-day-group">
            <div class="summary-day-header">Day ${dayNumber} — ${formattedDate} (${dayStops.length} stops)</div>
            ${dayStops.map(stop => `
              <div class="summary-itinerary-item">
                <span class="summary-time-tag">${stop.time}</span>
                <span class="summary-itinerary-text">
                  <strong>${escapeHTML(stop.destinationName)}</strong>: ${escapeHTML(stop.activity)}
                  ${stop.fee > 0 ? ` <small style="color: #0f766e;">(Fee: ₱${stop.fee})</small>` : ''}
                </span>
              </div>
            `).join('')}
          </div>
        `;
      }).join('');
    }
  }

  // 4. Budget Breakdown (Itemized table, NOT just repeating the total)
  const costTrans = document.getElementById('summary-cost-trans');
  const costAcc = document.getElementById('summary-cost-acc');
  const costFood = document.getElementById('summary-cost-food');
  const costAct = document.getElementById('summary-cost-activities');
  const costTotal = document.getElementById('summary-cost-total');
  const costPerPerson = document.getElementById('summary-cost-per-person');
  const costTravelers = document.getElementById('summary-cost-travelers');

  const total = budget.total || 0;
  const travelers = budget.travelers || 1;
  const perPerson = total / travelers;

  if (costTrans) costTrans.textContent = formatCurrency(budget.transportation || 0);
  if (costAcc) costAcc.textContent = formatCurrency(budget.accommodation || 0);
  if (costFood) costFood.textContent = formatCurrency(budget.food || 0);
  if (costAct) costAct.textContent = formatCurrency(budget.activities || 0);
  if (costTotal) costTotal.textContent = formatCurrency(total);
  if (costPerPerson) costPerPerson.textContent = formatCurrency(perPerson);
  if (costTravelers) costTravelers.textContent = travelers;
}

const generateSummary = buildSummary; // Alias

/* ==========================================================================
   CONFIRMATION DIALOG (Replaces window.confirm)
   ========================================================================== */
let confirmDialogCallback = null;
let confirmLastFocusedElement = null;

function setupConfirmDialog() {
  const modal = document.getElementById('confirm-modal');
  const cancelBtn = document.getElementById('confirm-cancel-btn');
  const okBtn = document.getElementById('confirm-ok-btn');
  const backdrop = document.getElementById('confirm-modal-backdrop');

  const closeDialog = () => {
    if (modal) {
      modal.style.display = 'none';
      modal.setAttribute('aria-hidden', 'true');
      document.body.style.overflow = '';
    }
    confirmDialogCallback = null;
    if (confirmLastFocusedElement && typeof confirmLastFocusedElement.focus === 'function') {
      confirmLastFocusedElement.focus();
    }
  };

  if (cancelBtn) cancelBtn.addEventListener('click', closeDialog);
  if (backdrop) backdrop.addEventListener('click', closeDialog);

  if (okBtn) {
    okBtn.addEventListener('click', () => {
      const cb = confirmDialogCallback;
      closeDialog();
      if (typeof cb === 'function') {
        cb();
      }
    });
  }

  document.addEventListener('keydown', (e) => {
    if (modal && modal.style.display !== 'none') {
      if (e.key === 'Escape') {
        closeDialog();
      } else if (e.key === 'Tab') {
        trapFocusInDialog(modal, e);
      }
    }
  });
}

function openConfirmDialog(title, message, onConfirm) {
  confirmLastFocusedElement = document.activeElement;
  confirmDialogCallback = onConfirm;

  const modal = document.getElementById('confirm-modal');
  const titleEl = document.getElementById('confirm-modal-title');
  const msgEl = document.getElementById('confirm-modal-msg');
  const okBtn = document.getElementById('confirm-ok-btn');

  if (titleEl) titleEl.textContent = title;
  if (msgEl) msgEl.textContent = message;

  if (modal) {
    modal.style.display = 'flex';
    modal.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
    if (okBtn) okBtn.focus();
  }
}

/* ==========================================================================
   UTILITY & TOAST NOTIFICATION CENTER
   ========================================================================== */
function formatCurrency(amount) {
  const num = Number(amount) || 0;
  return '₱' + num.toLocaleString('en-PH', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}

function formatDate(dateStr) {
  if (!dateStr) return '';
  try {
    const parts = dateStr.split('-');
    if (parts.length === 3) {
      const date = new Date(parts[0], parts[1] - 1, parts[2]);
      return date.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric'
      });
    }
  } catch (e) {
    // fallback
  }
  return dateStr;
}

function escapeHTML(str) {
  if (!str) return '';
  return str.replace(/[&<>'"]/g, tag => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    "'": '&#39;',
    '"': '&quot;'
  }[tag] || tag));
}

/**
 * Toast notification capped at 1–2 items, positioned away from content,
 * supporting Undo action and free of emojis.
 */
function showToast(message, type = 'info', enableUndo = false) {
  const container = document.getElementById('toast-container');
  if (!container) return;

  // Capped at 1-2 toasts: dismiss the oldest toast if count >= 2
  while (container.children.length >= 2) {
    container.removeChild(container.firstChild);
  }

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;

  const msgSpan = document.createElement('span');
  msgSpan.className = 'toast-msg';
  msgSpan.textContent = message;
  toast.appendChild(msgSpan);

  if (enableUndo) {
    const undoBtn = document.createElement('button');
    undoBtn.type = 'button';
    undoBtn.className = 'toast-undo-btn';
    undoBtn.textContent = 'Undo';
    undoBtn.addEventListener('click', () => {
      undoDeleteStop();
      if (toast.parentElement) toast.parentElement.removeChild(toast);
    });
    toast.appendChild(undoBtn);
  }

  container.appendChild(toast);

  const duration = enableUndo ? 4500 : 2800;

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    setTimeout(() => {
      if (toast.parentElement) toast.parentElement.removeChild(toast);
    }, 250);
  }, duration);
}

/* ==========================================================================
   ENTRY POINT
   ========================================================================== */
document.addEventListener('DOMContentLoaded', init);
