# Lakbay: Baguio City Travel Destination Explorer & Itinerary Planner System

> **Course**: ITP10 | Event-Driven Programming  
> **Institution**: Universidad de Dagupan - School of Information Technology Education  
> **Architecture**: Single Page Application (SPA) using Semantic HTML5, CSS3, and Vanilla JavaScript  
> **Visual Theme**: Deep Spruce & Ambient Sage Mist (`#10352b` / `#b8d4c8` / Frosted Glass)

---

## 🌲 Project Overview

**Lakbay** is an interactive, event-driven Single Page Application (SPA) designed to help travelers discover tourist attractions across **Baguio City** (The Summer Capital of the Philippines), organize step-by-step travel schedules, and estimate travel expenses with real-time budget calculations.

All user data (itinerary stops and budget estimates) seamlessly persists in the browser via `localStorage`, with defensive isolated `try/catch` wrappers and schema shape validation to ensure plans survive page refreshes and never crash the app.

---

## 🚀 How to Run the Application

### Option A: Via Local Browser (Direct Open)
1. Navigate to the project directory: `c:\xampp\htdocs\LAKBAY-5`
2. Open [index.html](file:///c:/xampp/htdocs/LAKBAY-5/index.html) in any modern browser (Google Chrome, Microsoft Edge, Mozilla Firefox, or Brave).

### Option B: Via XAMPP Apache Server
1. Open the **XAMPP Control Panel**.
2. Start the **Apache** module.
3. Open your browser and navigate to:
   ```
   http://localhost/LAKBAY-5/
   ```

---

## 📱 Navigation & Application Screens

### 0. Left-Side Navigation Bar (ANI-12 Style Layout)
- Fixed left sidebar navigation featuring a deep spruce container (`#10352b`), floating pure white active pill (`#ffffff` with dark spruce text and soft drop shadow), SVG icons, and a bottom "Plan Trip" shortcut pill.
- Smoothly transforms into a horizontal touch-scrolling header on mobile devices (tested down to 360px).

### 1. Screen 1 · Home Dashboard (`#section-home`)
- **Hero Banner**: Atmospheric mountain photography, "The Summer Capital of the Philippines" badge, and quick action buttons.
- **Side-by-Side Grid**:
  - *Welcome Spotlight*: Overview of Baguio's 1,500m elevation, cool mountain climate, and quick links.
  - *Trip Planning Progress Card*: Live 2-step checklist tracking Budget estimated and Itinerary stops scheduled with an animated percentage progress track.
- **Featured Destinations**: Hand-picked popular destinations with quick-add to itinerary and interactive carousel pagination dots.
- **Travel Recommendations**: Curated mountain travel tips (weather, morning traffic, dining specialties).

### 2. Screen 2 · Explore Gallery (`#section-explore`)
- **Live Search**: Instant keyword filtering across destination names, areas, descriptions, and activities.
- **Category Chips**: Filter by `All`, `Nature & Parks`, `Culture & Heritage`, `Food & Shopping`, `Viewpoints`, and `Museums & Arts`.
- **Fee Filter Chips**: Filter by `All`, `Free Only`, `Under ₱50`, `Under ₱100`.
- **Rating Filter**: Multi-attribute dropdown for `Any Rating`, `★ 4.7 & up`, and `★ 4.8 & up`.
- **Sort Dropdown**: Sort by Name (A-Z, Z-A), Rating (High to Low), or Entrance Fee (Low to High, High to Low).
- **Interactive Baguio Map View**: Toggleable Leaflet/OpenStreetMap embed displaying all 20 Baguio destinations with custom clickable popups.
- **SessionStorage Persistence**: Active filter preferences are saved in `sessionStorage` so refreshing or switching screens preserves your search.

### 3. Screen 3 · Destination Details Modal (`#destination-modal`)
- Accessible modal dialog with focus trap and focus restoration on close.
- Displays high-resolution photography, category, entrance fee, rating, and location.
- **New Detailed Metadata**:
  - 📍 **Area Cluster**: Downtown / Burnham, Mines View Ridge, Session Road, Camp John Hay, etc.
  - 🕒 **Operating Hours**: Exact daily schedules.
  - 🌅 **Best Time to Visit**: Advice on morning mist, avoiding family crowds, and sunset viewpoints.
  - 🚌 **How to Get There**: Practical jeepney and walking directions.
  - 💡 **Local Baguio Tip**: Insider advice (e.g. rent paddleboats early, try hot strawberry taho).
  - 🗺️ **Open in Google Maps**: Direct external navigation link.
- Action buttons: "Add to itinerary", Close (`&times;`), and `Escape` key shortcut.

### 4. Screen 4 · Travel Itinerary Planner with Integrated Budget Planning (`#section-itinerary`)
- **Step 1: Budget Range Selection Before Planning (View A)**:
  - Interactive dual-range slider for minimum and maximum travel budget in Philippine Pesos (₱500 – ₱25,000).
  - Quick preset chips: *Backpacker* (₱1,500 – ₱3,500), *Standard* (₱3,500 – ₱8,000), and *Comfort* (₱8,000 – ₱18,000).
  - Two-way bound numerical input fields and active highlight slider track.
  - Live per-day rate computation (`Est. ₱X – ₱Y per day for N days`).
  - Confirmation button: *"Confirm Budget & Start Planning Itinerary &rarr;"*.
- **Step 2: Travaa-Style Timeline Planner (View B - Strictly No Map)**:
  - **Top Health Toolbar**:
    - Budget Pill showing selected target budget range (`₱min – ₱max`).
    - Live health metrics: *Total Estimated Spent*, *Remaining Budget*, and Status Pill (`✓ Within Budget`, `⚠️ Approaching Limit`, `🚨 Over Budget`).
    - Dynamic budget utilization mini-progress bar.
    - Day management: `+ Add Day` and `− Remove Day` (with safe confirmation if stops exist).
    - `📊 Budget Summary` toggle for the integrated collapsible breakdown drawer.
  - **Integrated Collapsible Budget Drawer**:
    - Editable category cards: *Transportation*, *Accommodation*, *Food & Meals*, *Other/Pasalubong*.
    - Auto-computed *Destination Fees* dynamically summed from all planned stops.
    - **Real-time Over-Budget Alert Banner**: Appears when planned expenses exceed the maximum budget, showing exact overage amount and 1-click recommendations for highly-rated free Baguio attractions (e.g. Burnham Park, Wright Park, Session Road).
  - **Chronological Timeline Grid**:
    - Day rows with date stamps, area tags, and 16 hourly columns (7 AM to 10 PM).
    - Stop blocks colored by attraction category with start/end time ranges and photo thumbnails.
    - Drag-to-resize duration handle (adjusts duration on the fly).
    - Inline slot click: Click any empty hour slot to drop a draft activity block (`"click activity here"`) and immediately focus the inspector search.
    - Empty day prompt: Inviting empty slot banner when a day has 0 stops.
    - **Schedule Clash & Overlap Detection**: Detects overlapping stops on the same day, highlights clashing blocks with an amber warning outline and `⚠️` badge, and displays an explicit clash warning in the Stop Inspector.
  - **Right Stop Inspector Panel**:
    - Top search input with live autocomplete dropdown displaying thumbnail, area, fee, and real-time budget compatibility tags (`Free Entry`, `₱X · Fits Budget`, `₱X · Over Remaining`).
    - Destination photo banner, editable notes/description, website external link, address, phone number, and opening hours.
    - Timing inputs: Start time, duration dropdown (30m, 45m, 1h, 1.5h, 2h, 3h, 4h), and auto-computed end time.
    - Actions: `Save`, `Remove`, and `Google Maps` navigation link.
  - **Sample Plan & Export**:
    - Sample plan button populates a 2-day budget-conscious Baguio itinerary.
    - Copy Plan outputs formatted text with full budget breakdown, target range, remaining funds, and day-by-day stops.

### 6. Screen 6 · Travel Budget Calculator (`#section-budget`)
- **Automatic Activities Fee Sync**: Entrance fees are computed automatically as `sum(stop.fee) * travelers` after add, edit, delete, undo, clear, or travelers count change.
- **Other Activities & Shopping Field**: Separate input for pasalubong, strawberry treats, and Cordillera weaves so stop entrance fees stay accurate.
- **Accommodation Nights Calculation**: Accurately computes nights as `Math.max(1, days - 1)` with live rate hint: `₱X.XX / night (N night(s) for D day(s))`.
- **Budget Presets**:
  - 🎒 *Backpacker*: ₱1,200/day/traveler (jeepneys, transient rooms, street eats)
  - 🌲 *Standard*: ₱3,200/day/traveler (taxis, 3-star boutique hotel, cafes)
  - ✨ *Comfort*: ₱6,500/day/traveler (private van, Camp John Hay Manor, specialty dining)
- **Visual Comparison Progress Bar**: Live progress bar comparing scheduled stop entrance fees against your allocated activities budget with status badge ("Within Budget" / "Exceeds Budget").

### 7. Screen 7 · Travel Plan Summary (`#section-summary`)
- Compiles trip duration, traveler counts, day-by-day itinerary schedule (with per-day fee subtotals and completed badges), and itemized budget table into a print-ready report.
- Actions: "Copy Plan" (clipboard), "Export JSON" (backup), and "Print / Save PDF" (clean print layout omitting buttons and navigation).

---

## ⚡ Event Map Implementation (Events E1 to E20+)

Every interaction strictly follows Event-Driven Programming standards:

| Event ID | Feature | User Action | DOM Event | JavaScript Handler | Expected Result |
| :---: | :--- | :--- | :---: | :--- | :--- |
| **E1** | App Bootstrap | Load or refresh page | `DOMContentLoaded` | `init()` | Restores `localStorage` and `sessionStorage`, configures date constraints, and renders views. |
| **E2** | Navigation | Click sidebar link or CTA | `click` | `showSection(name)` | Switches active section, updates floating active white pill, updates browser URL hash, closes mobile menu. |
| **E3** | Explore Search | Type keyword in search bar | `input` | `searchInput.addEventListener` | Live filters 20 destinations by name, area, location, description, or activity; updates counter. |
| **E4** | Explore Category | Click category chip | `click` | `categoryChips.addEventListener` | Filters cards by category; highlights active chip; persists preference in `sessionStorage`. |
| **E5** | Explore Price | Click price filter chip | `click` | `priceChips.addEventListener` | Filters by Free, <₱50, <₱100; updates cards gallery and counter. |
| **E6** | Explore Rating | Change rating dropdown | `change` | `filterRating.addEventListener` | Filters for destinations rated ★ 4.7+ or ★ 4.8+. |
| **E8** | Explore Sorting | Change sort dropdown | `change` | `sortDropdown.addEventListener` | Reorders cards alphabetically, by rating, or by entrance fee. |
| **E9** | Interactive Map | Click "Show Map" button | `click` | `mapToggleBtn.addEventListener` | Expands Leaflet map container and plots 20 Baguio GPS pins with custom interactive popups. |
| **E10** | Destination Details | Click "Details" button | `click` | `showDetails(id)` | Opens accessible modal with hours, best time, directions, local tip, and Google Maps link; traps keyboard focus. |
| **E11** | Destination Details | Click Close or press `Esc` | `click`, `keydown` | `closeDetails()` | Closes modal and returns focus to the triggering button. |
| **E13** | Quick-Add Itinerary | Click "+ Itinerary" on card | `click` | `openQuickAddPopover(id)` | Opens lightweight popover to schedule stop with date, time, duration without leaving Explore. |
| **E14** | Itinerary Scheduling | Submit itinerary form | `submit` | `saveItineraryStop()` | Validates inputs, detects time overlaps and distant hops with soft warnings, sorts stops, and auto-syncs budget. |
| **E15** | Itinerary Edit | Click "Edit" on stop card | `click` | `editStop(id)` | Pre-populates form with stop details, duration, time, and switches button to "Update stop". |
| **E16** | Itinerary Delete | Click "Delete" on stop | `click` | `deleteStop(id)` | Removes stop, auto-recalculates budget, and displays toast with a 4.5-second "Undo" button. |
| **E17** | Itinerary Clear All | Click "Clear all" button | `click` | `clearBtn.addEventListener` | Displays custom confirmation dialog; clearing removes all stops and resets budget activities fee. |
| **E18** | Sample Plan Loader | Click "Start with Sample Plan" | `click` | `loadSample1DayPlan()` | Populates 5 iconic Baguio stops on today's date, synchronizes budget fees, and updates progress to 100%. |
| **E19** | Budget Calculator | Input expense or traveler | `input` | `calculateBudget()` | Live recomputes Total, Per-traveler, and accommodation per night (`days - 1`); updates comparison bar. |
| **E20** | Budget Presets | Click Backpacker / Standard / Comfort | `click` | `applyBudgetTier(tier)` | Auto-fills recommended daily rates for transport, lodging, food, and shopping based on days and travelers. |
| **E21** | Plan Export & Share | Click "Copy Plan" / "Export JSON" | `click` | `copyPlanAsText()`, `exportJSON()` | Copies formatted itinerary to clipboard or downloads `.json` file backup. |
| **E22** | Plan Import | Select JSON file | `change` | `importJSON(file)` | Reads file via `FileReader`, validates schema, restores state, and refreshes UI. |

---

## 💾 Defensive LocalStorage & SessionStorage Schema

### LocalStorage (`STORAGE_KEYS`)
```json
{
  "lakbay_itinerary": [
    {
      "id": "e4b52f10-21a4-49c7-9b81-c79a93e501b8",
      "destinationId": 1,
      "destinationName": "Burnham Park",
      "category": "Nature & Parks",
      "fee": 0,
      "date": "2026-11-15",
      "time": "08:00",
      "duration": 90,
      "activity": "Swan boat paddleboating and pine garden stroll"
    }
  ],
  "lakbay_budget": {
    "days": 2,
    "travelers": 2,
    "transportation": 700,
    "accommodation": 1800,
    "food": 1900,
    "activities": 220,
    "extraActivities": 500,
    "total": 5120,
    "perPerson": 2560
  }
}
```

### SessionStorage (`SESSION_KEYS`)
```json
{
  "lakbay_explore_filters": {
    "category": "All",
    "price": "all",
    "rating": "4.7",
    "savedOnly": false,
    "sort": "name-asc"
  }
}
```

---

## 🛡️ Evaluator Defense Test Checklist

Use this 60-second test sequence to verify all grading criteria:

1. **Clean Start**: Open [index.html](file:///c:/xampp/htdocs/LAKBAY-5/index.html) or `http://localhost/LAKBAY-5/`.
2. **Instant Test**: Go to **Itinerary** and click **"🚀 Start with Sample 1-Day Plan"**. Notice 5 stops scheduled, Day 1 grouped with ₱185 fees subtotal, and budget entrance fees automatically calculated!
3. **Clash & Travel Buffer Warning**: In the Itinerary form, schedule a stop on the same date at `08:30` (overlapping with Burnham Park). Observe the soft yellow warning banner: *"Schedule Overlap Notice: overlaps with Burnham Park"*. Notice the stop can still be scheduled.
4. **Budget Auto-Sync**: Go to **Budget**. Notice Activities fee is automatically computed from stops fees × travelers. Change travelers from 1 to 2; notice the fee automatically doubles and updates the live total!
5. **Budget Comparison Bar**: Observe the visual comparison bar indicating whether stop fees are within your activities budget. Click the **"✨ Comfort"** preset button and watch all tiers update instantly.
6. **Past Dates**: Stops with dates prior to today automatically receive a `✓ Completed` badge and can be filtered via the `Completed` tab.
7. **Interactive Map**: In **Explore**, click **"Show Map"** to view all 20 destinations plotted on the Leaflet map with custom interactive detail popups.
8. **Export & Share**: In **Itinerary** or **Summary**, click **"Copy Text"** to copy the formatted schedule, or **"Export"** to save `lakbay-baguio-plan.json`.
9. **Accessibility & Responsive**: Resize your browser window down to `360px`. Notice the sidebar transforms cleanly into a horizontal scroll header without layout clipping or text overlap.
