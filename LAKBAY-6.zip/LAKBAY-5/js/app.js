/**
 * ==============================================================================
 * Lakbay - Baguio City Travel Destination Explorer & Itinerary Planner
 * ==============================================================================
 * Comprehensive Event-Driven Single Page Application (Vanilla JavaScript)
 * Features:
 * - Ambient Sage / Deep Spruce aesthetic with frosted glass components
 * - Safe localStorage persistence & schema validation
 * - Dynamic Day-by-day Itinerary with Duration & non-blocking Clash Warnings
 * - Area-aware distance hop buffer alerts (Downtown, Mines View, Outskirts, etc.)
 * - Past dates completion tracking (✓ Completed badge & filter)
 * - Automatic Stop Entrance Fees synchronization with Budget Calculator
 * - Budget Presets (Backpacker, Standard, Comfort) & Visual Comparison Bar
 * - Interactive Leaflet Baguio Map with 20 destination pins
 * - Export / Import JSON & Copy Plan as text
 * - Quick Sample 1-Day Baguio Plan loader
 * - WCAG AA accessible modal focus traps and keyboard navigation
 */

'use strict';

// Application State Object
const appState = {
  currentSection: 'home',
  activeCategory: 'All',
  priceFilter: 'all', // 'all' | 'free' | '50' | '100'
  ratingFilter: 'all', // 'all' | '4.7' | '4.8'
  searchQuery: '',
  sortOrder: 'name-asc',
  itineraryViewFilter: 'all', // 'all' | 'upcoming' | 'completed'
  itinerary: [], // Array of stop objects: [{ id, destinationId, destinationName, date, time, duration, activity, fee }]
  budget: {
    days: 2,
    travelers: 1,
    transportation: 0,
    accommodation: 0,
    food: 0,
    activities: 0,
    extraActivities: 0,
    total: 0,
    perPerson: 0
  },
  trip: {
    name: 'Baguio Mountain Holiday',
    city: 'Baguio City',
    days: 2,
    startDate: '',
    budgetMin: 1500,
    budgetMax: 3500,
    budgetConfirmed: false
  },
  hasConfirmedBudget: false,
  selectedStopId: null,
  pickerDay: 0,
  pickerTime: '09:00',
  pickerDuration: 90,
  pickerCategory: 'All',
  pickerBudgetFilter: 'all',
  pickerSearchQuery: '',
  modalDestinationId: null,
  editingStopId: null,
  lastDeletedStop: null, // For undo delete
  lastFocusedElement: null, // For accessible focus return
  mapInstance: null,
  mapMarkers: []
};

// Storage Keys
const STORAGE_KEYS = {
  ITINERARY: 'lakbay_itinerary',
  BUDGET: 'lakbay_budget',
  TRIP: 'lakbay_trip'
};

const SESSION_KEYS = {
  FILTER_PREFS: 'lakbay_explore_filters'
};

/* ==========================================================================
   INITIALIZATION & DATA RESTORATION (DOMContentLoaded)
   ========================================================================== */
function init() {
  // 1. Restore persistent user data from localStorage with isolated try/catch
  loadData();
  loadFilterPrefs();

  // 2. Setup Navigation and Section Switching Listeners
  setupNavigation();

  // 3. Populate Itinerary Destination Dropdown
  populateDestinationSelect();

  // 4. Configure Minimum Dates
  setupDateConstraints();

  // 5. Render Initial Views
  renderHomeProgress();
  renderFeaturedDestinations();
  renderExploreGallery();
  renderItineraryList();

  // 6. Setup Explore Controls, Search, Filter, Price, Rating, Sort
  setupExploreControls();
  setupHomeQuickPlanner();
  setupFeaturedCarousel();

  // 7. Setup Modal and Confirmation Dialog Listeners
  setupModalControls();
  setupConfirmDialog();
  setupQuickAddPopover();

  // 8. Setup Itinerary Form Listeners
  setupItineraryControls();
  setupDestinationDropdown();

  // 9. Setup Summary Actions (Print, Export, Copy)
  setupSummaryControls();

  // Check URL Hash for deep linking (e.g. #summary or #explore)
  handleInitialHash();
}

/* ==========================================================================
   SAFE LOCALSTORAGE PERSISTENCE (Isolated Try/Catch & Shape Validation)
   ========================================================================== */
function loadData() {
  // Cleanup: remove leftover favorites data from older versions
  try {
    localStorage.removeItem('lakbay_favorites');
  } catch (err) {
    // ignore
  }

  // 2. Itinerary: validate array, drop orphaned stops with nonexistent destinationId
  try {
    const savedItinerary = localStorage.getItem(STORAGE_KEYS.ITINERARY);
    if (savedItinerary) {
      const parsed = JSON.parse(savedItinerary);
      if (Array.isArray(parsed)) {
        appState.itinerary = parsed
          .filter(stop => {
            if (!stop || typeof stop !== 'object') return false;
            const destId = Number(stop.destinationId);
            return sampleDestinations.some(d => d.id === destId) && stop.date && stop.time;
          })
          .map(stop => {
            const destObj = sampleDestinations.find(d => d.id === Number(stop.destinationId));
            return {
              id: String(stop.id || generateUniqueId()),
              destinationId: Number(stop.destinationId),
              destinationName: destObj ? destObj.name : (stop.destinationName || 'Destination'),
              category: destObj ? destObj.category : (stop.category || ''),
              fee: destObj ? destObj.fee : (Number(stop.fee) || 0),
              date: String(stop.date),
              time: String(stop.time),
              duration: Math.max(15, parseInt(stop.duration, 10) || 90),
              activity: String(stop.activity || '')
            };
          });
      }
    }
  } catch (err) {
    console.warn('[Lakbay] Invalid itinerary data in storage. Resetting.', err);
    appState.itinerary = [];
  }

  // 3. Budget: validate object and sanitize numbers
  try {
    const savedBudget = localStorage.getItem(STORAGE_KEYS.BUDGET);
    if (savedBudget) {
      const parsed = JSON.parse(savedBudget);
      if (parsed && typeof parsed === 'object') {
        appState.budget = {
          days: Math.max(1, parseInt(parsed.days, 10) || 1),
          travelers: Math.max(1, parseInt(parsed.travelers, 10) || 1),
          transportation: Math.max(0, parseFloat(parsed.transportation) || 0),
          accommodation: Math.max(0, parseFloat(parsed.accommodation) || 0),
          food: Math.max(0, parseFloat(parsed.food) || 0),
          activities: Math.max(0, parseFloat(parsed.activities) || 0),
          extraActivities: Math.max(0, parseFloat(parsed.extraActivities) || 0),
          total: Math.max(0, parseFloat(parsed.total) || 0),
          perPerson: Math.max(0, parseFloat(parsed.perPerson) || 0)
        };
      }
    }
  } catch (err) {
    console.warn('[Lakbay] Invalid budget data in storage. Resetting.', err);
  }

    // 4. Load Trip Setup / Budget Range
  try {
    const savedTrip = localStorage.getItem(STORAGE_KEYS.TRIP);
    if (savedTrip) {
      const parsed = JSON.parse(savedTrip);
      if (parsed && typeof parsed === 'object') {
        const bMin = Math.max(500, parseInt(parsed.budgetMin, 10) || 1500);
        const bMax = Math.max(bMin, parseInt(parsed.budgetMax, 10) || 3500);
        const days = Math.max(1, parseInt(parsed.days, 10) || 2);
        const confirmed = Boolean(parsed.budgetConfirmed);
        appState.trip = {
          name: parsed.name ? String(parsed.name).trim() : 'Baguio Mountain Holiday',
          city: parsed.city ? String(parsed.city).trim() : 'Baguio City',
          days: days,
          startDate: parsed.startDate || getTodayDateString(),
          budgetMin: bMin,
          budgetMax: bMax,
          budgetConfirmed: confirmed
        };
        appState.hasConfirmedBudget = confirmed;
      }
    }
  } catch (err) {
    console.warn('[Lakbay] Invalid trip data in storage. Resetting.', err);
  }
}

function saveData() {
  try {
    localStorage.setItem(STORAGE_KEYS.ITINERARY, JSON.stringify(appState.itinerary));
    localStorage.setItem(STORAGE_KEYS.BUDGET, JSON.stringify(appState.budget));
    localStorage.setItem(STORAGE_KEYS.TRIP, JSON.stringify(appState.trip));
    renderHomeProgress();
  } catch (err) {
    console.error('[Lakbay] Error saving data to localStorage:', err);
  }
}

/* SessionStorage for Filter Preferences */
function saveFilterPrefs() {
  try {
    const prefs = {
      category: appState.activeCategory,
      price: appState.priceFilter,
      rating: appState.ratingFilter,
      sort: appState.sortOrder
    };
    sessionStorage.setItem(SESSION_KEYS.FILTER_PREFS, JSON.stringify(prefs));
  } catch (e) {
    // SessionStorage unavailable or restricted
  }
}

function loadFilterPrefs() {
  try {
    const raw = sessionStorage.getItem(SESSION_KEYS.FILTER_PREFS);
    if (raw) {
      const p = JSON.parse(raw);
      if (p.category) appState.activeCategory = p.category;
      if (p.price) appState.priceFilter = p.price;
      if (p.rating) appState.ratingFilter = p.rating;
      if (p.sort) appState.sortOrder = p.sort;
    }
  } catch (e) {
    // ignore
  }
}

/* ==========================================================================
   HELPERS (Escaping, Unique IDs, Time & Date)
   ========================================================================== */
function generateUniqueId() {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return 'id-' + Date.now().toString(36) + '-' + Math.random().toString(36).substring(2, 9);
}

function escapeHTML(str) {
  const s = String(str ?? '');
  return s.replace(/[&<>'"]/g, tag => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    "'": '&#39;',
    '"': '&quot;'
  }[tag] || tag));
}

function timeToMinutes(timeStr) {
  if (!timeStr) return 0;
  const parts = String(timeStr).split(':');
  const h = parseInt(parts[0], 10) || 0;
  const m = parseInt(parts[1], 10) || 0;
  return h * 60 + m;
}

function minutesToTime(totalMins) {
  const h = Math.floor(totalMins / 60) % 24;
  const m = totalMins % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

function formatTime12h(timeStr) {
  if (!timeStr) return '';
  const parts = String(timeStr).split(':');
  let h = parseInt(parts[0], 10) || 0;
  const m = parseInt(parts[1], 10) || 0;
  const ampm = h >= 12 ? 'PM' : 'AM';
  h = h % 12;
  if (h === 0) h = 12;
  return `${h}:${String(m).padStart(2, '0')} ${ampm}`;
}

function getDateForDay(startDateStr, dayIndex) {
  if (!startDateStr) startDateStr = getTodayDateString();
  const parts = String(startDateStr).split('-');
  const d = new Date(parts[0], parts[1] - 1, parts[2]);
  d.setDate(d.getDate() + (parseInt(dayIndex, 10) || 0));
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function formatDayCellDate(dateStr) {
  if (!dateStr) return { dayOfMonth: '1', monthShort: 'DAY', weekDayShort: 'TODAY' };
  try {
    const parts = String(dateStr).split('-');
    const d = new Date(parts[0], parts[1] - 1, parts[2]);
    const dayOfMonth = d.getDate();
    const monthShort = d.toLocaleDateString('en-US', { month: 'short' }).toUpperCase();
    const weekDayShort = d.toLocaleDateString('en-US', { weekday: 'short' }).toUpperCase();
    return { dayOfMonth, monthShort, weekDayShort };
  } catch (e) {
    return { dayOfMonth: '1', monthShort: 'DAY', weekDayShort: 'TODAY' };
  }
}

function getTodayDateString() {
  const today = new Date();
  const year = today.getFullYear();
  const month = String(today.getMonth() + 1).padStart(2, '0');
  const day = String(today.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function isPastDate(dateStr) {
  if (!dateStr) return false;
  return dateStr < getTodayDateString();
}

function formatDate(dateStr) {
  if (!dateStr) return '';
  try {
    const parts = dateStr.split('-');
    if (parts.length === 3) {
      const date = new Date(parts[0], parts[1] - 1, parts[2]);
      return date.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric'
      });
    }
  } catch (e) {
    // fallback
  }
  return dateStr;
}

function formatCurrency(amount) {
  const num = Number(amount) || 0;
  return '₱' + num.toLocaleString('en-PH', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}

function formatNumber(amount) {
  const num = Number(amount) || 0;
  return num.toLocaleString('en-PH', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}

function populateDestinationSelect() {
  const select = document.getElementById('itinerary-destination');
  if (!select) return;
  select.innerHTML = '<option value="">-- Choose a Destination --</option>' +
    sampleDestinations.map(d => `<option value="${d.id}">${escapeHTML(d.name)}</option>`).join('');
}

function setupDateConstraints() {
  const todayStr = getTodayDateString();
  const dateInput = document.getElementById('itinerary-date');
  const quickDateInput = document.getElementById('quick-add-date');
  const tripStartDateInput = document.getElementById('trip-setup-start-date');

  if (tripStartDateInput) {
    tripStartDateInput.min = todayStr;
    if (!tripStartDateInput.value) {
      tripStartDateInput.value = appState.trip.startDate || todayStr;
    }
  }

  if (dateInput) {
    dateInput.min = todayStr;
    if (!dateInput.value) {
      dateInput.value = todayStr;
    }
  }

  if (quickDateInput) {
    quickDateInput.min = todayStr;
    if (!quickDateInput.value) {
      quickDateInput.value = todayStr;
    }
  }
}

/* ==========================================================================
   NAVIGATION & SECTION SWITCHING (ANI-12 Left Sidebar Layout)
   ========================================================================== */
function setupNavigation() {
  const navContainer = document.getElementById('main-nav');
  const mobileToggle = document.getElementById('mobile-toggle');

  // Event Delegation for nav-items and data-section buttons
  document.addEventListener('click', (e) => {
    const navBtn = e.target.closest('[data-section]');
    if (navBtn) {
      const section = navBtn.getAttribute('data-section');
      if (section) {
        showSection(section);
      }
    }
  });

  // Mobile toggle
  if (mobileToggle) {
    mobileToggle.addEventListener('click', () => {
      if (navContainer) {
        navContainer.classList.toggle('nav-open');
      }
    });
  }

  // Close mobile nav on resize
  window.addEventListener('resize', () => {
    if (window.innerWidth > 900 && navContainer && navContainer.classList.contains('nav-open')) {
      navContainer.classList.remove('nav-open');
    }
  });

  // Popstate hash change
  window.addEventListener('hashchange', () => {
    const hash = window.location.hash.replace('#', '');
    if (hash) {
      showSection(hash, false);
    }
  });
}

function showSection(sectionId, updateHash = true) {
  const validSections = ['home', 'explore', 'itinerary', 'budget', 'summary'];
  const targetId = validSections.includes(sectionId) ? sectionId : 'home';

  // Hide all screens
  document.querySelectorAll('.app-screen').forEach(screen => {
    screen.classList.remove('active');
  });

  // Show target screen
  const targetScreen = document.getElementById(`section-${targetId}`);
  if (targetScreen) {
    targetScreen.classList.add('active');
  }

  // Update active state in sidebar nav items
  document.querySelectorAll('.sidebar .nav-item').forEach(item => {
    item.classList.toggle('active', item.getAttribute('data-section') === targetId);
  });

  appState.currentSection = targetId;

  if (updateHash) {
    history.replaceState(null, '', `#${targetId}`);
  }

  // Close mobile navigation drawer if open
  const navContainer = document.getElementById('main-nav');
  if (navContainer && navContainer.classList.contains('nav-open')) {
    navContainer.classList.remove('nav-open');
  }

  // Section-specific triggers
  if (targetId === 'summary') {
    buildSummary();
  } else if (targetId === 'explore') {
    renderExploreGallery();
  } else if (targetId === 'itinerary') {
    renderItineraryList();
  }

  // Scroll viewport smoothly to top
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function handleInitialHash() {
  const hash = window.location.hash.replace('#', '');
  if (hash) {
    showSection(hash, false);
  }
}

/* ==========================================================================
   SCREEN 1: HOME (Dashboard, Stats, Progress, Carousel)
   ========================================================================== */
function renderHomeProgress() {
  const hasBudget = appState.hasConfirmedBudget;
  const stopCount = appState.itinerary.length;

  let completedSteps = 0;
  if (hasBudget) completedSteps++;
  if (stopCount > 0) completedSteps++;

  const percentage = Math.round((completedSteps / 2) * 100);

  const percentLabel = document.getElementById('hero-progress-percent');
  const progressBar = document.getElementById('hero-progress-bar');
  const stepBudget = document.getElementById('step-budget');
  const stepStops = document.getElementById('step-stops');

  const stepBudgetStatus = document.getElementById('step-budget-status');
  const stepStopsStatus = document.getElementById('step-stops-status');

  const nextStepText = document.getElementById('hero-next-step-text');
  const nextStepBtn = document.getElementById('hero-next-step-btn');

  if (percentLabel) percentLabel.textContent = `${percentage}%`;
  if (progressBar) progressBar.style.width = `${percentage}%`;

  if (stepBudget) {
    stepBudget.classList.toggle('completed', hasBudget);
    if (stepBudgetStatus) {
      stepBudgetStatus.textContent = hasBudget ? `₱${formatNumber(appState.trip.budgetMin)} – ₱${formatNumber(appState.trip.budgetMax)}` : 'Not established yet';
    }
  }

  if (stepStops) {
    stepStops.classList.toggle('completed', stopCount > 0);
    if (stepStopsStatus) {
      stepStopsStatus.textContent = stopCount > 0 ? `${stopCount} stop${stopCount === 1 ? '' : 's'} planned` : '0 stops planned';
    }
  }

  // Dynamic next step guidance
  if (nextStepText && nextStepBtn) {
    if (!hasBudget) {
      nextStepText.textContent = 'Establish your estimated travel budget in the Itinerary Planner.';
      nextStepBtn.setAttribute('data-section', 'itinerary');
      nextStepBtn.textContent = 'Set Travel Budget →';
    } else if (stopCount === 0) {
      nextStepText.textContent = 'Organize and schedule your planned stops in Baguio.';
      nextStepBtn.setAttribute('data-section', 'itinerary');
      nextStepBtn.textContent = 'Plan Itinerary →';
    } else {
      nextStepText.textContent = 'Your trip plan is ready! Review and print your summary.';
      nextStepBtn.setAttribute('data-section', 'summary');
      nextStepBtn.textContent = 'View Summary →';
    }
  }
}

function renderFeaturedDestinations() {
  const container = document.getElementById('home-featured-grid');
  if (!container) return;

  const featured = sampleDestinations.filter(d => d.featured).slice(0, 6);
  container.innerHTML = featured.map(dest => createDestinationCardHTML(dest, true)).join('');
}

function setupFeaturedCarousel() {
  const dotsContainer = document.getElementById('featured-carousel-dots');
  if (!dotsContainer) return;

  dotsContainer.addEventListener('click', (e) => {
    const dot = e.target.closest('.carousel-dot');
    if (!dot) return;

    dotsContainer.querySelectorAll('.carousel-dot').forEach(d => {
      d.classList.remove('active');
      d.setAttribute('aria-selected', 'false');
    });

    dot.classList.add('active');
    dot.setAttribute('aria-selected', 'true');

    const page = parseInt(dot.getAttribute('data-page'), 10) || 0;
    const allCards = sampleDestinations.filter(d => d.featured);
    const pageSize = 3;
    const start = (page * pageSize) % allCards.length;
    const sliced = allCards.slice(start, start + pageSize);

    const container = document.getElementById('home-featured-grid');
    if (container) {
      container.innerHTML = sliced.map(dest => createDestinationCardHTML(dest, true)).join('');
    }
  });
}

function setupHomeQuickPlanner() {
  // Quick navigation buttons from Home are handled by global [data-section] listener
}

/* ==========================================================================
   SCREEN 2: EXPLORE (Filtering, Search, Rating, Map View, Cards)
   ========================================================================== */
function setupExploreControls() {
  const searchInput = document.getElementById('search-input');
  const searchClearBtn = document.getElementById('search-clear-btn');
  const chipsContainer = document.getElementById('category-chips-container');
  const priceContainer = document.getElementById('price-filters-container');
  const ratingFilter = document.getElementById('filter-rating');
  const sortDropdown = document.getElementById('sort-dropdown');
  const mapToggleBtn = document.getElementById('btn-toggle-explore-map');
  const clearBtn = document.getElementById('btn-clear-explore-filters');
  const resetBtn = document.getElementById('btn-reset-explore-filters');

  // Restore stored session preferences in UI controls
  if (chipsContainer) {
    chipsContainer.querySelectorAll('.chip').forEach(chip => {
      chip.classList.toggle('active', chip.getAttribute('data-category') === appState.activeCategory);
    });
  }
  if (priceContainer) {
    priceContainer.querySelectorAll('.price-chip').forEach(btn => {
      btn.classList.toggle('active', btn.getAttribute('data-price') === appState.priceFilter);
    });
  }
  if (ratingFilter) {
    ratingFilter.value = appState.ratingFilter || 'all';
  }
  if (sortDropdown) {
    sortDropdown.value = appState.sortOrder || 'name-asc';
  }

  // 1. Search input
  if (searchInput) {
    searchInput.addEventListener('input', () => {
      appState.searchQuery = searchInput.value.trim().toLowerCase();
      if (searchClearBtn) {
        searchClearBtn.style.display = searchInput.value ? 'block' : 'none';
      }
      renderExploreGallery();
    });
  }

  // 2. Search clear button
  if (searchClearBtn) {
    searchClearBtn.addEventListener('click', () => {
      if (searchInput) {
        searchInput.value = '';
        searchInput.focus();
      }
      searchClearBtn.style.display = 'none';
      appState.searchQuery = '';
      renderExploreGallery();
    });
  }

  // 3. Category chips
  if (chipsContainer) {
    chipsContainer.addEventListener('click', (e) => {
      const chip = e.target.closest('.chip');
      if (!chip) return;

      chipsContainer.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
      chip.classList.add('active');

      appState.activeCategory = chip.getAttribute('data-category') || 'All';
      saveFilterPrefs();
      renderExploreGallery();
    });
  }

  // 4. Price filter chips
  if (priceContainer) {
    priceContainer.addEventListener('click', (e) => {
      const priceChip = e.target.closest('.price-chip');
      if (!priceChip) return;

      priceContainer.querySelectorAll('.price-chip').forEach(b => b.classList.remove('active'));
      priceChip.classList.add('active');

      appState.priceFilter = priceChip.getAttribute('data-price') || 'all';
      saveFilterPrefs();
      renderExploreGallery();
    });
  }

  // 5. Rating filter dropdown
  if (ratingFilter) {
    ratingFilter.addEventListener('change', (e) => {
      appState.ratingFilter = e.target.value;
      saveFilterPrefs();
      renderExploreGallery();
    });
  }

  // 7. Sort dropdown
  if (sortDropdown) {
    sortDropdown.addEventListener('change', (e) => {
      appState.sortOrder = e.target.value;
      saveFilterPrefs();
      renderExploreGallery();
    });
  }

  // 8. Map view toggle
  if (mapToggleBtn) {
    mapToggleBtn.addEventListener('click', () => {
      const container = document.getElementById('explore-map-container');
      const textSpan = document.getElementById('btn-toggle-explore-map-text');
      if (!container) return;

      const isHidden = container.style.display === 'none';
      if (isHidden) {
        container.style.display = 'block';
        if (textSpan) textSpan.textContent = 'Hide Map';
        initOrUpdateBaguioMap();
      } else {
        container.style.display = 'none';
        if (textSpan) textSpan.textContent = 'Show Map';
      }
    });
  }

  // 9. Reset and Clear Filters
  const resetAllFilters = () => {
    if (searchInput) searchInput.value = '';
    if (searchClearBtn) searchClearBtn.style.display = 'none';
    appState.searchQuery = '';
    appState.activeCategory = 'All';
    appState.priceFilter = 'all';
    appState.ratingFilter = 'all';
    appState.sortOrder = 'name-asc';

    if (chipsContainer) {
      chipsContainer.querySelectorAll('.chip').forEach(c => {
        c.classList.toggle('active', c.getAttribute('data-category') === 'All');
      });
    }

    if (priceContainer) {
      priceContainer.querySelectorAll('.price-chip').forEach(b => {
        b.classList.toggle('active', b.getAttribute('data-price') === 'all');
      });
    }

    if (ratingFilter) ratingFilter.value = 'all';
    if (sortDropdown) sortDropdown.value = 'name-asc';

    saveFilterPrefs();
    renderExploreGallery();
  };

  if (clearBtn) clearBtn.addEventListener('click', resetAllFilters);
  if (resetBtn) resetBtn.addEventListener('click', resetAllFilters);

  // Gallery Card Event Delegation
  const exploreGrid = document.getElementById('explore-cards-grid');
  if (exploreGrid) {
    exploreGrid.addEventListener('click', handleCardActions);
  }

  const homeGrid = document.getElementById('home-featured-grid');
  if (homeGrid) {
    homeGrid.addEventListener('click', handleCardActions);
  }
}

function handleCardActions(e) {
  // 1. Details Modal
  const detailsBtn = e.target.closest('.btn-show-details');
  if (detailsBtn) {
    e.stopPropagation();
    const id = parseInt(detailsBtn.getAttribute('data-id'), 10);
    showDetails(id);
    return;
  }

  // 2. Quick-Add Popover
  const quickItineraryBtn = e.target.closest('.btn-quick-itinerary');
  if (quickItineraryBtn) {
    e.stopPropagation();
    const id = parseInt(quickItineraryBtn.getAttribute('data-id'), 10);
    openQuickAddPopover(id, quickItineraryBtn);
  }
}

function renderExploreGallery() {
  const grid = document.getElementById('explore-cards-grid');
  const emptyState = document.getElementById('explore-empty-state');
  const countText = document.getElementById('results-count-text');
  if (!grid) return;

  // 1. Category Filter
  let list = sampleDestinations.filter(item => {
    if (appState.activeCategory === 'All') return true;
    return item.category.toLowerCase() === appState.activeCategory.toLowerCase();
  });

  // 2. Price Filter
  if (appState.priceFilter === 'free') {
    list = list.filter(item => item.fee === 0);
  } else if (appState.priceFilter === '50') {
    list = list.filter(item => item.fee <= 50);
  } else if (appState.priceFilter === '100') {
    list = list.filter(item => item.fee <= 100);
  }

  // 3. Rating Filter
  if (appState.ratingFilter === '4.7') {
    list = list.filter(item => item.rating >= 4.7);
  } else if (appState.ratingFilter === '4.8') {
    list = list.filter(item => item.rating >= 4.8);
  }

  // 4. Search Query Filter
  if (appState.searchQuery) {
    const q = appState.searchQuery;
    list = list.filter(item => {
      const matchName = item.name.toLowerCase().includes(q);
      const matchLocation = item.location.toLowerCase().includes(q);
      const matchArea = item.area ? item.area.toLowerCase().includes(q) : false;
      const matchDesc = item.description.toLowerCase().includes(q);
      const matchActivities = item.activities.some(act => act.toLowerCase().includes(q));
      return matchName || matchLocation || matchArea || matchDesc || matchActivities;
    });
  }

  // 6. Sort
  list.sort((a, b) => {
    if (appState.sortOrder === 'name-asc') {
      return a.name.localeCompare(b.name);
    } else if (appState.sortOrder === 'name-desc') {
      return b.name.localeCompare(a.name);
    } else if (appState.sortOrder === 'rating-desc') {
      return b.rating - a.rating;
    } else if (appState.sortOrder === 'fee-asc') {
      return a.fee - b.fee;
    } else if (appState.sortOrder === 'fee-desc') {
      return b.fee - a.fee;
    }
    return 0;
  });

  // 7. Results Counter
  if (countText) {
    countText.textContent = `Showing ${list.length} destination${list.length === 1 ? '' : 's'}`;
  }

  // 8. Output
  if (list.length === 0) {
    grid.innerHTML = '';
    if (emptyState) emptyState.style.display = 'block';
  } else {
    if (emptyState) emptyState.style.display = 'none';
    grid.innerHTML = list.map(dest => createDestinationCardHTML(dest)).join('');
  }
}

function createDestinationCardHTML(dest, isFeatured = false) {
  const isPlanned = appState.itinerary.some(s => s.destinationId === dest.id);

  const categorySlug = dest.category.toLowerCase().replace(/[^a-z0-9]+/g, '-');
  const badgeClass = `badge-${categorySlug}`;
  const feeText = dest.fee === 0 ? 'Free Entry' : `₱${dest.fee}`;

  return `
    <article class="destination-card" data-id="${dest.id}">
      <div class="card-image-wrap">
        <img 
          src="${escapeHTML(dest.image)}" 
          alt="${escapeHTML(dest.name)}" 
          class="card-img" 
          loading="lazy"
          onerror="this.src='assets/images/burnham-park.jpg'"
        >
        ${isPlanned ? `<span class="card-planned-indicator"><svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"></polyline></svg> In itinerary</span>` : ''}
      </div>
      <div class="card-content">
        <div class="card-meta-row">
          <div class="card-meta-badges">
            <span class="badge ${badgeClass}">${escapeHTML(dest.category)}</span>
            <span class="badge rating-badge">
              <svg viewBox="0 0 24 24" width="12" height="12" fill="#f59e0b" stroke="#f59e0b"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
              ${dest.rating}
            </span>
          </div>
          <span class="card-fee-text ${dest.fee === 0 ? '' : 'card-fee-highlight'}">${feeText}</span>
        </div>
        <h3 class="card-title">${escapeHTML(dest.name)}</h3>
        <p class="card-location">
          <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
          <span>${escapeHTML(dest.area || dest.location)}</span>
        </p>
        <p class="card-desc">${dest.description ? escapeHTML(dest.description.substring(0, 85)) + '...' : ''}</p>
        <div class="card-actions">
          <button type="button" class="btn btn-outline btn-sm btn-show-details" data-id="${dest.id}">
            Details
          </button>
          <button type="button" class="btn btn-primary btn-sm btn-quick-itinerary ${isPlanned ? 'btn-outline' : ''}" data-id="${dest.id}">
            ${isPlanned ? 'Added' : '+ Itinerary'}
          </button>
        </div>
      </div>
    </article>
  `;
}

/* ==========================================================================
   INTERACTIVE BAGUIO LEAFLET MAP
   ========================================================================== */
function initOrUpdateBaguioMap() {
  const mapEl = document.getElementById('baguio-map');
  if (!mapEl) return;

  if (typeof L === 'undefined') {
    mapEl.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:center;height:100%;padding:2rem;text-align:center;color:#10352b;background:rgba(255,255,255,0.75);">
        <div>
          <h4 style="margin-bottom:0.4rem;font-weight:800;">📍 Baguio City Tourist Map</h4>
          <p style="font-size:0.9rem;color:#38554d;max-width:420px;margin:0 auto 0.75rem;">
            To view live interactive map tiles, connect to the internet. All 20 Baguio destinations have precise GPS coordinates configured!
          </p>
          <p style="font-size:0.85rem;color:#5f7e75;">
            You can also click "Open in Google Maps" inside any destination details modal.
          </p>
        </div>
      </div>
    `;
    return;
  }

  if (!appState.mapInstance) {
    appState.mapInstance = L.map('baguio-map').setView([16.4124, 120.5937], 13);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; OpenStreetMap contributors'
    }).addTo(appState.mapInstance);
  }

  // Clear existing markers
  appState.mapMarkers.forEach(m => appState.mapInstance.removeLayer(m));
  appState.mapMarkers = [];

  // Plot all 20 destinations
  sampleDestinations.forEach(dest => {
    if (!dest.lat || !dest.lng) return;
    const isPlanned = appState.itinerary.some(s => s.destinationId === dest.id);
    const marker = L.marker([dest.lat, dest.lng]).addTo(appState.mapInstance);

    const popupHtml = `
      <div class="map-popup-wrap">
        <strong class="map-popup-title">${escapeHTML(dest.name)}</strong>
        <span class="map-popup-meta">${escapeHTML(dest.category)} · ${dest.fee === 0 ? 'Free' : '₱' + dest.fee}</span>
        <span class="map-popup-meta">📍 ${escapeHTML(dest.area || dest.location)}</span>
        <button type="button" class="map-popup-btn" onclick="showDetails(${dest.id})">
          ${isPlanned ? 'View Stop Details' : 'View Details'}
        </button>
      </div>
    `;
    marker.bindPopup(popupHtml);
    appState.mapMarkers.push(marker);
  });

  setTimeout(() => {
    if (appState.mapInstance) {
      appState.mapInstance.invalidateSize();
    }
  }, 250);
}

/* ==========================================================================
   SCREEN 3: DESTINATION DETAILS MODAL (Focus Trap & Information Rich)
   ========================================================================== */
function setupModalControls() {
  const modal = document.getElementById('destination-modal');
  const closeBtn = document.getElementById('modal-close-btn');
  const backdrop = document.getElementById('modal-backdrop');
  const itineraryBtn = document.getElementById('modal-itinerary-btn');

  if (closeBtn) closeBtn.addEventListener('click', closeDetails);
  if (backdrop) backdrop.addEventListener('click', closeDetails);

  // Accessible Escape & Focus Trap
  document.addEventListener('keydown', (e) => {
    if (modal && modal.style.display !== 'none') {
      if (e.key === 'Escape') {
        closeDetails();
        return;
      }
      if (e.key === 'Tab') {
        trapFocusInDialog(modal, e);
      }
    }
  });

  // Modal Add to Itinerary
  if (itineraryBtn) {
    itineraryBtn.addEventListener('click', () => {
      if (appState.modalDestinationId !== null) {
        const destId = appState.modalDestinationId;
        closeDetails();
        prefillItineraryForm(destId);
      }
    });
  }
}

function trapFocusInDialog(dialogElement, e) {
  const focusable = dialogElement.querySelectorAll(
    'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
  );
  if (focusable.length === 0) return;

  const first = focusable[0];
  const last = focusable[focusable.length - 1];

  if (e.shiftKey) {
    if (document.activeElement === first) {
      last.focus();
      e.preventDefault();
    }
  } else {
    if (document.activeElement === last) {
      first.focus();
      e.preventDefault();
    }
  }
}

function showDetails(id) {
  const dest = sampleDestinations.find(d => d.id === id);
  if (!dest) return;

  appState.lastFocusedElement = document.activeElement;
  appState.modalDestinationId = id;

  const modal = document.getElementById('destination-modal');
  const img = document.getElementById('modal-img');
  const title = document.getElementById('modal-title');
  const categoryBadge = document.getElementById('modal-category');
  const feeBadge = document.getElementById('modal-fee');
  const ratingText = document.getElementById('modal-rating-text');
  const locText = document.getElementById('modal-location-text');
  const desc = document.getElementById('modal-description');
  const activitiesWrap = document.getElementById('modal-activities');
  const areaEl = document.getElementById('modal-area');
  const hoursEl = document.getElementById('modal-hours');
  const bestTimeEl = document.getElementById('modal-best-time');
  const howToGetThereEl = document.getElementById('modal-how-to-get-there');
  const tipEl = document.getElementById('modal-tip');
  const gmapsLink = document.getElementById('modal-gmaps-link');

  if (img) {
    img.src = escapeHTML(dest.image);
    img.alt = escapeHTML(dest.name);
  }
  if (title) title.textContent = dest.name;
  if (locText) locText.textContent = dest.location;
  if (desc) desc.textContent = dest.description;
  if (ratingText) ratingText.textContent = dest.rating;

  if (areaEl) areaEl.textContent = dest.area || 'Baguio City';
  if (hoursEl) hoursEl.textContent = dest.openingHours || 'Open daily';
  if (bestTimeEl) bestTimeEl.textContent = dest.bestTimeToVisit || 'Morning to early afternoon';
  if (howToGetThereEl) howToGetThereEl.textContent = dest.howToGetThere || 'Accessible via jeepney or taxi from downtown Baguio.';
  if (tipEl) tipEl.textContent = dest.tip || 'Bring a light jacket as Baguio temperatures can drop suddenly.';

  if (gmapsLink) {
    gmapsLink.href = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(dest.name + ' Baguio City')}`;
  }

  if (categoryBadge) {
    categoryBadge.textContent = dest.category;
    const categorySlug = dest.category.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    categoryBadge.className = `badge badge-${categorySlug}`;
  }

  if (feeBadge) {
    feeBadge.textContent = dest.fee === 0 ? 'Free Entry' : `Entrance Fee: ₱${dest.fee}`;
  }

  if (activitiesWrap) {
    activitiesWrap.innerHTML = dest.activities
      .map(act => `<span class="activity-tag">${escapeHTML(act)}</span>`)
      .join('');
  }

  if (modal) {
    modal.style.display = 'flex';
    modal.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';

    const closeBtn = document.getElementById('modal-close-btn');
    if (closeBtn) closeBtn.focus();
  }
}

function closeDetails() {
  const modal = document.getElementById('destination-modal');
  if (modal) {
    modal.style.display = 'none';
    modal.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  }
  appState.modalDestinationId = null;

  if (appState.lastFocusedElement && typeof appState.lastFocusedElement.focus === 'function') {
    appState.lastFocusedElement.focus();
  }
}

/* ==========================================================================
   SCREEN 4: ITINERARY PLANNER (Budget Selection & Day-by-Day Timeline)
   ========================================================================== */

const BUDGET_SLIDER_CONFIG = {
  MIN_ALLOWED: 500,
  MAX_ALLOWED: 25000,
  STEP: 100,
  MIN_GAP: 100
};

let stopEditorTargetId = null;
let activeDayFilter = 'all';

/**
 * Main itinerary renderer: toggles between View 1 (Budget Selector) and View 2 (Confirmed Workspace)
 */
function renderItineraryList() {
  const selectorView = document.getElementById('budget-selector-view');
  const confirmedView = document.getElementById('budget-confirmed-view');
  if (!selectorView || !confirmedView) return;

  if (appState.hasConfirmedBudget) {
    selectorView.style.display = 'none';
    confirmedView.style.display = 'block';
    renderItineraryWorkspace();
  } else {
    selectorView.style.display = 'block';
    confirmedView.style.display = 'none';
    syncBudgetInputsFromState();
  }
}

/**
 * Synchronizes inputs and UI elements from current appState.trip
 */
function syncBudgetInputsFromState() {
  const minVal = appState.trip.budgetMin || 1500;
  const maxVal = appState.trip.budgetMax || 3500;
  const daysVal = appState.trip.days || 2;

  const sliderMin = document.getElementById('budget-slider-min');
  const sliderMax = document.getElementById('budget-slider-max');
  const numMin = document.getElementById('budget-num-min');
  const numMax = document.getElementById('budget-num-max');
  const daysInput = document.getElementById('budget-trip-days');

  if (sliderMin) sliderMin.value = minVal;
  if (sliderMax) sliderMax.value = maxVal;
  if (numMin) numMin.value = minVal;
  if (numMax) numMax.value = maxVal;
  if (daysInput) daysInput.value = daysVal;

  updateBudgetCalculations(minVal, maxVal, daysVal);
  updateSliderTrackHighlight(minVal, maxVal);
  highlightMatchingPreset(minVal, maxVal);
}

/**
 * Updates the highlight bar on the dual-range track
 */
function updateSliderTrackHighlight(minVal, maxVal) {
  const highlightBar = document.getElementById('budget-highlight-track');
  if (!highlightBar) return;

  const totalRange = BUDGET_SLIDER_CONFIG.MAX_ALLOWED - BUDGET_SLIDER_CONFIG.MIN_ALLOWED;
  const leftPct = Math.max(0, Math.min(100, ((minVal - BUDGET_SLIDER_CONFIG.MIN_ALLOWED) / totalRange) * 100));
  const widthPct = Math.max(0, Math.min(100 - leftPct, ((maxVal - minVal) / totalRange) * 100));

  highlightBar.style.left = `${leftPct.toFixed(2)}%`;
  highlightBar.style.width = `${widthPct.toFixed(2)}%`;
}

/**
 * Calculates live daily allowance and projected category allocations
 */
function updateBudgetCalculations(minVal, maxVal, days) {
  const safeDays = Math.max(1, parseInt(days, 10) || 1);
  const minDaily = Math.round(minVal / safeDays);
  const maxDaily = Math.round(maxVal / safeDays);

  const dailyEl = document.getElementById('budget-calc-daily');
  const maxEl = document.getElementById('budget-calc-max');
  const lodgingEl = document.getElementById('alloc-lodging');
  const foodEl = document.getElementById('alloc-food');
  const transpoEl = document.getElementById('alloc-transpo');
  const activitiesEl = document.getElementById('alloc-activities');
  const otherEl = document.getElementById('alloc-other');

  if (dailyEl) dailyEl.textContent = `₱${formatNumber(minDaily)} – ₱${formatNumber(maxDaily)} / day`;
  if (maxEl) maxEl.textContent = formatNumber(maxVal);

  if (lodgingEl) lodgingEl.textContent = `₱${formatNumber(Math.round(maxVal * 0.40))}`;
  if (foodEl) foodEl.textContent = `₱${formatNumber(Math.round(maxVal * 0.25))}`;
  if (transpoEl) transpoEl.textContent = `₱${formatNumber(Math.round(maxVal * 0.15))}`;
  if (activitiesEl) activitiesEl.textContent = `₱${formatNumber(Math.round(maxVal * 0.10))}`;
  if (otherEl) otherEl.textContent = `₱${formatNumber(Math.round(maxVal * 0.10))}`;
}

/**
 * Highlights a preset button if current values match
 */
function highlightMatchingPreset(minVal, maxVal) {
  const presetBtns = document.querySelectorAll('#budget-preset-buttons .btn-preset');
  presetBtns.forEach(btn => {
    const pMin = parseInt(btn.getAttribute('data-min'), 10);
    const pMax = parseInt(btn.getAttribute('data-max'), 10);
    if (pMin === minVal && pMax === maxVal) {
      btn.classList.add('active');
    } else {
      btn.classList.remove('active');
    }
  });
}

/**
 * Renders the confirmed workspace: Live budget tracker meter, day tabs, and stops timeline
 */
function renderItineraryWorkspace() {
  const trip = appState.trip;
  const days = trip.days || 2;
  const minBudget = trip.budgetMin || 1500;
  const maxBudget = trip.budgetMax || 3500;
  const stops = appState.itinerary || [];

  // 1. Top Badges & Trip Title
  const tripTitleEl = document.getElementById('confirmed-trip-title');
  const budgetDisplay = document.getElementById('confirmed-budget-display');
  const daysDisplay = document.getElementById('confirmed-days-display');

  if (tripTitleEl) tripTitleEl.textContent = `${trip.city || 'Baguio City'} · ${days} Day${days > 1 ? 's' : ''}`;
  if (budgetDisplay) budgetDisplay.textContent = `₱${formatNumber(minBudget)} – ₱${formatNumber(maxBudget)}`;
  if (daysDisplay) daysDisplay.textContent = `${days} Day${days > 1 ? 's' : ''}`;

  // 2. Budget Utilization Calculations
  const stopsFees = stops.reduce((sum, s) => {
    const d = sampleDestinations.find(dest => dest.id === s.destinationId);
    return sum + (d ? Number(d.fee) || 0 : (Number(s.fee) || 0));
  }, 0);

  const baseLivingCost = Math.round(maxBudget * 0.80);
  const totalPlannedSpent = baseLivingCost + stopsFees;
  const remainingBudget = maxBudget - totalPlannedSpent;

  // Update Tracker Metrics
  const feesEl = document.getElementById('tracker-stops-fees');
  const countEl = document.getElementById('tracker-stops-count');
  const baseEl = document.getElementById('tracker-base-living');
  const remBox = document.getElementById('tracker-remaining-box');
  const remEl = document.getElementById('tracker-remaining-budget');
  const remStatusEl = document.getElementById('tracker-remaining-status');

  if (feesEl) feesEl.textContent = `₱${formatNumber(stopsFees)}`;
  if (countEl) countEl.textContent = `${stops.length} stop${stops.length === 1 ? '' : 's'} planned`;
  if (baseEl) baseEl.textContent = `₱${formatNumber(baseLivingCost)}`;

  if (remEl) {
    if (remainingBudget >= 0) {
      remEl.textContent = `₱${formatNumber(remainingBudget)}`;
      remEl.style.color = '#10352b';
      if (remBox) {
        remBox.style.background = '#f0fdf4';
        remBox.style.borderColor = '#bbf7d0';
      }
      if (remStatusEl) {
        remStatusEl.textContent = 'Within Budget ✓';
        remStatusEl.style.color = '#15803d';
      }
    } else {
      remEl.textContent = `-₱${formatNumber(Math.abs(remainingBudget))}`;
      remEl.style.color = '#b91c1c';
      if (remBox) {
        remBox.style.background = '#fef2f2';
        remBox.style.borderColor = '#fecaca';
      }
      if (remStatusEl) {
        remStatusEl.textContent = 'Over Ceiling ⚠️';
        remStatusEl.style.color = '#b91c1c';
      }
    }
  }

  // Meter Bar
  const meterPercent = Math.min(100, Math.round((totalPlannedSpent / maxBudget) * 100));
  const meterPercentEl = document.getElementById('tracker-meter-percent');
  const meterCeilingEl = document.getElementById('tracker-meter-ceiling');
  const meterFill = document.getElementById('tracker-meter-fill');
  const alertBanner = document.getElementById('tracker-budget-alert');
  const alertMsg = document.getElementById('tracker-alert-message');

  if (meterPercentEl) meterPercentEl.textContent = `${meterPercent}%`;
  if (meterCeilingEl) meterCeilingEl.textContent = `Max Ceiling: ₱${formatNumber(maxBudget)}`;
  if (meterFill) {
    meterFill.style.width = `${meterPercent}%`;
    meterFill.className = 'meter-fill' + (meterPercent >= 100 ? ' overflow' : (meterPercent >= 85 ? ' warning' : ''));
  }

  if (alertBanner) {
    if (remainingBudget < 0) {
      alertBanner.style.display = 'flex';
      if (alertMsg) {
        alertMsg.textContent = `Planned expenses (₱${formatNumber(totalPlannedSpent)}) exceed your ₱${formatNumber(maxBudget)} ceiling by ₱${formatNumber(Math.abs(remainingBudget))}. Consider swapping paid attractions for free favorites like Burnham Park, Wright Park, or The Mansion!`;
      }
    } else {
      alertBanner.style.display = 'none';
    }
  }

  // 3. Render Day Filter Tabs
  renderDayFilterTabs(days);

  // 4. Render Chronological Day-by-Day Timeline
  renderTimelineDays(days, stops);
}

/**
 * Generates Day Tabs ("All Days", "Day 1", "Day 2"...)
 */
function renderDayFilterTabs(daysCount) {
  const tabsContainer = document.getElementById('itinerary-day-tabs');
  if (!tabsContainer) return;

  let tabsHTML = `<button type="button" class="day-tab-pill ${activeDayFilter === 'all' ? 'active' : ''}" data-day="all">All Days (${daysCount})</button>`;
  for (let i = 1; i <= daysCount; i++) {
    const isActive = activeDayFilter === String(i);
    tabsHTML += `<button type="button" class="day-tab-pill ${isActive ? 'active' : ''}" data-day="${i}">Day ${i}</button>`;
  }

  tabsContainer.innerHTML = tabsHTML;

  tabsContainer.querySelectorAll('.day-tab-pill').forEach(btn => {
    btn.addEventListener('click', () => {
      activeDayFilter = btn.getAttribute('data-day');
      renderItineraryWorkspace();
    });
  });
}

/**
 * Calculates day index (1-based) from stop date and trip startDate
 */
function getStopDayIndex(stopDateStr) {
  const startDateStr = appState.trip.startDate || getTodayDateString();
  const start = new Date(startDateStr);
  const stopDate = new Date(stopDateStr);
  const diffDays = Math.floor((stopDate - start) / (1000 * 60 * 60 * 24));
  return Math.max(1, Math.min(appState.trip.days || 2, diffDays + 1));
}

/**
 * Computes calendar date string for Day N
 */
function getDateForDay(dayIndex) {
  const startDateStr = appState.trip.startDate || getTodayDateString();
  const date = new Date(startDateStr);
  date.setDate(date.getDate() + (dayIndex - 1));
  return date.toISOString().split('T')[0];
}

/**
 * Clash detector: identifies overlapping time windows on the same date
 */
function findItineraryClashes(stops) {
  const clashMap = {};
  for (let i = 0; i < stops.length; i++) {
    const s1 = stops[i];
    const start1 = timeToMinutes(s1.time);
    const end1 = start1 + (Number(s1.duration) || 90);

    for (let j = i + 1; j < stops.length; j++) {
      const s2 = stops[j];
      if (s1.date !== s2.date) continue;

      const start2 = timeToMinutes(s2.time);
      const end2 = start2 + (Number(s2.duration) || 90);

      if (start1 < end2 && start2 < end1) {
        clashMap[s1.id] = {
          withName: s2.destinationName || 'Another Stop',
          timeRange: `${s2.time} – ${minutesToTime(end2)}`
        };
        clashMap[s2.id] = {
          withName: s1.destinationName || 'Another Stop',
          timeRange: `${s1.time} – ${minutesToTime(end1)}`
        };
      }
    }
  }
  return clashMap;
}

/**
 * Renders the day sections and timeline stop cards
 */
function renderTimelineDays(daysCount, stops) {
  const container = document.getElementById('itinerary-days-list');
  if (!container) return;

  sortItineraryChronologically();
  const clashesMap = findItineraryClashes(stops);

  let html = '';

  for (let dayNum = 1; dayNum <= daysCount; dayNum++) {
    if (activeDayFilter !== 'all' && activeDayFilter !== String(dayNum)) {
      continue;
    }

    const dayDateStr = getDateForDay(dayNum);
    const formattedDate = formatDate(dayDateStr);

    const dayStops = stops.filter(s => {
      if (s.date === dayDateStr) return true;
      return getStopDayIndex(s.date) === dayNum;
    });

    const dayFeesSum = dayStops.reduce((sum, s) => {
      const d = sampleDestinations.find(dest => dest.id === s.destinationId);
      return sum + (d ? Number(d.fee) || 0 : (Number(s.fee) || 0));
    }, 0);

    const totalMinutes = dayStops.reduce((sum, s) => sum + (Number(s.duration) || 90), 0);
    const hours = Math.floor(totalMinutes / 60);
    const mins = totalMinutes % 60;
    const timeTotalStr = hours > 0 ? `${hours}h ${mins > 0 ? mins + 'm' : ''}` : `${mins}m`;

    html += `
      <section class="itinerary-day-section" data-day="${dayNum}">
        <div class="day-section-header">
          <div class="day-section-title-wrap">
            <h3 class="day-section-title">Day ${dayNum}</h3>
            <span class="day-section-date">· ${formattedDate}</span>
            <div class="day-meta-pills">
              <span class="day-meta-pill">${dayStops.length} Stop${dayStops.length === 1 ? '' : 's'}</span>
              <span class="day-meta-pill">⏱️ ${timeTotalStr}</span>
              <span class="day-meta-pill">🎟️ ${dayFeesSum === 0 ? 'Free Entry' : '₱' + formatNumber(dayFeesSum)}</span>
            </div>
          </div>
          <button type="button" class="day-add-stop-btn" data-day="${dayNum}">
            + Add to Day ${dayNum}
          </button>
        </div>

        <div class="day-stops-list">
    `;

    if (dayStops.length === 0) {
      html += `
        <div class="empty-day-banner">
          <p class="empty-day-text">No planned destinations scheduled for Day ${dayNum} yet.</p>
          <button type="button" class="btn btn-sm btn-outline day-add-stop-btn" data-day="${dayNum}">
            + Add First Stop to Day ${dayNum}
          </button>
        </div>
      `;
    } else {
      dayStops.forEach((stop) => {
        const dest = sampleDestinations.find(d => d.id === stop.destinationId) || {
          name: stop.destinationName || 'Destination',
          category: stop.category || 'Sightseeing',
          fee: stop.fee || 0,
          image: 'assets/images/burnham-park.jpg',
          area: 'Baguio City'
        };

        const duration = Number(stop.duration) || 90;
        const startMins = timeToMinutes(stop.time);
        const endMins = startMins + duration;
        const startTimeStr = stop.time || '09:00';
        const endTimeStr = minutesToTime(endMins);

        const fee = dest.fee || 0;
        const clashInfo = clashesMap[stop.id];

        html += `
          <div class="itinerary-stop-card" data-stop-id="${stop.id}">
            <!-- Time Col -->
            <div class="stop-time-col">
              <span class="stop-time-val">${startTimeStr}</span>
              <span class="stop-time-end">to ${endTimeStr}</span>
              <span class="stop-dur-pill">${duration}m</span>
            </div>

            <!-- Thumbnail -->
            <img src="${dest.image}" alt="${escapeHTML(dest.name)}" class="stop-thumb-img" loading="lazy">

            <!-- Content Col -->
            <div class="stop-info-col">
              <div class="stop-title-row">
                <h4 class="stop-dest-title">${escapeHTML(dest.name)}</h4>
                <span class="${fee > 0 ? 'badge-fee-paid' : 'badge-fee-free'}">
                  ${fee > 0 ? '₱' + formatNumber(fee) : 'Free Entry'}
                </span>
              </div>
              <div class="stop-meta-tags">
                <span class="stop-category-tag">${escapeHTML(dest.category)}</span>
                <span class="stop-area-tag">📍 ${escapeHTML(dest.area || dest.location || 'Baguio')}</span>
              </div>
              ${stop.activity ? `<p class="stop-activity-text">🎯 ${escapeHTML(stop.activity)}</p>` : ''}
              ${clashInfo ? `<div class="stop-clash-warning">⚠️ Overlaps with ${escapeHTML(clashInfo.withName)} (${clashInfo.timeRange})</div>` : ''}
            </div>

            <!-- Actions Col -->
            <div class="stop-actions-col">
              <button type="button" class="btn-icon-action btn-move-stop" data-dir="up" data-stop-id="${stop.id}" title="Move earlier in time">↑</button>
              <button type="button" class="btn-icon-action btn-move-stop" data-dir="down" data-stop-id="${stop.id}" title="Move later in time">↓</button>
              <button type="button" class="btn-icon-action btn-edit-stop" data-stop-id="${stop.id}" title="Edit stop details">✏️</button>
              <button type="button" class="btn-icon-action action-delete btn-delete-stop" data-stop-id="${stop.id}" title="Remove stop">🗑️</button>
            </div>
          </div>
        `;
      });
    }

    html += `
        </div>
      </section>
    `;
  }

  container.innerHTML = html;

  // Attach card event listeners
  container.querySelectorAll('.day-add-stop-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const day = btn.getAttribute('data-day');
      openStopEditor({ day });
    });
  });

  container.querySelectorAll('.btn-edit-stop').forEach(btn => {
    btn.addEventListener('click', () => {
      const stopId = btn.getAttribute('data-stop-id');
      openStopEditor({ stopId });
    });
  });

  container.querySelectorAll('.btn-delete-stop').forEach(btn => {
    btn.addEventListener('click', () => {
      const stopId = btn.getAttribute('data-stop-id');
      deleteStop(stopId);
    });
  });

  container.querySelectorAll('.btn-move-stop').forEach(btn => {
    btn.addEventListener('click', () => {
      const stopId = btn.getAttribute('data-stop-id');
      const dir = btn.getAttribute('data-dir');
      reorderStop(stopId, dir);
    });
  });
}

/**
 * Removes a stop and offers an Undo toast
 */
function deleteStop(stopId) {
  const index = appState.itinerary.findIndex(s => s.id === stopId);
  if (index === -1) return;

  const deleted = appState.itinerary.splice(index, 1)[0];
  appState.lastDeletedStop = deleted;
  saveData();
  renderItineraryWorkspace();

  showToast(`Removed "${deleted.destinationName || 'stop'}".`, 'info', true);
}

/**
 * Undoes previous delete
 */
function undoDeleteStop() {
  if (!appState.lastDeletedStop) return;
  appState.itinerary.push(appState.lastDeletedStop);
  appState.lastDeletedStop = null;
  sortItineraryChronologically();
  saveData();
  renderItineraryWorkspace();
  showToast('Restored stop.', 'success');
}

/**
 * Reorders a stop earlier or later in time
 */
function reorderStop(stopId, direction) {
  const stop = appState.itinerary.find(s => s.id === stopId);
  if (!stop) return;

  const currentMins = timeToMinutes(stop.time);
  const delta = direction === 'up' ? -30 : 30;
  const newMins = Math.max(360, Math.min(1380, currentMins + delta)); // between 06:00 and 23:00

  stop.time = minutesToTime(newMins);
  sortItineraryChronologically();
  saveData();
  renderItineraryWorkspace();
}

/**
 * Loads a curated 2-day Baguio itinerary that fits within the budget
 */
function loadSampleItinerary() {
  const startDate = appState.trip.startDate || getTodayDateString();
  const dateDay1 = getDateForDay(1);
  const dateDay2 = getDateForDay(2);

  appState.trip.days = Math.max(2, appState.trip.days || 2);

  appState.itinerary = [
    // Day 1
    {
      id: generateUniqueId(),
      destinationId: 3, // Wright Park
      destinationName: 'Wright Park',
      category: 'Nature & Parks',
      fee: 0,
      date: dateDay1,
      time: '09:00',
      duration: 60,
      activity: 'Morning stroll along the Pool of Pines'
    },
    {
      id: generateUniqueId(),
      destinationId: 4, // The Mansion
      destinationName: 'The Mansion',
      category: 'Culture & Heritage',
      fee: 0,
      date: dateDay1,
      time: '10:15',
      duration: 45,
      activity: 'Sightseeing at the presidential summer palace gates'
    },
    {
      id: generateUniqueId(),
      destinationId: 2, // Mines View Park
      destinationName: 'Mines View Park',
      category: 'Viewpoints',
      fee: 10,
      date: dateDay1,
      time: '11:30',
      duration: 90,
      activity: 'Panoramic ridge views and buying Good Shepherd strawberry jam'
    },
    {
      id: generateUniqueId(),
      destinationId: 15, // Baguio Night Market (actual ID 15)
      destinationName: 'Baguio Night Market',
      category: 'Food & Shopping',
      fee: 0,
      date: dateDay1,
      time: '21:00',
      duration: 90,
      activity: 'Street food tasting, strawberry taho, and thrift shopping'
    },
    // Day 2
    {
      id: generateUniqueId(),
      destinationId: 1, // Burnham Park
      destinationName: 'Burnham Park',
      category: 'Nature & Parks',
      fee: 0,
      date: dateDay2,
      time: '09:00',
      duration: 90,
      activity: 'Swan paddleboat lagoon rowing and rose garden walk'
    },
    {
      id: generateUniqueId(),
      destinationId: 6, // Camp John Hay (actual ID 6)
      destinationName: 'Camp John Hay',
      category: 'Nature & Parks',
      fee: 80,
      date: dateDay2,
      time: '11:00',
      duration: 120,
      activity: 'Trekking the Yellow Trail and visiting Bell Amphitheater'
    },
    {
      id: generateUniqueId(),
      destinationId: 5, // Baguio Botanical Garden (actual ID 5)
      destinationName: 'Baguio Botanical Garden',
      category: 'Nature & Parks',
      fee: 10,
      date: dateDay2,
      time: '14:30',
      duration: 60,
      activity: 'Exploring Igorot cultural village replicas and indigenous pines'
    }
  ];

  sortItineraryChronologically();
  saveData();
  renderItineraryWorkspace();

  showToast('Loaded sample 2-day Baguio itinerary!', 'success');
}

/**
 * Clears all itinerary stops after user confirmation
 */
function clearItinerary() {
  openConfirmDialog(
    'Clear All Itinerary Stops?',
    'Are you sure you want to remove all planned stops? Your established budget settings will remain intact.',
    () => {
      appState.itinerary = [];
      saveData();
      renderItineraryWorkspace();
      showToast('Itinerary stops cleared.', 'info');
    }
  );
}

/**
 * Setup Stop Editor Modal dialog and controls
 */
function setupStopEditorModal() {
  const modal = document.getElementById('stop-editor-modal');
  const backdrop = document.getElementById('stop-editor-backdrop');
  const closeBtn = document.getElementById('stop-modal-close');
  const cancelBtn = document.getElementById('btn-cancel-stop-modal');
  const form = document.getElementById('stop-editor-form');

  const destSelect = document.getElementById('stop-destination-select');
  const daySelect = document.getElementById('stop-day-select');
  const dateInput = document.getElementById('stop-date-input');
  const timeInput = document.getElementById('stop-time-input');
  const durInput = document.getElementById('stop-duration-input');
  const activityInput = document.getElementById('stop-activity-input');

  const previewStrip = document.getElementById('stop-dest-preview-strip');
  const previewImg = document.getElementById('stop-preview-img');
  const previewName = document.getElementById('stop-preview-name');
  const previewCat = document.getElementById('stop-preview-category');
  const previewFee = document.getElementById('stop-preview-fee');
  const previewArea = document.getElementById('stop-preview-area');

  const suggRow = document.getElementById('stop-activity-suggestions');
  const suggChipsWrap = document.getElementById('stop-suggestions-chips');

  const impactFee = document.getElementById('modal-impact-fee');
  const impactRemaining = document.getElementById('modal-impact-remaining');

  const populateDestPicker = (selectedId = null) => {
    if (!destSelect) return;
    const list = sampleDestinations;

    destSelect.innerHTML = '<option value="">-- Choose a Baguio Destination --</option>' +
      list.map(d => {
        const feeStr = d.fee > 0 ? `₱${d.fee}` : 'Free';
        return `<option value="${d.id}">${escapeHTML(d.name)} (${escapeHTML(d.category)}) — ${feeStr}</option>`;
      }).join('');

    if (selectedId) {
      destSelect.value = selectedId;
    }
  };

  const updateDestPreview = () => {
    const destId = Number(destSelect.value);
    const dest = sampleDestinations.find(d => d.id === destId);
    if (!dest) {
      if (previewStrip) previewStrip.style.display = 'none';
      if (suggRow) suggRow.style.display = 'none';
      if (impactFee) impactFee.textContent = '₱0';
      return;
    }

    if (previewStrip) previewStrip.style.display = 'flex';
    if (previewImg) previewImg.src = dest.image;
    if (previewName) previewName.textContent = dest.name;
    if (previewCat) previewCat.textContent = dest.category;
    if (previewFee) {
      previewFee.textContent = dest.fee > 0 ? `₱${dest.fee}` : 'Free Entry';
      previewFee.className = `badge ${dest.fee > 0 ? 'badge-fee-paid' : 'badge-fee-free'}`;
    }
    if (previewArea) previewArea.textContent = dest.area || dest.location;

    // Suggestions chips
    if (suggRow && suggChipsWrap) {
      if (dest.activities && dest.activities.length) {
        suggRow.style.display = 'flex';
        suggChipsWrap.innerHTML = dest.activities.map(act => `
          <button type="button" class="sugg-chip" data-act="${escapeHTML(act)}">${escapeHTML(act)}</button>
        `).join('');

        suggChipsWrap.querySelectorAll('.sugg-chip').forEach(chip => {
          chip.addEventListener('click', () => {
            activityInput.value = chip.getAttribute('data-act');
          });
        });
      } else {
        suggRow.style.display = 'none';
      }
    }

    // Modal Budget Impact
    const currentFee = dest.fee || 0;
    if (impactFee) impactFee.textContent = currentFee > 0 ? `₱${formatNumber(currentFee)}` : 'Free Entry';

    const maxBudget = appState.trip.budgetMax || 3500;
    const baseCost = Math.round(maxBudget * 0.80);
    const currentStopsFees = appState.itinerary
      .filter(s => s.id !== stopEditorTargetId)
      .reduce((sum, s) => {
        const d = sampleDestinations.find(item => item.id === s.destinationId);
        return sum + (d ? Number(d.fee) || 0 : (Number(s.fee) || 0));
      }, 0);

    const projectedRemaining = maxBudget - (baseCost + currentStopsFees + currentFee);
    if (impactRemaining) {
      impactRemaining.textContent = projectedRemaining >= 0 ? `₱${formatNumber(projectedRemaining)}` : `-₱${formatNumber(Math.abs(projectedRemaining))} (Over Limit)`;
      impactRemaining.style.color = projectedRemaining >= 0 ? '#10352b' : '#b91c1c';
    }
  };

  if (destSelect) {
    destSelect.addEventListener('change', updateDestPreview);
  }

  if (daySelect && dateInput) {
    daySelect.addEventListener('change', () => {
      const dayNum = parseInt(daySelect.value, 10) || 1;
      dateInput.value = getDateForDay(dayNum);
    });

    dateInput.addEventListener('change', () => {
      const dayNum = getStopDayIndex(dateInput.value);
      daySelect.value = String(dayNum);
    });
  }

  const durChips = document.querySelectorAll('.duration-chip');
  durChips.forEach(chip => {
    chip.addEventListener('click', () => {
      durChips.forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      if (durInput) durInput.value = chip.getAttribute('data-dur');
    });
  });

  const closeModal = () => {
    if (modal) modal.style.display = 'none';
    stopEditorTargetId = null;
  };

  if (closeBtn) closeBtn.addEventListener('click', closeModal);
  if (backdrop) backdrop.addEventListener('click', closeModal);
  if (cancelBtn) cancelBtn.addEventListener('click', closeModal);

  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const destId = Number(destSelect.value);
      if (!destId) {
        showToast('Please select a destination.', 'warning');
        return;
      }

      const dest = sampleDestinations.find(d => d.id === destId);
      const scheduledDate = dateInput.value || getDateForDay(1);
      const startTime = timeInput.value || '09:00';
      const duration = Math.max(15, parseInt(durInput.value, 10) || 90);
      const activity = (activityInput.value || '').trim();

      if (stopEditorTargetId) {
        const stop = appState.itinerary.find(s => s.id === stopEditorTargetId);
        if (stop) {
          stop.destinationId = destId;
          stop.destinationName = dest.name;
          stop.category = dest.category;
          stop.fee = dest.fee || 0;
          stop.date = scheduledDate;
          stop.time = startTime;
          stop.duration = duration;
          stop.activity = activity;
          showToast(`Updated "${dest.name}"!`, 'success');
        }
      } else {
        const newStop = {
          id: generateUniqueId(),
          destinationId: destId,
          destinationName: dest.name,
          category: dest.category,
          fee: dest.fee || 0,
          date: scheduledDate,
          time: startTime,
          duration: duration,
          activity: activity
        };
        appState.itinerary.push(newStop);
        showToast(`Added "${dest.name}" to Day ${getStopDayIndex(scheduledDate)}!`, 'success');
      }

      sortItineraryChronologically();
      saveData();
      renderItineraryWorkspace();
      closeModal();
    });
  }
}

/**
 * Opens Stop Editor Modal for adding or editing
 */
function openStopEditor(options = {}) {
  const modal = document.getElementById('stop-editor-modal');
  if (!modal) return;

  const titleEl = document.getElementById('stop-modal-title');
  const destSelect = document.getElementById('stop-destination-select');
  const daySelect = document.getElementById('stop-day-select');
  const dateInput = document.getElementById('stop-date-input');
  const timeInput = document.getElementById('stop-time-input');
  const durInput = document.getElementById('stop-duration-input');
  const activityInput = document.getElementById('stop-activity-input');

  const daysCount = appState.trip.days || 2;
  if (daySelect) {
    daySelect.innerHTML = Array.from({ length: daysCount }, (_, i) => i + 1)
      .map(d => `<option value="${d}">Day ${d}</option>`)
      .join('');
  }

  destSelect.innerHTML = '<option value="">-- Choose a Baguio Destination --</option>' +
    sampleDestinations.map(d => {
      const feeStr = d.fee > 0 ? `₱${d.fee}` : 'Free';
      return `<option value="${d.id}">${escapeHTML(d.name)} (${escapeHTML(d.category)}) — ${feeStr}</option>`;
    }).join('');

  if (options.stopId) {
    stopEditorTargetId = options.stopId;
    if (titleEl) titleEl.textContent = 'Edit Itinerary Stop';
    const stop = appState.itinerary.find(s => s.id === options.stopId);
    if (stop) {
      if (destSelect) destSelect.value = stop.destinationId;
      const dayNum = getStopDayIndex(stop.date);
      if (daySelect) daySelect.value = String(dayNum);
      if (dateInput) dateInput.value = stop.date;
      if (timeInput) timeInput.value = stop.time;
      if (durInput) durInput.value = stop.duration || 90;
      if (activityInput) activityInput.value = stop.activity || '';
    }
  } else {
    stopEditorTargetId = null;
    if (titleEl) titleEl.textContent = 'Add Stop to Itinerary';
    const targetDay = options.day ? Number(options.day) : 1;
    if (daySelect) daySelect.value = String(targetDay);
    if (dateInput) dateInput.value = getDateForDay(targetDay);

    if (options.destinationId && destSelect) {
      destSelect.value = options.destinationId;
    } else if (destSelect) {
      destSelect.value = '';
    }

    if (timeInput) timeInput.value = '09:00';
    if (durInput) durInput.value = '90';
    if (activityInput) activityInput.value = '';
  }

  destSelect.dispatchEvent(new Event('change'));
  modal.style.display = 'flex';
}

/**
 * Event listeners and controls for Step 1 Budget Setup & Itinerary Planner
 */
function setupItineraryControls() {
  const sliderMin = document.getElementById('budget-slider-min');
  const sliderMax = document.getElementById('budget-slider-max');
  const numMin = document.getElementById('budget-num-min');
  const numMax = document.getElementById('budget-num-max');
  const daysInput = document.getElementById('budget-trip-days');
  const presetButtons = document.querySelectorAll('#budget-preset-buttons .btn-preset');
  const btnConfirm = document.getElementById('btn-confirm-budget');
  const btnEdit = document.getElementById('btn-edit-confirmed-budget');

  const btnOpenAddStop = document.getElementById('btn-open-add-stop-modal');
  const btnLoadSample = document.getElementById('btn-load-sample-itinerary');
  const btnClearItin = document.getElementById('btn-clear-itinerary');

  // Setup stop editor modal listeners
  setupStopEditorModal();

  // Planner Workspace Buttons
  if (btnOpenAddStop) {
    btnOpenAddStop.addEventListener('click', () => {
      openStopEditor();
    });
  }

  if (btnLoadSample) {
    btnLoadSample.addEventListener('click', loadSampleItinerary);
  }

  if (btnClearItin) {
    btnClearItin.addEventListener('click', clearItinerary);
  }

  // 1. Min Slider Input
  if (sliderMin && sliderMax && numMin && numMax) {
    sliderMin.addEventListener('pointerdown', () => {
      sliderMin.style.zIndex = '5';
      sliderMax.style.zIndex = '4';
    });
    sliderMax.addEventListener('pointerdown', () => {
      sliderMax.style.zIndex = '5';
      sliderMin.style.zIndex = '4';
    });

    sliderMin.addEventListener('input', () => {
      sliderMin.style.zIndex = '5';
      sliderMax.style.zIndex = '4';
      let minVal = parseInt(sliderMin.value, 10);
      const maxVal = parseInt(sliderMax.value, 10);

      if (minVal > maxVal - BUDGET_SLIDER_CONFIG.MIN_GAP) {
        minVal = maxVal - BUDGET_SLIDER_CONFIG.MIN_GAP;
        sliderMin.value = minVal;
      }

      numMin.value = minVal;
      const days = daysInput ? parseInt(daysInput.value, 10) || 2 : 2;
      updateBudgetCalculations(minVal, maxVal, days);
      updateSliderTrackHighlight(minVal, maxVal);
      highlightMatchingPreset(minVal, maxVal);
    });

    // 2. Max Slider Input
    sliderMax.addEventListener('input', () => {
      sliderMax.style.zIndex = '5';
      sliderMin.style.zIndex = '4';
      const minVal = parseInt(sliderMin.value, 10);
      let maxVal = parseInt(sliderMax.value, 10);

      if (maxVal < minVal + BUDGET_SLIDER_CONFIG.MIN_GAP) {
        maxVal = minVal + BUDGET_SLIDER_CONFIG.MIN_GAP;
        sliderMax.value = maxVal;
      }

      numMax.value = maxVal;
      const days = daysInput ? parseInt(daysInput.value, 10) || 2 : 2;
      updateBudgetCalculations(minVal, maxVal, days);
      updateSliderTrackHighlight(minVal, maxVal);
      highlightMatchingPreset(minVal, maxVal);
    });

    // 3. Min Number Input
    const handleMinNumChange = () => {
      let minVal = parseInt(numMin.value, 10) || BUDGET_SLIDER_CONFIG.MIN_ALLOWED;
      const maxVal = parseInt(numMax.value, 10) || 3500;

      if (minVal < BUDGET_SLIDER_CONFIG.MIN_ALLOWED) {
        minVal = BUDGET_SLIDER_CONFIG.MIN_ALLOWED;
      }
      if (minVal > maxVal - BUDGET_SLIDER_CONFIG.MIN_GAP) {
        minVal = maxVal - BUDGET_SLIDER_CONFIG.MIN_GAP;
      }

      numMin.value = minVal;
      sliderMin.value = minVal;
      const days = daysInput ? parseInt(daysInput.value, 10) || 2 : 2;
      updateBudgetCalculations(minVal, maxVal, days);
      updateSliderTrackHighlight(minVal, maxVal);
      highlightMatchingPreset(minVal, maxVal);
    };
    numMin.addEventListener('change', handleMinNumChange);
    numMin.addEventListener('blur', handleMinNumChange);

    // 4. Max Number Input
    const handleMaxNumChange = () => {
      const minVal = parseInt(numMin.value, 10) || BUDGET_SLIDER_CONFIG.MIN_ALLOWED;
      let maxVal = parseInt(numMax.value, 10) || 3500;

      if (maxVal > BUDGET_SLIDER_CONFIG.MAX_ALLOWED) {
        maxVal = BUDGET_SLIDER_CONFIG.MAX_ALLOWED;
      }
      if (maxVal < minVal + BUDGET_SLIDER_CONFIG.MIN_GAP) {
        maxVal = minVal + BUDGET_SLIDER_CONFIG.MIN_GAP;
      }

      numMax.value = maxVal;
      sliderMax.value = maxVal;
      const days = daysInput ? parseInt(daysInput.value, 10) || 2 : 2;
      updateBudgetCalculations(minVal, maxVal, days);
      updateSliderTrackHighlight(minVal, maxVal);
      highlightMatchingPreset(minVal, maxVal);
    };
    numMax.addEventListener('change', handleMaxNumChange);
    numMax.addEventListener('blur', handleMaxNumChange);
  }

  // 5. Trip Days Input
  if (daysInput) {
    const handleDaysChange = () => {
      let days = parseInt(daysInput.value, 10) || 2;
      if (days < 1) days = 1;
      if (days > 30) days = 30;
      daysInput.value = days;

      const minVal = numMin ? parseInt(numMin.value, 10) || 1500 : 1500;
      const maxVal = numMax ? parseInt(numMax.value, 10) || 3500 : 3500;
      updateBudgetCalculations(minVal, maxVal, days);
    };
    daysInput.addEventListener('input', handleDaysChange);
    daysInput.addEventListener('change', handleDaysChange);
  }

  // 6. Preset Buttons
  presetButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const pMin = parseInt(btn.getAttribute('data-min'), 10);
      const pMax = parseInt(btn.getAttribute('data-max'), 10);
      if (!pMin || !pMax) return;

      if (sliderMin) sliderMin.value = pMin;
      if (sliderMax) sliderMax.value = pMax;
      if (numMin) numMin.value = pMin;
      if (numMax) numMax.value = pMax;

      const days = daysInput ? parseInt(daysInput.value, 10) || 2 : 2;
      updateBudgetCalculations(pMin, pMax, days);
      updateSliderTrackHighlight(pMin, pMax);
      highlightMatchingPreset(pMin, pMax);
    });
  });

  // 7. Confirm Budget Action
  if (btnConfirm) {
    btnConfirm.addEventListener('click', () => {
      const minVal = numMin ? parseInt(numMin.value, 10) || 1500 : 1500;
      const maxVal = numMax ? parseInt(numMax.value, 10) || 3500 : 3500;
      const days = daysInput ? parseInt(daysInput.value, 10) || 2 : 2;

      if (minVal > maxVal) {
        showToast('Minimum budget cannot exceed maximum budget.', 'warning');
        return;
      }

      appState.trip.budgetMin = minVal;
      appState.trip.budgetMax = maxVal;
      appState.trip.days = days;
      appState.trip.budgetConfirmed = true;
      appState.hasConfirmedBudget = true;

      saveData();
      localStorage.setItem('lakbay_budget_range', JSON.stringify({
        min: minVal,
        max: maxVal,
        days: days,
        confirmed: true
      }));

      renderItineraryList();
      showToast(`Budget established: ₱${formatNumber(minVal)} – ₱${formatNumber(maxVal)} (${days} Days)`, 'success');
    });
  }

  // 8. Edit Confirmed Budget Action
  if (btnEdit) {
    btnEdit.addEventListener('click', () => {
      appState.hasConfirmedBudget = false;
      appState.trip.budgetConfirmed = false;
      saveData();

      const selectorView = document.getElementById('budget-selector-view');
      const confirmedView = document.getElementById('budget-confirmed-view');
      if (selectorView) selectorView.style.display = 'block';
      if (confirmedView) confirmedView.style.display = 'none';

      syncBudgetInputsFromState();

      if (numMin) numMin.focus();
    });
  }
}

/**
 * Integration Stubs for Other Screens (Explore / Details / Summary)
 */
function prefillItineraryForm(destId) {
  showSection('itinerary');
  const dest = sampleDestinations.find(d => d.id === destId);
  const destName = dest ? dest.name : 'Destination';

  if (!appState.hasConfirmedBudget) {
    showToast(`Please confirm your estimated budget first before planning "${destName}".`, 'info');
  } else {
    openStopEditor({ destinationId: destId });
  }
}

function openQuickAddPopover(destId, anchorBtn) {
  prefillItineraryForm(destId);
}

function setupQuickAddPopover() {
  // Integrated into stop-editor-modal
}

function setupDestinationDropdown() {
  // Handled inside stop editor
}

function sortItineraryChronologically() {
  if (!Array.isArray(appState.itinerary)) return;
  appState.itinerary.sort((a, b) => {
    if (a.date !== b.date) return (a.date || '').localeCompare(b.date || '');
    return (a.time || '').localeCompare(b.time || '');
  });
}

/**
 * Text export formatter for Screen 6
 */
function copyPlanAsText() {
  const trip = appState.trip;
  const stops = appState.itinerary;
  const days = trip.days || 2;
  const nights = Math.max(1, days - 1);
  const minBudget = trip.budgetMin || 1500;
  const maxBudget = trip.budgetMax || 3500;

  const totalFees = stops.reduce((sum, s) => {
    const d = sampleDestinations.find(dest => dest.id === s.destinationId);
    return sum + (d ? Number(d.fee) || 0 : (Number(s.fee) || 0));
  }, 0);

  let text = `=================================================\n`;
  text += `LAKBAY PH — ${(trip.name || 'BAGUIO MOUNTAIN HOLIDAY').toUpperCase()}\n`;
  text += `=================================================\n`;
  text += `Destination: ${trip.city || 'Baguio City'}\n`;
  text += `Duration: ${days} Day(s) (${nights} Night(s))\n`;
  text += `Budget Limit: ₱${formatNumber(minBudget)} – ₱${formatNumber(maxBudget)}\n`;
  text += `Total Entrance Fees: ₱${formatNumber(totalFees)}\n`;
  text += `=================================================\n\n`;

  if (stops.length === 0) {
    text += `No stops scheduled yet.\n`;
  } else {
    const uniqueDates = [...new Set(stops.map(s => s.date))].sort();
    uniqueDates.forEach((dateStr, idx) => {
      const dayStops = stops.filter(s => s.date === dateStr);
      text += `Day ${idx + 1} (${formatDate(dateStr)}):\n`;
      dayStops.forEach((s, sIdx) => {
        const d = sampleDestinations.find(item => item.id === s.destinationId);
        const feeStr = (d && d.fee > 0) ? `₱${d.fee}` : 'Free';
        const end = minutesToTime(timeToMinutes(s.time) + (s.duration || 90));
        text += `  ${sIdx + 1}. ${s.time} – ${end} | ${s.destinationName} (${feeStr})\n`;
        if (s.activity) text += `     Activity: ${s.activity}\n`;
      });
      text += `\n`;
    });
  }

  if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
    navigator.clipboard.writeText(text).then(() => {
      showToast('Travel plan copied to clipboard!', 'success');
    }).catch(() => {
      fallbackCopyText(text);
    });
  } else {
    fallbackCopyText(text);
  }
}

function fallbackCopyText(text) {
  const textarea = document.createElement('textarea');
  textarea.value = text;
  textarea.style.position = 'fixed';
  textarea.style.left = '-9999px';
  document.body.appendChild(textarea);
  textarea.select();
  try {
    document.execCommand('copy');
    showToast('Travel plan copied to clipboard!', 'success');
  } catch (err) {
    showToast('Failed to copy to clipboard.', 'danger');
  }
  document.body.removeChild(textarea);
}


// Budget Calculator screen was removed in favor of integrated Itinerary Budget Planning
function setupBudgetControls() {}
function restoreBudgetInputs() {}
function calculateBudget(shouldSave = false) {}
function syncActivitiesFeeFromStops(notify = false) {}

/* ==========================================================================
   SCREEN 6: TRAVEL PLAN SUMMARY (Day-by-Day, Export JSON, Copy Plan, Print)
   ========================================================================== */
function setupSummaryControls() {
  const printBtn = document.getElementById('btn-print-summary');
  const copyBtn = document.getElementById('btn-summary-copy-plan');
  const exportBtn = document.getElementById('btn-summary-export-json');

  if (printBtn) {
    printBtn.addEventListener('click', () => {
      window.print();
    });
  }

  if (copyBtn) {
    copyBtn.addEventListener('click', copyPlanAsText);
  }

  if (exportBtn) {
    exportBtn.addEventListener('click', exportJSON);
  }
}

function buildSummary() {
  const reportCard = document.getElementById('summary-report-card');
  const emptyState = document.getElementById('summary-empty-state');
  const printBtn = document.getElementById('btn-print-summary');

  const stops = appState.itinerary;
  const trip = appState.trip;

  const hasData = stops.length > 0 || appState.hasConfirmedBudget;

  if (!hasData) {
    if (reportCard) reportCard.style.display = 'none';
    if (printBtn) printBtn.style.display = 'none';
    if (emptyState) emptyState.style.display = 'block';
    return;
  }

  if (emptyState) emptyState.style.display = 'none';
  if (reportCard) reportCard.style.display = 'block';
  if (printBtn) printBtn.style.display = 'inline-flex';

  // 1. Meta Details
  const metaDays = document.getElementById('summary-meta-days');
  const metaTravelers = document.getElementById('summary-meta-travelers');
  const metaStops = document.getElementById('summary-meta-stops-count');

  const daysCount = trip.days || 2;
  const nightsCount = Math.max(1, daysCount - 1);
  const travelersCount = 1;

  if (metaDays) metaDays.textContent = `${daysCount} Day${daysCount === 1 ? '' : 's'} (${nightsCount} Night${nightsCount === 1 ? '' : 's'})`;
  if (metaTravelers) metaTravelers.textContent = `${travelersCount} Person${travelersCount === 1 ? '' : 's'}`;
  if (metaStops) metaStops.textContent = `${stops.length} Stop${stops.length === 1 ? '' : 's'}`;

  // 3. Day-by-Day Itinerary Schedule with Per-Day Subtotals
  const itineraryContainer = document.getElementById('summary-itinerary-list');
  if (itineraryContainer) {
    if (stops.length === 0) {
      itineraryContainer.innerHTML = '<span style="color: #94a3b8; font-style: italic;">No planned stops yet.</span>';
    } else {
      const uniqueDates = [...new Set(stops.map(s => s.date))].sort();
      itineraryContainer.innerHTML = uniqueDates.map((dateStr, idx) => {
        const dayStops = stops.filter(s => s.date === dateStr);
        const dayNumber = idx + 1;
        const formattedDate = formatDate(dateStr);
        const dayFees = dayStops.reduce((sum, s) => sum + (Number(s.fee) || 0), 0);

        return `
          <div class="summary-day-group">
            <div class="summary-day-header">
              Day ${dayNumber} — ${formattedDate} (${dayStops.length} stops · Entrance Fees: ${dayFees === 0 ? 'Free' : '₱' + dayFees.toFixed(2)}/person)
            </div>
            ${dayStops.map(stop => {
              const duration = stop.duration || 90;
              const startMins = timeToMinutes(stop.time);
              const endMins = startMins + duration;
              const rangeStr = `${stop.time} – ${minutesToTime(endMins)}`;
              const isDone = isPastDate(stop.date);

              return `
                <div class="summary-itinerary-item">
                  <span class="summary-time-tag">${rangeStr}</span>
                  <span class="summary-itinerary-text">
                    <strong>${escapeHTML(stop.destinationName)}</strong>
                    ${isDone ? ' <span class="stop-status-badge completed">✓ Completed</span>' : ''}
                    ${stop.activity && stop.activity.trim() ? `: ${escapeHTML(stop.activity)}` : ''}
                    ${stop.fee > 0 ? ` <small style="color: #10352b; font-weight:700;">(Fee: ₱${stop.fee})</small>` : ' <small style="color: #5f7e75;">(Free)</small>'}
                  </span>
                </div>
              `;
            }).join('')}
          </div>
        `;
      }).join('');
    }
  }

  // 4. Budget Breakdown (Calculated from Itinerary Budget Selection)
  const costTrans = document.getElementById('summary-cost-trans');
  const costAcc = document.getElementById('summary-cost-acc');
  const costFood = document.getElementById('summary-cost-food');
  const costAct = document.getElementById('summary-cost-activities');
  const costExtra = document.getElementById('summary-cost-extra');
  const costTotal = document.getElementById('summary-cost-total');
  const costPerPerson = document.getElementById('summary-cost-per-person');
  const costTravelers = document.getElementById('summary-cost-travelers');

  const maxBudget = trip.budgetMax || 3500;
  const lodging = Math.round(maxBudget * 0.40);
  const food = Math.round(maxBudget * 0.25);
  const transpo = Math.round(maxBudget * 0.15);
  const stopsFees = stops.reduce((sum, s) => sum + (Number(s.fee) || 0), 0);
  const other = Math.round(maxBudget * 0.10);

  if (costTrans) costTrans.textContent = formatCurrency(transpo);
  if (costAcc) costAcc.textContent = formatCurrency(lodging);
  if (costFood) costFood.textContent = formatCurrency(food);
  if (costAct) costAct.textContent = formatCurrency(stopsFees);
  if (costExtra) costExtra.textContent = formatCurrency(other);
  if (costTotal) costTotal.textContent = `₱${formatNumber(trip.budgetMin || 1500)} – ₱${formatNumber(maxBudget)}`;
  if (costPerPerson) costPerPerson.textContent = `₱${formatNumber(trip.budgetMin || 1500)} – ₱${formatNumber(maxBudget)}`;
  if (costTravelers) costTravelers.textContent = travelersCount;
}

const generateSummary = buildSummary;

/* ==========================================================================
   EXPORT & SHARE (Copy as Text, Export JSON, Import JSON)
   ========================================================================== */
function exportJSON() {
  const data = {
    version: 1,
    exportedAt: new Date().toISOString(),
    city: 'Baguio City, Philippines',
    itinerary: appState.itinerary,
    trip: appState.trip
  };

  const jsonStr = JSON.stringify(data, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);

  const a = document.createElement('a');
  a.href = url;
  a.download = `lakbay-baguio-plan-${getTodayDateString()}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);

  showToast('Itinerary plan exported as JSON backup.', 'success');
}

function importJSON(file) {
  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      const parsed = JSON.parse(e.target.result);
      if (!parsed || typeof parsed !== 'object') {
        throw new Error('Invalid JSON structure');
      }

      // Validate & restore itinerary
      if (Array.isArray(parsed.itinerary)) {
        appState.itinerary = parsed.itinerary
          .filter(stop => {
            const destId = Number(stop.destinationId);
            return sampleDestinations.some(d => d.id === destId) && stop.date && stop.time;
          })
          .map(stop => {
            const destObj = sampleDestinations.find(d => d.id === Number(stop.destinationId));
            return {
              id: String(stop.id || generateUniqueId()),
              destinationId: Number(stop.destinationId),
              destinationName: destObj ? destObj.name : 'Destination',
              category: destObj ? destObj.category : '',
              fee: destObj ? destObj.fee : 0,
              date: String(stop.date),
              time: String(stop.time),
              duration: parseInt(stop.duration, 10) || 90,
              activity: String(stop.activity || '')
            };
          });
      }

      // Validate & restore trip
      if (parsed.trip && typeof parsed.trip === 'object') {
        const bMin = Math.max(500, parseInt(parsed.trip.budgetMin, 10) || 1500);
        const bMax = Math.max(bMin, parseInt(parsed.trip.budgetMax, 10) || 3500);
        const days = Math.max(1, parseInt(parsed.trip.days, 10) || 2);
        const confirmed = Boolean(parsed.trip.budgetConfirmed);
        appState.trip = {
          name: parsed.trip.name ? String(parsed.trip.name).trim() : 'Baguio Mountain Holiday',
          city: parsed.trip.city ? String(parsed.trip.city).trim() : 'Baguio City',
          days: days,
          startDate: parsed.trip.startDate || getTodayDateString(),
          budgetMin: bMin,
          budgetMax: bMax,
          budgetConfirmed: confirmed
        };
        appState.hasConfirmedBudget = confirmed;
      }

      sortItineraryChronologically();
      saveData();

          renderHomeProgress();
      renderExploreGallery();
      renderItineraryList();

      showToast(`Imported ${appState.itinerary.length} stops and trip data successfully!`, 'success');
    } catch (err) {
      console.error('[Lakbay] Import error:', err);
      showToast('Error importing JSON. Please ensure the file is a valid Lakbay backup.', 'danger');
    }
  };
  reader.readAsText(file);
}



/* ==========================================================================
   CONFIRMATION DIALOG (Accessible replacement for window.confirm)
   ========================================================================== */
let confirmDialogCallback = null;
let confirmLastFocusedElement = null;

function setupConfirmDialog() {
  const modal = document.getElementById('confirm-modal');
  const cancelBtn = document.getElementById('confirm-cancel-btn');
  const okBtn = document.getElementById('confirm-ok-btn');
  const backdrop = document.getElementById('confirm-modal-backdrop');

  const closeDialog = () => {
    if (modal) {
      modal.style.display = 'none';
      modal.setAttribute('aria-hidden', 'true');
      document.body.style.overflow = '';
    }
    confirmDialogCallback = null;
    if (confirmLastFocusedElement && typeof confirmLastFocusedElement.focus === 'function') {
      confirmLastFocusedElement.focus();
    }
  };

  if (cancelBtn) cancelBtn.addEventListener('click', closeDialog);
  if (backdrop) backdrop.addEventListener('click', closeDialog);

  if (okBtn) {
    okBtn.addEventListener('click', () => {
      const cb = confirmDialogCallback;
      closeDialog();
      if (typeof cb === 'function') {
        cb();
      }
    });
  }

  document.addEventListener('keydown', (e) => {
    if (modal && modal.style.display !== 'none') {
      if (e.key === 'Escape') {
        closeDialog();
      } else if (e.key === 'Tab') {
        trapFocusInDialog(modal, e);
      }
    }
  });
}

function openConfirmDialog(title, message, onConfirm) {
  confirmLastFocusedElement = document.activeElement;
  confirmDialogCallback = onConfirm;

  const modal = document.getElementById('confirm-modal');
  const titleEl = document.getElementById('confirm-modal-title');
  const msgEl = document.getElementById('confirm-modal-msg');
  const okBtn = document.getElementById('confirm-ok-btn');

  if (titleEl) titleEl.textContent = title;
  if (msgEl) msgEl.textContent = message;

  if (modal) {
    modal.style.display = 'flex';
    modal.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
    if (okBtn) okBtn.focus();
  }
}

/* ==========================================================================
   TOAST NOTIFICATION CENTER (Capped at 1–2 items, Supports Undo)
   ========================================================================== */
function showToast(message, type = 'info', enableUndo = false) {
  const container = document.getElementById('toast-container');
  if (!container) return;

  // Capped at 2 toasts: remove oldest if count >= 2
  while (container.children.length >= 2) {
    container.removeChild(container.firstChild);
  }

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;

  const msgSpan = document.createElement('span');
  msgSpan.className = 'toast-msg';
  msgSpan.textContent = message;
  toast.appendChild(msgSpan);

  if (enableUndo) {
    const undoBtn = document.createElement('button');
    undoBtn.type = 'button';
    undoBtn.className = 'toast-undo-btn';
    undoBtn.textContent = 'Undo';
    undoBtn.addEventListener('click', () => {
      undoDeleteStop();
      if (toast.parentElement) toast.parentElement.removeChild(toast);
    });
    toast.appendChild(undoBtn);
  }

  container.appendChild(toast);

  const duration = enableUndo ? 4500 : 2800;

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    setTimeout(() => {
      if (toast.parentElement) toast.parentElement.removeChild(toast);
    }, 250);
  }, duration);
}

/* ==========================================================================
   ENTRY POINT
   ========================================================================== */
document.addEventListener('DOMContentLoaded', init);
