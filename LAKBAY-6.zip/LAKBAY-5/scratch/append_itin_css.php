<?php
$cssPath = 'css/style.css';
$css = file_get_contents($cssPath);

$newStyles = <<<'CSS'

/* ==========================================================================
   ITINERARY PLANNER & WORKSPACE STYLES (Confirmed Budget State)
   ========================================================================== */

/* Header & Action Bar */
.confirmed-status-group {
  display: flex;
  align-items: center;
  gap: 12px;
  flex-wrap: wrap;
}

.confirmed-trip-title {
  font-size: 1rem;
  font-weight: 800;
  color: #10352b;
  background: #f0f7f3;
  padding: 4px 12px;
  border-radius: var(--radius-full);
  border: 1px solid #dbe6de;
}

.confirmed-actions-group {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
}

/* Integrated Budget Tracker Panel */
.budget-tracker-panel {
  background: #f7faf8;
  border: 1.5px solid #dce8e0;
  border-radius: var(--radius-lg);
  padding: 1.25rem 1.5rem;
  display: flex;
  flex-direction: column;
  gap: 1rem;
  margin: 0.5rem 0 1.25rem 0;
}

.budget-tracker-stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: 12px;
}

.tracker-stat-box {
  background: #ffffff;
  border: 1px solid #e2ebe5;
  border-radius: var(--radius-md);
  padding: 0.85rem 1rem;
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.tracker-stat-box.highlight-box {
  background: #f0fdf4;
  border-color: #bbf7d0;
}

.tracker-stat-label {
  font-size: 0.68rem;
  font-weight: 800;
  letter-spacing: 0.05em;
  text-transform: uppercase;
  color: #55726a;
}

.tracker-stat-val {
  font-size: 1.2rem;
  font-weight: 800;
  color: var(--text-main);
}

.tracker-stat-sub {
  font-size: 0.75rem;
  color: #64748b;
  font-weight: 600;
}

/* Progress Meter */
.budget-meter-wrap {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.meter-labels-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 0.8rem;
  font-weight: 700;
  color: #38554d;
}

.meter-track {
  height: 8px;
  background: #e2e8f0;
  border-radius: 4px;
  overflow: hidden;
}

.meter-fill {
  height: 100%;
  background: linear-gradient(90deg, #10352b 0%, #22c55e 100%);
  border-radius: 4px;
  transition: width 0.3s ease, background 0.3s ease;
}

.meter-fill.warning {
  background: linear-gradient(90deg, #eab308 0%, #f97316 100%);
}

.meter-fill.overflow {
  background: #ef4444;
}

.budget-alert-banner {
  display: flex;
  align-items: center;
  gap: 8px;
  background: #fef2f2;
  border: 1px solid #fecaca;
  color: #b91c1c;
  padding: 0.6rem 0.9rem;
  border-radius: var(--radius-md);
  font-size: 0.82rem;
  font-weight: 600;
  animation: fadeInBudget 0.2s ease-out;
}

/* Day Filter Tabs & Workspace Header */
.itinerary-workspace-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
  margin-top: 0.5rem;
  padding-bottom: 0.75rem;
  border-bottom: 1px solid #edf2ee;
  flex-wrap: wrap;
}

.day-filter-tabs {
  display: flex;
  align-items: center;
  gap: 8px;
  overflow-x: auto;
  padding: 2px 0;
}

.day-tab-pill {
  background: #f1f5f3;
  border: 1.5px solid transparent;
  color: #38554d;
  font-weight: 700;
  font-size: 0.85rem;
  padding: 6px 14px;
  border-radius: var(--radius-full);
  cursor: pointer;
  transition: all 0.2s ease;
  white-space: nowrap;
}

.day-tab-pill:hover {
  background: #e6ede8;
}

.day-tab-pill.active {
  background: #10352b;
  color: #ffffff;
  border-color: #10352b;
}

/* Day-by-Day Timeline Container */
.itinerary-days-container {
  display: flex;
  flex-direction: column;
  gap: 1.75rem;
  margin-top: 1rem;
}

.itinerary-day-section {
  display: flex;
  flex-direction: column;
  gap: 0.85rem;
}

.day-section-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0.7rem 1.1rem;
  background: #edf5f0;
  border-radius: var(--radius-md);
  border-left: 4px solid #10352b;
}

.day-section-title-wrap {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
}

.day-section-title {
  font-size: 1rem;
  font-weight: 800;
  color: #10352b;
  margin: 0;
}

.day-section-date {
  font-size: 0.82rem;
  color: #5f7e75;
  font-weight: 600;
}

.day-meta-pills {
  display: flex;
  align-items: center;
  gap: 6px;
}

.day-meta-pill {
  font-size: 0.72rem;
  font-weight: 700;
  color: #2e594d;
  background: #ffffff;
  padding: 2px 8px;
  border-radius: var(--radius-full);
  border: 1px solid #dce8e0;
}

.day-add-stop-btn {
  background: #ffffff;
  border: 1px solid #dce8e0;
  color: #10352b;
  font-size: 0.78rem;
  font-weight: 700;
  padding: 4px 10px;
  border-radius: var(--radius-full);
  cursor: pointer;
  transition: all 0.15s ease;
}

.day-add-stop-btn:hover {
  background: #10352b;
  color: #ffffff;
  border-color: #10352b;
}

/* Stops List & Stop Card */
.day-stops-list {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.empty-day-banner {
  background: #ffffff;
  border: 1.5px dashed #d5e2da;
  border-radius: var(--radius-lg);
  padding: 1.5rem;
  text-align: center;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
}

.empty-day-text {
  font-size: 0.85rem;
  color: #64748b;
  margin: 0;
}

.itinerary-stop-card {
  display: grid;
  grid-template-columns: 88px 72px 1fr auto;
  align-items: center;
  gap: 14px;
  padding: 0.85rem 1.15rem;
  background: #ffffff;
  border: 1.5px solid #e5ebe7;
  border-radius: var(--radius-lg);
  box-shadow: 0 2px 6px rgba(16, 53, 43, 0.04);
  transition: all 0.2s ease;
}

.itinerary-stop-card:hover {
  border-color: #b9d1c3;
  box-shadow: 0 4px 12px rgba(16, 53, 43, 0.08);
  transform: translateY(-1px);
}

.stop-time-col {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background: #f0f7f3;
  border-radius: var(--radius-md);
  padding: 6px;
  text-align: center;
  gap: 2px;
}

.stop-time-val {
  font-size: 0.88rem;
  font-weight: 800;
  color: #10352b;
}

.stop-time-end {
  font-size: 0.72rem;
  color: #64748b;
  font-weight: 600;
}

.stop-dur-pill {
  font-size: 0.65rem;
  font-weight: 700;
  background: #ffffff;
  color: #10352b;
  padding: 1px 6px;
  border-radius: var(--radius-full);
  border: 1px solid #d5e2da;
}

.stop-thumb-img {
  width: 72px;
  height: 64px;
  object-fit: cover;
  border-radius: var(--radius-md);
  border: 1px solid #e2e8f0;
}

.stop-info-col {
  display: flex;
  flex-direction: column;
  gap: 4px;
  min-width: 0;
}

.stop-title-row {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
}

.stop-dest-title {
  font-size: 0.98rem;
  font-weight: 800;
  color: var(--text-main);
  margin: 0;
}

.badge-fee-free {
  font-size: 0.72rem;
  font-weight: 700;
  background: #dcfce7;
  color: #15803d;
  padding: 2px 8px;
  border-radius: var(--radius-full);
}

.badge-fee-paid {
  font-size: 0.72rem;
  font-weight: 700;
  background: #fef9c3;
  color: #854d0e;
  padding: 2px 8px;
  border-radius: var(--radius-full);
}

.stop-meta-tags {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 0.75rem;
  color: #64748b;
}

.stop-category-tag {
  font-weight: 700;
  color: #2e594d;
}

.stop-activity-text {
  font-size: 0.82rem;
  color: #475569;
  margin: 0;
  line-height: 1.35;
}

.stop-clash-warning {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  background: #fffbeb;
  border: 1px solid #fde68a;
  color: #b45309;
  font-size: 0.72rem;
  font-weight: 700;
  padding: 2px 8px;
  border-radius: var(--radius-sm);
  margin-top: 2px;
}

.stop-actions-col {
  display: flex;
  align-items: center;
  gap: 4px;
}

.btn-icon-action {
  width: 32px;
  height: 32px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: var(--radius-full);
  font-size: 0.85rem;
  cursor: pointer;
  color: #475569;
  transition: all 0.15s ease;
}

.btn-icon-action:hover {
  background: #10352b;
  color: #ffffff;
  border-color: #10352b;
}

.btn-icon-action.action-delete:hover {
  background: #ef4444;
  color: #ffffff;
  border-color: #ef4444;
}

/* Add / Edit Stop Modal Dialog */
.dest-picker-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 6px;
}

.dest-filter-toggle {
  display: flex;
  align-items: center;
  gap: 4px;
}

.dest-toggle-pill {
  background: #f1f5f3;
  border: 1px solid #dce8e0;
  font-size: 0.72rem;
  font-weight: 700;
  color: #38554d;
  padding: 2px 10px;
  border-radius: var(--radius-full);
  cursor: pointer;
  transition: all 0.15s ease;
}

.dest-toggle-pill.active {
  background: #10352b;
  color: #ffffff;
  border-color: #10352b;
}

.dest-preview-strip {
  display: flex;
  align-items: center;
  gap: 12px;
  background: #f0f7f3;
  border: 1px solid #d5e5db;
  border-radius: var(--radius-md);
  padding: 8px 12px;
  margin-bottom: 1rem;
}

.dest-preview-thumb {
  width: 54px;
  height: 48px;
  object-fit: cover;
  border-radius: var(--radius-sm);
}

.dest-preview-meta {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.dest-preview-tags {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 0.72rem;
}

.duration-input-wrap {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.duration-quick-chips {
  display: flex;
  gap: 6px;
}

.duration-chip {
  background: #ffffff;
  border: 1px solid #cbd5e1;
  font-size: 0.72rem;
  font-weight: 700;
  color: #475569;
  padding: 2px 8px;
  border-radius: var(--radius-sm);
  cursor: pointer;
  transition: all 0.15s ease;
}

.duration-chip:hover {
  border-color: #10352b;
  color: #10352b;
}

.duration-chip.active {
  background: #10352b;
  color: #ffffff;
  border-color: #10352b;
}

.activity-suggestions-row {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-top: 6px;
  font-size: 0.75rem;
}

.sugg-label {
  font-weight: 700;
  color: #64748b;
  white-space: nowrap;
}

.sugg-chips-wrap {
  display: flex;
  gap: 6px;
  flex-wrap: wrap;
}

.sugg-chip {
  background: #f1f5f9;
  border: 1px solid #e2e8f0;
  font-size: 0.72rem;
  color: #334155;
  padding: 2px 8px;
  border-radius: var(--radius-full);
  cursor: pointer;
  transition: all 0.15s ease;
}

.sugg-chip:hover {
  background: #10352b;
  color: #ffffff;
}

.modal-budget-impact {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: var(--radius-md);
  padding: 8px 14px;
  font-size: 0.8rem;
  color: #475569;
  margin: 1rem 0;
}

.modal-actions-footer {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 10px;
  padding-top: 1rem;
  border-top: 1px solid #e2e8f0;
}

@media (max-width: 640px) {
  .itinerary-stop-card {
    grid-template-columns: 1fr;
    gap: 10px;
  }

  .stop-time-col {
    flex-direction: row;
    justify-content: space-between;
    padding: 6px 10px;
  }

  .stop-thumb-img {
    width: 100%;
    height: 120px;
  }

  .stop-actions-col {
    justify-content: flex-end;
  }

  .confirmed-badge-row {
    flex-direction: column;
    align-items: flex-start;
    gap: 10px;
  }

  .confirmed-actions-group {
    width: 100%;
    justify-content: flex-start;
  }
}

CSS;

file_put_contents($cssPath, $css . "\n" . $newStyles);
echo "Successfully appended itinerary planner CSS to $cssPath!\n";
