<?php
$jsPath = 'js/app.js';
$content = file_get_contents($jsPath);

$startMarker = '/* ==========================================================================' . "\n" . '   SCREEN 4: ITINERARY PLANNER';
$endMarker = '/* ==========================================================================' . "\n" . '   SCREEN 5: FAVORITES';

$posStart = strpos($content, $startMarker);
$posEnd = strpos($content, $endMarker);

if ($posStart === false || $posEnd === false) {
    die("Error: Screen 4 or Screen 5 marker not found!\n");
}

echo "Found Screen 4 from $posStart to $posEnd\n";

$newScreen4 = <<<'JS'
/* ==========================================================================
   SCREEN 4: ITINERARY PLANNER (Budget Selection & Day-by-Day Timeline)
   ========================================================================== */

const BUDGET_SLIDER_CONFIG = {
  MIN_ALLOWED: 500,
  MAX_ALLOWED: 25000,
  STEP: 100,
  MIN_GAP: 100
};

let stopEditorTargetId = null;
let activeDayFilter = 'all';

/**
 * Main itinerary renderer: toggles between View 1 (Budget Selector) and View 2 (Confirmed Workspace)
 */
function renderItineraryList() {
  const selectorView = document.getElementById('budget-selector-view');
  const confirmedView = document.getElementById('budget-confirmed-view');
  if (!selectorView || !confirmedView) return;

  if (appState.hasConfirmedBudget) {
    selectorView.style.display = 'none';
    confirmedView.style.display = 'block';
    renderItineraryWorkspace();
  } else {
    selectorView.style.display = 'block';
    confirmedView.style.display = 'none';
    syncBudgetInputsFromState();
  }
}

/**
 * Synchronizes inputs and UI elements from current appState.trip
 */
function syncBudgetInputsFromState() {
  const minVal = appState.trip.budgetMin || 1500;
  const maxVal = appState.trip.budgetMax || 3500;
  const daysVal = appState.trip.days || 2;

  const sliderMin = document.getElementById('budget-slider-min');
  const sliderMax = document.getElementById('budget-slider-max');
  const numMin = document.getElementById('budget-num-min');
  const numMax = document.getElementById('budget-num-max');
  const daysInput = document.getElementById('budget-trip-days');

  if (sliderMin) sliderMin.value = minVal;
  if (sliderMax) sliderMax.value = maxVal;
  if (numMin) numMin.value = minVal;
  if (numMax) numMax.value = maxVal;
  if (daysInput) daysInput.value = daysVal;

  updateBudgetCalculations(minVal, maxVal, daysVal);
  updateSliderTrackHighlight(minVal, maxVal);
  highlightMatchingPreset(minVal, maxVal);
}

/**
 * Updates the highlight bar on the dual-range track
 */
function updateSliderTrackHighlight(minVal, maxVal) {
  const highlightBar = document.getElementById('budget-highlight-track');
  if (!highlightBar) return;

  const totalRange = BUDGET_SLIDER_CONFIG.MAX_ALLOWED - BUDGET_SLIDER_CONFIG.MIN_ALLOWED;
  const leftPct = Math.max(0, Math.min(100, ((minVal - BUDGET_SLIDER_CONFIG.MIN_ALLOWED) / totalRange) * 100));
  const widthPct = Math.max(0, Math.min(100 - leftPct, ((maxVal - minVal) / totalRange) * 100));

  highlightBar.style.left = `${leftPct.toFixed(2)}%`;
  highlightBar.style.width = `${widthPct.toFixed(2)}%`;
}

/**
 * Calculates live daily allowance and projected category allocations
 */
function updateBudgetCalculations(minVal, maxVal, days) {
  const safeDays = Math.max(1, parseInt(days, 10) || 1);
  const minDaily = Math.round(minVal / safeDays);
  const maxDaily = Math.round(maxVal / safeDays);

  const dailyEl = document.getElementById('budget-calc-daily');
  const maxEl = document.getElementById('budget-calc-max');
  const lodgingEl = document.getElementById('alloc-lodging');
  const foodEl = document.getElementById('alloc-food');
  const transpoEl = document.getElementById('alloc-transpo');
  const activitiesEl = document.getElementById('alloc-activities');
  const otherEl = document.getElementById('alloc-other');

  if (dailyEl) dailyEl.textContent = `₱${formatNumber(minDaily)} – ₱${formatNumber(maxDaily)} / day`;
  if (maxEl) maxEl.textContent = formatNumber(maxVal);

  if (lodgingEl) lodgingEl.textContent = `₱${formatNumber(Math.round(maxVal * 0.40))}`;
  if (foodEl) foodEl.textContent = `₱${formatNumber(Math.round(maxVal * 0.25))}`;
  if (transpoEl) transpoEl.textContent = `₱${formatNumber(Math.round(maxVal * 0.15))}`;
  if (activitiesEl) activitiesEl.textContent = `₱${formatNumber(Math.round(maxVal * 0.10))}`;
  if (otherEl) otherEl.textContent = `₱${formatNumber(Math.round(maxVal * 0.10))}`;
}

/**
 * Highlights a preset button if current values match
 */
function highlightMatchingPreset(minVal, maxVal) {
  const presetBtns = document.querySelectorAll('#budget-preset-buttons .btn-preset');
  presetBtns.forEach(btn => {
    const pMin = parseInt(btn.getAttribute('data-min'), 10);
    const pMax = parseInt(btn.getAttribute('data-max'), 10);
    if (pMin === minVal && pMax === maxVal) {
      btn.classList.add('active');
    } else {
      btn.classList.remove('active');
    }
  });
}

/**
 * Renders the confirmed workspace: Live budget tracker meter, day tabs, and stops timeline
 */
function renderItineraryWorkspace() {
  const trip = appState.trip;
  const days = trip.days || 2;
  const minBudget = trip.budgetMin || 1500;
  const maxBudget = trip.budgetMax || 3500;
  const stops = appState.itinerary || [];

  // 1. Top Badges & Trip Title
  const tripTitleEl = document.getElementById('confirmed-trip-title');
  const budgetDisplay = document.getElementById('confirmed-budget-display');
  const daysDisplay = document.getElementById('confirmed-days-display');

  if (tripTitleEl) tripTitleEl.textContent = `${trip.city || 'Baguio City'} · ${days} Day${days > 1 ? 's' : ''}`;
  if (budgetDisplay) budgetDisplay.textContent = `₱${formatNumber(minBudget)} – ₱${formatNumber(maxBudget)}`;
  if (daysDisplay) daysDisplay.textContent = `${days} Day${days > 1 ? 's' : ''}`;

  // 2. Budget Utilization Calculations
  const stopsFees = stops.reduce((sum, s) => {
    const d = sampleDestinations.find(dest => dest.id === s.destinationId);
    return sum + (d ? Number(d.fee) || 0 : (Number(s.fee) || 0));
  }, 0);

  const baseLivingCost = Math.round(maxBudget * 0.80);
  const totalPlannedSpent = baseLivingCost + stopsFees;
  const remainingBudget = maxBudget - totalPlannedSpent;

  // Update Tracker Metrics
  const feesEl = document.getElementById('tracker-stops-fees');
  const countEl = document.getElementById('tracker-stops-count');
  const baseEl = document.getElementById('tracker-base-living');
  const remBox = document.getElementById('tracker-remaining-box');
  const remEl = document.getElementById('tracker-remaining-budget');
  const remStatusEl = document.getElementById('tracker-remaining-status');

  if (feesEl) feesEl.textContent = `₱${formatNumber(stopsFees)}`;
  if (countEl) countEl.textContent = `${stops.length} stop${stops.length === 1 ? '' : 's'} planned`;
  if (baseEl) baseEl.textContent = `₱${formatNumber(baseLivingCost)}`;

  if (remEl) {
    if (remainingBudget >= 0) {
      remEl.textContent = `₱${formatNumber(remainingBudget)}`;
      remEl.style.color = '#10352b';
      if (remBox) {
        remBox.style.background = '#f0fdf4';
        remBox.style.borderColor = '#bbf7d0';
      }
      if (remStatusEl) {
        remStatusEl.textContent = 'Within Budget ✓';
        remStatusEl.style.color = '#15803d';
      }
    } else {
      remEl.textContent = `-₱${formatNumber(Math.abs(remainingBudget))}`;
      remEl.style.color = '#b91c1c';
      if (remBox) {
        remBox.style.background = '#fef2f2';
        remBox.style.borderColor = '#fecaca';
      }
      if (remStatusEl) {
        remStatusEl.textContent = 'Over Ceiling ⚠️';
        remStatusEl.style.color = '#b91c1c';
      }
    }
  }

  // Meter Bar
  const meterPercent = Math.min(100, Math.round((totalPlannedSpent / maxBudget) * 100));
  const meterPercentEl = document.getElementById('tracker-meter-percent');
  const meterCeilingEl = document.getElementById('tracker-meter-ceiling');
  const meterFill = document.getElementById('tracker-meter-fill');
  const alertBanner = document.getElementById('tracker-budget-alert');
  const alertMsg = document.getElementById('tracker-alert-message');

  if (meterPercentEl) meterPercentEl.textContent = `${meterPercent}%`;
  if (meterCeilingEl) meterCeilingEl.textContent = `Max Ceiling: ₱${formatNumber(maxBudget)}`;
  if (meterFill) {
    meterFill.style.width = `${meterPercent}%`;
    meterFill.className = 'meter-fill' + (meterPercent >= 100 ? ' overflow' : (meterPercent >= 85 ? ' warning' : ''));
  }

  if (alertBanner) {
    if (remainingBudget < 0) {
      alertBanner.style.display = 'flex';
      if (alertMsg) {
        alertMsg.textContent = `Planned expenses (₱${formatNumber(totalPlannedSpent)}) exceed your ₱${formatNumber(maxBudget)} ceiling by ₱${formatNumber(Math.abs(remainingBudget))}. Consider swapping paid attractions for free favorites like Burnham Park, Wright Park, or The Mansion!`;
      }
    } else {
      alertBanner.style.display = 'none';
    }
  }

  // 3. Render Day Filter Tabs
  renderDayFilterTabs(days);

  // 4. Render Chronological Day-by-Day Timeline
  renderTimelineDays(days, stops);
}

/**
 * Generates Day Tabs ("All Days", "Day 1", "Day 2"...)
 */
function renderDayFilterTabs(daysCount) {
  const tabsContainer = document.getElementById('itinerary-day-tabs');
  if (!tabsContainer) return;

  let tabsHTML = `<button type="button" class="day-tab-pill ${activeDayFilter === 'all' ? 'active' : ''}" data-day="all">All Days (${daysCount})</button>`;
  for (let i = 1; i <= daysCount; i++) {
    const isActive = activeDayFilter === String(i);
    tabsHTML += `<button type="button" class="day-tab-pill ${isActive ? 'active' : ''}" data-day="${i}">Day ${i}</button>`;
  }

  tabsContainer.innerHTML = tabsHTML;

  tabsContainer.querySelectorAll('.day-tab-pill').forEach(btn => {
    btn.addEventListener('click', () => {
      activeDayFilter = btn.getAttribute('data-day');
      renderItineraryWorkspace();
    });
  });
}

/**
 * Calculates day index (1-based) from stop date and trip startDate
 */
function getStopDayIndex(stopDateStr) {
  const startDateStr = appState.trip.startDate || getTodayDateString();
  const start = new Date(startDateStr);
  const stopDate = new Date(stopDateStr);
  const diffDays = Math.floor((stopDate - start) / (1000 * 60 * 60 * 24));
  return Math.max(1, Math.min(appState.trip.days || 2, diffDays + 1));
}

/**
 * Computes calendar date string for Day N
 */
function getDateForDay(dayIndex) {
  const startDateStr = appState.trip.startDate || getTodayDateString();
  const date = new Date(startDateStr);
  date.setDate(date.getDate() + (dayIndex - 1));
  return date.toISOString().split('T')[0];
}

/**
 * Clash detector: identifies overlapping time windows on the same date
 */
function findItineraryClashes(stops) {
  const clashMap = {};
  for (let i = 0; i < stops.length; i++) {
    const s1 = stops[i];
    const start1 = timeToMinutes(s1.time);
    const end1 = start1 + (Number(s1.duration) || 90);

    for (let j = i + 1; j < stops.length; j++) {
      const s2 = stops[j];
      if (s1.date !== s2.date) continue;

      const start2 = timeToMinutes(s2.time);
      const end2 = start2 + (Number(s2.duration) || 90);

      if (start1 < end2 && start2 < end1) {
        clashMap[s1.id] = {
          withName: s2.destinationName || 'Another Stop',
          timeRange: `${s2.time} – ${minutesToTime(end2)}`
        };
        clashMap[s2.id] = {
          withName: s1.destinationName || 'Another Stop',
          timeRange: `${s1.time} – ${minutesToTime(end1)}`
        };
      }
    }
  }
  return clashMap;
}

/**
 * Renders the day sections and timeline stop cards
 */
function renderTimelineDays(daysCount, stops) {
  const container = document.getElementById('itinerary-days-list');
  if (!container) return;

  sortItineraryChronologically();
  const clashesMap = findItineraryClashes(stops);

  let html = '';

  for (let dayNum = 1; dayNum <= daysCount; dayNum++) {
    if (activeDayFilter !== 'all' && activeDayFilter !== String(dayNum)) {
      continue;
    }

    const dayDateStr = getDateForDay(dayNum);
    const formattedDate = formatDate(dayDateStr);

    const dayStops = stops.filter(s => {
      if (s.date === dayDateStr) return true;
      return getStopDayIndex(s.date) === dayNum;
    });

    const dayFeesSum = dayStops.reduce((sum, s) => {
      const d = sampleDestinations.find(dest => dest.id === s.destinationId);
      return sum + (d ? Number(d.fee) || 0 : (Number(s.fee) || 0));
    }, 0);

    const totalMinutes = dayStops.reduce((sum, s) => sum + (Number(s.duration) || 90), 0);
    const hours = Math.floor(totalMinutes / 60);
    const mins = totalMinutes % 60;
    const timeTotalStr = hours > 0 ? `${hours}h ${mins > 0 ? mins + 'm' : ''}` : `${mins}m`;

    html += `
      <section class="itinerary-day-section" data-day="${dayNum}">
        <div class="day-section-header">
          <div class="day-section-title-wrap">
            <h3 class="day-section-title">Day ${dayNum}</h3>
            <span class="day-section-date">· ${formattedDate}</span>
            <div class="day-meta-pills">
              <span class="day-meta-pill">${dayStops.length} Stop${dayStops.length === 1 ? '' : 's'}</span>
              <span class="day-meta-pill">⏱️ ${timeTotalStr}</span>
              <span class="day-meta-pill">🎟️ ${dayFeesSum === 0 ? 'Free Entry' : '₱' + formatNumber(dayFeesSum)}</span>
            </div>
          </div>
          <button type="button" class="day-add-stop-btn" data-day="${dayNum}">
            + Add to Day ${dayNum}
          </button>
        </div>

        <div class="day-stops-list">
    `;

    if (dayStops.length === 0) {
      html += `
        <div class="empty-day-banner">
          <p class="empty-day-text">No planned destinations scheduled for Day ${dayNum} yet.</p>
          <button type="button" class="btn btn-sm btn-outline day-add-stop-btn" data-day="${dayNum}">
            + Add First Stop to Day ${dayNum}
          </button>
        </div>
      `;
    } else {
      dayStops.forEach((stop) => {
        const dest = sampleDestinations.find(d => d.id === stop.destinationId) || {
          name: stop.destinationName || 'Destination',
          category: stop.category || 'Sightseeing',
          fee: stop.fee || 0,
          image: 'assets/images/burnham-park.jpg',
          area: 'Baguio City'
        };

        const duration = Number(stop.duration) || 90;
        const startMins = timeToMinutes(stop.time);
        const endMins = startMins + duration;
        const startTimeStr = stop.time || '09:00';
        const endTimeStr = minutesToTime(endMins);

        const fee = dest.fee || 0;
        const clashInfo = clashesMap[stop.id];

        html += `
          <div class="itinerary-stop-card" data-stop-id="${stop.id}">
            <!-- Time Col -->
            <div class="stop-time-col">
              <span class="stop-time-val">${startTimeStr}</span>
              <span class="stop-time-end">to ${endTimeStr}</span>
              <span class="stop-dur-pill">${duration}m</span>
            </div>

            <!-- Thumbnail -->
            <img src="${dest.image}" alt="${escapeHTML(dest.name)}" class="stop-thumb-img" loading="lazy">

            <!-- Content Col -->
            <div class="stop-info-col">
              <div class="stop-title-row">
                <h4 class="stop-dest-title">${escapeHTML(dest.name)}</h4>
                <span class="${fee > 0 ? 'badge-fee-paid' : 'badge-fee-free'}">
                  ${fee > 0 ? '₱' + formatNumber(fee) : 'Free Entry'}
                </span>
              </div>
              <div class="stop-meta-tags">
                <span class="stop-category-tag">${escapeHTML(dest.category)}</span>
                <span class="stop-area-tag">📍 ${escapeHTML(dest.area || dest.location || 'Baguio')}</span>
              </div>
              ${stop.activity ? `<p class="stop-activity-text">🎯 ${escapeHTML(stop.activity)}</p>` : ''}
              ${clashInfo ? `<div class="stop-clash-warning">⚠️ Overlaps with ${escapeHTML(clashInfo.withName)} (${clashInfo.timeRange})</div>` : ''}
            </div>

            <!-- Actions Col -->
            <div class="stop-actions-col">
              <button type="button" class="btn-icon-action btn-move-stop" data-dir="up" data-stop-id="${stop.id}" title="Move earlier in time">↑</button>
              <button type="button" class="btn-icon-action btn-move-stop" data-dir="down" data-stop-id="${stop.id}" title="Move later in time">↓</button>
              <button type="button" class="btn-icon-action btn-edit-stop" data-stop-id="${stop.id}" title="Edit stop details">✏️</button>
              <button type="button" class="btn-icon-action action-delete btn-delete-stop" data-stop-id="${stop.id}" title="Remove stop">🗑️</button>
            </div>
          </div>
        `;
      });
    }

    html += `
        </div>
      </section>
    `;
  }

  container.innerHTML = html;

  // Attach card event listeners
  container.querySelectorAll('.day-add-stop-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const day = btn.getAttribute('data-day');
      openStopEditor({ day });
    });
  });

  container.querySelectorAll('.btn-edit-stop').forEach(btn => {
    btn.addEventListener('click', () => {
      const stopId = btn.getAttribute('data-stop-id');
      openStopEditor({ stopId });
    });
  });

  container.querySelectorAll('.btn-delete-stop').forEach(btn => {
    btn.addEventListener('click', () => {
      const stopId = btn.getAttribute('data-stop-id');
      deleteStop(stopId);
    });
  });

  container.querySelectorAll('.btn-move-stop').forEach(btn => {
    btn.addEventListener('click', () => {
      const stopId = btn.getAttribute('data-stop-id');
      const dir = btn.getAttribute('data-dir');
      reorderStop(stopId, dir);
    });
  });
}

/**
 * Removes a stop and offers an Undo toast
 */
function deleteStop(stopId) {
  const index = appState.itinerary.findIndex(s => s.id === stopId);
  if (index === -1) return;

  const deleted = appState.itinerary.splice(index, 1)[0];
  appState.lastDeletedStop = deleted;
  saveData();
  renderItineraryWorkspace();

  showToast(`Removed "${deleted.destinationName || 'stop'}".`, 'info', true);
}

/**
 * Undoes previous delete
 */
function undoDeleteStop() {
  if (!appState.lastDeletedStop) return;
  appState.itinerary.push(appState.lastDeletedStop);
  appState.lastDeletedStop = null;
  sortItineraryChronologically();
  saveData();
  renderItineraryWorkspace();
  showToast('Restored stop.', 'success');
}

/**
 * Reorders a stop earlier or later in time
 */
function reorderStop(stopId, direction) {
  const stop = appState.itinerary.find(s => s.id === stopId);
  if (!stop) return;

  const currentMins = timeToMinutes(stop.time);
  const delta = direction === 'up' ? -30 : 30;
  const newMins = Math.max(360, Math.min(1380, currentMins + delta)); // between 06:00 and 23:00

  stop.time = minutesToTime(newMins);
  sortItineraryChronologically();
  saveData();
  renderItineraryWorkspace();
}

/**
 * Loads a curated 2-day Baguio itinerary that fits within the budget
 */
function loadSampleItinerary() {
  const startDate = appState.trip.startDate || getTodayDateString();
  const dateDay1 = getDateForDay(1);
  const dateDay2 = getDateForDay(2);

  appState.trip.days = Math.max(2, appState.trip.days || 2);

  appState.itinerary = [
    // Day 1
    {
      id: generateUniqueId(),
      destinationId: 3, // Wright Park
      destinationName: 'Wright Park',
      category: 'Nature & Parks',
      fee: 0,
      date: dateDay1,
      time: '09:00',
      duration: 60,
      activity: 'Morning stroll along the Pool of Pines'
    },
    {
      id: generateUniqueId(),
      destinationId: 4, // The Mansion
      destinationName: 'The Mansion',
      category: 'Historical & Cultural',
      fee: 0,
      date: dateDay1,
      time: '10:15',
      duration: 45,
      activity: 'Sightseeing at the presidential summer palace gates'
    },
    {
      id: generateUniqueId(),
      destinationId: 2, // Mines View Park
      destinationName: 'Mines View Park',
      category: 'Viewpoints',
      fee: 10,
      date: dateDay1,
      time: '11:30',
      duration: 90,
      activity: 'Panoramic ridge views and buying Good Shepherd strawberry jam'
    },
    {
      id: generateUniqueId(),
      destinationId: 5, // Baguio Night Market
      destinationName: 'Baguio Night Market',
      category: 'Shopping & Markets',
      fee: 0,
      date: dateDay1,
      time: '19:00',
      duration: 90,
      activity: 'Street food tasting, strawberry taho, and thrift shopping'
    },
    // Day 2
    {
      id: generateUniqueId(),
      destinationId: 1, // Burnham Park
      destinationName: 'Burnham Park',
      category: 'Nature & Parks',
      fee: 0,
      date: dateDay2,
      time: '09:00',
      duration: 90,
      activity: 'Swan paddleboat lagoon rowing and rose garden walk'
    },
    {
      id: generateUniqueId(),
      destinationId: 6, // Camp John Hay
      destinationName: 'Camp John Hay',
      category: 'Nature & Parks',
      fee: 80,
      date: dateDay2,
      time: '11:00',
      duration: 120,
      activity: 'Trekking the Yellow Trail and visiting Bell Amphitheater'
    },
    {
      id: generateUniqueId(),
      destinationId: 7, // Baguio Botanical Garden
      destinationName: 'Baguio Botanical Garden',
      category: 'Nature & Parks',
      fee: 10,
      date: dateDay2,
      time: '14:30',
      duration: 60,
      activity: 'Exploring Igorot cultural village replicas and indigenous pines'
    }
  ];

  sortItineraryChronologically();
  saveData();
  renderItineraryWorkspace();

  showToast('Loaded sample 2-day Baguio itinerary!', 'success');
}

/**
 * Clears all itinerary stops after user confirmation
 */
function clearItinerary() {
  openConfirmDialog(
    'Clear All Itinerary Stops?',
    'Are you sure you want to remove all planned stops? Your established budget settings will remain intact.',
    () => {
      appState.itinerary = [];
      saveData();
      renderItineraryWorkspace();
      showToast('Itinerary stops cleared.', 'info');
    }
  );
}

/**
 * Setup Stop Editor Modal dialog and controls
 */
function setupStopEditorModal() {
  const modal = document.getElementById('stop-editor-modal');
  const backdrop = document.getElementById('stop-editor-backdrop');
  const closeBtn = document.getElementById('stop-modal-close');
  const cancelBtn = document.getElementById('btn-cancel-stop-modal');
  const form = document.getElementById('stop-editor-form');

  const destSelect = document.getElementById('stop-destination-select');
  const btnFilterAll = document.getElementById('btn-dest-filter-all');
  const btnFilterFavs = document.getElementById('btn-dest-filter-favs');
  const daySelect = document.getElementById('stop-day-select');
  const dateInput = document.getElementById('stop-date-input');
  const timeInput = document.getElementById('stop-time-input');
  const durInput = document.getElementById('stop-duration-input');
  const activityInput = document.getElementById('stop-activity-input');

  const previewStrip = document.getElementById('stop-dest-preview-strip');
  const previewImg = document.getElementById('stop-preview-img');
  const previewName = document.getElementById('stop-preview-name');
  const previewCat = document.getElementById('stop-preview-category');
  const previewFee = document.getElementById('stop-preview-fee');
  const previewArea = document.getElementById('stop-preview-area');

  const suggRow = document.getElementById('stop-activity-suggestions');
  const suggChipsWrap = document.getElementById('stop-suggestions-chips');

  const impactFee = document.getElementById('modal-impact-fee');
  const impactRemaining = document.getElementById('modal-impact-remaining');

  let currentDestFilter = 'all';

  const populateDestPicker = (selectedId = null) => {
    if (!destSelect) return;
    let list = sampleDestinations;
    if (currentDestFilter === 'favs') {
      const favList = sampleDestinations.filter(d => appState.favorites.includes(d.id));
      if (favList.length > 0) list = favList;
    }

    destSelect.innerHTML = '<option value="">-- Choose a Baguio Destination --</option>' +
      list.map(d => {
        const feeStr = d.fee > 0 ? `₱${d.fee}` : 'Free';
        return `<option value="${d.id}">${escapeHTML(d.name)} (${escapeHTML(d.category)}) — ${feeStr}</option>`;
      }).join('');

    if (selectedId) {
      destSelect.value = selectedId;
    }
  };

  const updateDestPreview = () => {
    const destId = Number(destSelect.value);
    const dest = sampleDestinations.find(d => d.id === destId);
    if (!dest) {
      if (previewStrip) previewStrip.style.display = 'none';
      if (suggRow) suggRow.style.display = 'none';
      if (impactFee) impactFee.textContent = '₱0';
      return;
    }

    if (previewStrip) previewStrip.style.display = 'flex';
    if (previewImg) previewImg.src = dest.image;
    if (previewName) previewName.textContent = dest.name;
    if (previewCat) previewCat.textContent = dest.category;
    if (previewFee) {
      previewFee.textContent = dest.fee > 0 ? `₱${dest.fee}` : 'Free Entry';
      previewFee.className = `badge ${dest.fee > 0 ? 'badge-fee-paid' : 'badge-fee-free'}`;
    }
    if (previewArea) previewArea.textContent = dest.area || dest.location;

    // Suggestions chips
    if (suggRow && suggChipsWrap) {
      if (dest.activities && dest.activities.length) {
        suggRow.style.display = 'flex';
        suggChipsWrap.innerHTML = dest.activities.map(act => `
          <button type="button" class="sugg-chip" data-act="${escapeHTML(act)}">${escapeHTML(act)}</button>
        `).join('');

        suggChipsWrap.querySelectorAll('.sugg-chip').forEach(chip => {
          chip.addEventListener('click', () => {
            activityInput.value = chip.getAttribute('data-act');
          });
        });
      } else {
        suggRow.style.display = 'none';
      }
    }

    // Modal Budget Impact
    const currentFee = dest.fee || 0;
    if (impactFee) impactFee.textContent = currentFee > 0 ? `₱${formatNumber(currentFee)}` : 'Free Entry';

    const maxBudget = appState.trip.budgetMax || 3500;
    const baseCost = Math.round(maxBudget * 0.80);
    const currentStopsFees = appState.itinerary
      .filter(s => s.id !== stopEditorTargetId)
      .reduce((sum, s) => {
        const d = sampleDestinations.find(item => item.id === s.destinationId);
        return sum + (d ? Number(d.fee) || 0 : (Number(s.fee) || 0));
      }, 0);

    const projectedRemaining = maxBudget - (baseCost + currentStopsFees + currentFee);
    if (impactRemaining) {
      impactRemaining.textContent = projectedRemaining >= 0 ? `₱${formatNumber(projectedRemaining)}` : `-₱${formatNumber(Math.abs(projectedRemaining))} (Over Limit)`;
      impactRemaining.style.color = projectedRemaining >= 0 ? '#10352b' : '#b91c1c';
    }
  };

  if (destSelect) {
    destSelect.addEventListener('change', updateDestPreview);
  }

  if (btnFilterAll && btnFilterFavs) {
    btnFilterAll.addEventListener('click', () => {
      currentDestFilter = 'all';
      btnFilterAll.classList.add('active');
      btnFilterFavs.classList.remove('active');
      const cur = destSelect.value;
      populateDestPicker(cur);
      updateDestPreview();
    });

    btnFilterFavs.addEventListener('click', () => {
      currentDestFilter = 'favs';
      btnFilterFavs.classList.add('active');
      btnFilterAll.classList.remove('active');
      const cur = destSelect.value;
      populateDestPicker(cur);
      updateDestPreview();
    });
  }

  if (daySelect && dateInput) {
    daySelect.addEventListener('change', () => {
      const dayNum = parseInt(daySelect.value, 10) || 1;
      dateInput.value = getDateForDay(dayNum);
    });

    dateInput.addEventListener('change', () => {
      const dayNum = getStopDayIndex(dateInput.value);
      daySelect.value = String(dayNum);
    });
  }

  const durChips = document.querySelectorAll('.duration-chip');
  durChips.forEach(chip => {
    chip.addEventListener('click', () => {
      durChips.forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      if (durInput) durInput.value = chip.getAttribute('data-dur');
    });
  });

  const closeModal = () => {
    if (modal) modal.style.display = 'none';
    stopEditorTargetId = null;
  };

  if (closeBtn) closeBtn.addEventListener('click', closeModal);
  if (backdrop) backdrop.addEventListener('click', closeModal);
  if (cancelBtn) cancelBtn.addEventListener('click', closeModal);

  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const destId = Number(destSelect.value);
      if (!destId) {
        showToast('Please select a destination.', 'warning');
        return;
      }

      const dest = sampleDestinations.find(d => d.id === destId);
      const scheduledDate = dateInput.value || getDateForDay(1);
      const startTime = timeInput.value || '09:00';
      const duration = Math.max(15, parseInt(durInput.value, 10) || 90);
      const activity = (activityInput.value || '').trim();

      if (stopEditorTargetId) {
        const stop = appState.itinerary.find(s => s.id === stopEditorTargetId);
        if (stop) {
          stop.destinationId = destId;
          stop.destinationName = dest.name;
          stop.category = dest.category;
          stop.fee = dest.fee || 0;
          stop.date = scheduledDate;
          stop.time = startTime;
          stop.duration = duration;
          stop.activity = activity;
          showToast(`Updated "${dest.name}"!`, 'success');
        }
      } else {
        const newStop = {
          id: generateUniqueId(),
          destinationId: destId,
          destinationName: dest.name,
          category: dest.category,
          fee: dest.fee || 0,
          date: scheduledDate,
          time: startTime,
          duration: duration,
          activity: activity
        };
        appState.itinerary.push(newStop);
        showToast(`Added "${dest.name}" to Day ${getStopDayIndex(scheduledDate)}!`, 'success');
      }

      sortItineraryChronologically();
      saveData();
      renderItineraryWorkspace();
      closeModal();
    });
  }
}

/**
 * Opens Stop Editor Modal for adding or editing
 */
function openStopEditor(options = {}) {
  const modal = document.getElementById('stop-editor-modal');
  if (!modal) return;

  const titleEl = document.getElementById('stop-modal-title');
  const destSelect = document.getElementById('stop-destination-select');
  const daySelect = document.getElementById('stop-day-select');
  const dateInput = document.getElementById('stop-date-input');
  const timeInput = document.getElementById('stop-time-input');
  const durInput = document.getElementById('stop-duration-input');
  const activityInput = document.getElementById('stop-activity-input');
  const favsCountEl = document.getElementById('stop-modal-favs-count');

  if (favsCountEl) favsCountEl.textContent = appState.favorites.length;

  const daysCount = appState.trip.days || 2;
  if (daySelect) {
    daySelect.innerHTML = Array.from({ length: daysCount }, (_, i) => i + 1)
      .map(d => `<option value="${d}">Day ${d}</option>`)
      .join('');
  }

  const btnFilterAll = document.getElementById('btn-dest-filter-all');
  const btnFilterFavs = document.getElementById('btn-dest-filter-favs');
  if (btnFilterAll) btnFilterAll.classList.add('active');
  if (btnFilterFavs) btnFilterFavs.classList.remove('active');

  destSelect.innerHTML = '<option value="">-- Choose a Baguio Destination --</option>' +
    sampleDestinations.map(d => {
      const feeStr = d.fee > 0 ? `₱${d.fee}` : 'Free';
      return `<option value="${d.id}">${escapeHTML(d.name)} (${escapeHTML(d.category)}) — ${feeStr}</option>`;
    }).join('');

  if (options.stopId) {
    stopEditorTargetId = options.stopId;
    if (titleEl) titleEl.textContent = 'Edit Itinerary Stop';
    const stop = appState.itinerary.find(s => s.id === options.stopId);
    if (stop) {
      if (destSelect) destSelect.value = stop.destinationId;
      const dayNum = getStopDayIndex(stop.date);
      if (daySelect) daySelect.value = String(dayNum);
      if (dateInput) dateInput.value = stop.date;
      if (timeInput) timeInput.value = stop.time;
      if (durInput) durInput.value = stop.duration || 90;
      if (activityInput) activityInput.value = stop.activity || '';
    }
  } else {
    stopEditorTargetId = null;
    if (titleEl) titleEl.textContent = 'Add Stop to Itinerary';
    const targetDay = options.day ? Number(options.day) : 1;
    if (daySelect) daySelect.value = String(targetDay);
    if (dateInput) dateInput.value = getDateForDay(targetDay);

    if (options.destinationId && destSelect) {
      destSelect.value = options.destinationId;
    } else if (destSelect) {
      destSelect.value = '';
    }

    if (timeInput) timeInput.value = '09:00';
    if (durInput) durInput.value = '90';
    if (activityInput) activityInput.value = '';
  }

  destSelect.dispatchEvent(new Event('change'));
  modal.style.display = 'flex';
}

/**
 * Event listeners and controls for Step 1 Budget Setup & Itinerary Planner
 */
function setupItineraryControls() {
  const sliderMin = document.getElementById('budget-slider-min');
  const sliderMax = document.getElementById('budget-slider-max');
  const numMin = document.getElementById('budget-num-min');
  const numMax = document.getElementById('budget-num-max');
  const daysInput = document.getElementById('budget-trip-days');
  const presetButtons = document.querySelectorAll('#budget-preset-buttons .btn-preset');
  const btnConfirm = document.getElementById('btn-confirm-budget');
  const btnEdit = document.getElementById('btn-edit-confirmed-budget');

  const btnOpenAddStop = document.getElementById('btn-open-add-stop-modal');
  const btnLoadSample = document.getElementById('btn-load-sample-itinerary');
  const btnClearItin = document.getElementById('btn-clear-itinerary');

  // Setup stop editor modal listeners
  setupStopEditorModal();

  // Planner Workspace Buttons
  if (btnOpenAddStop) {
    btnOpenAddStop.addEventListener('click', () => {
      openStopEditor();
    });
  }

  if (btnLoadSample) {
    btnLoadSample.addEventListener('click', loadSampleItinerary);
  }

  if (btnClearItin) {
    btnClearItin.addEventListener('click', clearItinerary);
  }

  // 1. Min Slider Input
  if (sliderMin && sliderMax && numMin && numMax) {
    sliderMin.addEventListener('pointerdown', () => {
      sliderMin.style.zIndex = '5';
      sliderMax.style.zIndex = '4';
    });
    sliderMax.addEventListener('pointerdown', () => {
      sliderMax.style.zIndex = '5';
      sliderMin.style.zIndex = '4';
    });

    sliderMin.addEventListener('input', () => {
      sliderMin.style.zIndex = '5';
      sliderMax.style.zIndex = '4';
      let minVal = parseInt(sliderMin.value, 10);
      const maxVal = parseInt(sliderMax.value, 10);

      if (minVal > maxVal - BUDGET_SLIDER_CONFIG.MIN_GAP) {
        minVal = maxVal - BUDGET_SLIDER_CONFIG.MIN_GAP;
        sliderMin.value = minVal;
      }

      numMin.value = minVal;
      const days = daysInput ? parseInt(daysInput.value, 10) || 2 : 2;
      updateBudgetCalculations(minVal, maxVal, days);
      updateSliderTrackHighlight(minVal, maxVal);
      highlightMatchingPreset(minVal, maxVal);
    });

    // 2. Max Slider Input
    sliderMax.addEventListener('input', () => {
      sliderMax.style.zIndex = '5';
      sliderMin.style.zIndex = '4';
      const minVal = parseInt(sliderMin.value, 10);
      let maxVal = parseInt(sliderMax.value, 10);

      if (maxVal < minVal + BUDGET_SLIDER_CONFIG.MIN_GAP) {
        maxVal = minVal + BUDGET_SLIDER_CONFIG.MIN_GAP;
        sliderMax.value = maxVal;
      }

      numMax.value = maxVal;
      const days = daysInput ? parseInt(daysInput.value, 10) || 2 : 2;
      updateBudgetCalculations(minVal, maxVal, days);
      updateSliderTrackHighlight(minVal, maxVal);
      highlightMatchingPreset(minVal, maxVal);
    });

    // 3. Min Number Input
    const handleMinNumChange = () => {
      let minVal = parseInt(numMin.value, 10) || BUDGET_SLIDER_CONFIG.MIN_ALLOWED;
      const maxVal = parseInt(numMax.value, 10) || 3500;

      if (minVal < BUDGET_SLIDER_CONFIG.MIN_ALLOWED) {
        minVal = BUDGET_SLIDER_CONFIG.MIN_ALLOWED;
      }
      if (minVal > maxVal - BUDGET_SLIDER_CONFIG.MIN_GAP) {
        minVal = maxVal - BUDGET_SLIDER_CONFIG.MIN_GAP;
      }

      numMin.value = minVal;
      sliderMin.value = minVal;
      const days = daysInput ? parseInt(daysInput.value, 10) || 2 : 2;
      updateBudgetCalculations(minVal, maxVal, days);
      updateSliderTrackHighlight(minVal, maxVal);
      highlightMatchingPreset(minVal, maxVal);
    };
    numMin.addEventListener('change', handleMinNumChange);
    numMin.addEventListener('blur', handleMinNumChange);

    // 4. Max Number Input
    const handleMaxNumChange = () => {
      const minVal = parseInt(numMin.value, 10) || BUDGET_SLIDER_CONFIG.MIN_ALLOWED;
      let maxVal = parseInt(numMax.value, 10) || 3500;

      if (maxVal > BUDGET_SLIDER_CONFIG.MAX_ALLOWED) {
        maxVal = BUDGET_SLIDER_CONFIG.MAX_ALLOWED;
      }
      if (maxVal < minVal + BUDGET_SLIDER_CONFIG.MIN_GAP) {
        maxVal = minVal + BUDGET_SLIDER_CONFIG.MIN_GAP;
      }

      numMax.value = maxVal;
      sliderMax.value = maxVal;
      const days = daysInput ? parseInt(daysInput.value, 10) || 2 : 2;
      updateBudgetCalculations(minVal, maxVal, days);
      updateSliderTrackHighlight(minVal, maxVal);
      highlightMatchingPreset(minVal, maxVal);
    };
    numMax.addEventListener('change', handleMaxNumChange);
    numMax.addEventListener('blur', handleMaxNumChange);
  }

  // 5. Trip Days Input
  if (daysInput) {
    const handleDaysChange = () => {
      let days = parseInt(daysInput.value, 10) || 2;
      if (days < 1) days = 1;
      if (days > 30) days = 30;
      daysInput.value = days;

      const minVal = numMin ? parseInt(numMin.value, 10) || 1500 : 1500;
      const maxVal = numMax ? parseInt(numMax.value, 10) || 3500 : 3500;
      updateBudgetCalculations(minVal, maxVal, days);
    };
    daysInput.addEventListener('input', handleDaysChange);
    daysInput.addEventListener('change', handleDaysChange);
  }

  // 6. Preset Buttons
  presetButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const pMin = parseInt(btn.getAttribute('data-min'), 10);
      const pMax = parseInt(btn.getAttribute('data-max'), 10);
      if (!pMin || !pMax) return;

      if (sliderMin) sliderMin.value = pMin;
      if (sliderMax) sliderMax.value = pMax;
      if (numMin) numMin.value = pMin;
      if (numMax) numMax.value = pMax;

      const days = daysInput ? parseInt(daysInput.value, 10) || 2 : 2;
      updateBudgetCalculations(pMin, pMax, days);
      updateSliderTrackHighlight(pMin, pMax);
      highlightMatchingPreset(pMin, pMax);
    });
  });

  // 7. Confirm Budget Action
  if (btnConfirm) {
    btnConfirm.addEventListener('click', () => {
      const minVal = numMin ? parseInt(numMin.value, 10) || 1500 : 1500;
      const maxVal = numMax ? parseInt(numMax.value, 10) || 3500 : 3500;
      const days = daysInput ? parseInt(daysInput.value, 10) || 2 : 2;

      if (minVal > maxVal) {
        showToast('Minimum budget cannot exceed maximum budget.', 'warning');
        return;
      }

      appState.trip.budgetMin = minVal;
      appState.trip.budgetMax = maxVal;
      appState.trip.days = days;
      appState.trip.budgetConfirmed = true;
      appState.hasConfirmedBudget = true;

      saveData();
      localStorage.setItem('lakbay_budget_range', JSON.stringify({
        min: minVal,
        max: maxVal,
        days: days,
        confirmed: true
      }));

      renderItineraryList();
      showToast(`Budget established: ₱${formatNumber(minVal)} – ₱${formatNumber(maxVal)} (${days} Days)`, 'success');
    });
  }

  // 8. Edit Confirmed Budget Action
  if (btnEdit) {
    btnEdit.addEventListener('click', () => {
      appState.hasConfirmedBudget = false;
      appState.trip.budgetConfirmed = false;
      saveData();

      const selectorView = document.getElementById('budget-selector-view');
      const confirmedView = document.getElementById('budget-confirmed-view');
      if (selectorView) selectorView.style.display = 'block';
      if (confirmedView) confirmedView.style.display = 'none';

      syncBudgetInputsFromState();

      if (numMin) numMin.focus();
    });
  }
}

/**
 * Integration Stubs for Other Screens (Explore / Details / Favorites / Summary)
 */
function prefillItineraryForm(destId) {
  showSection('itinerary');
  const dest = sampleDestinations.find(d => d.id === destId);
  const destName = dest ? dest.name : 'Destination';

  if (!appState.hasConfirmedBudget) {
    showToast(`Please confirm your estimated budget first before planning "${destName}".`, 'info');
  } else {
    openStopEditor({ destinationId: destId });
  }
}

function openQuickAddPopover(destId, anchorBtn) {
  prefillItineraryForm(destId);
}

function setupQuickAddPopover() {
  // Integrated into stop-editor-modal
}

function setupDestinationDropdown() {
  // Handled inside stop editor
}

function sortItineraryChronologically() {
  if (!Array.isArray(appState.itinerary)) return;
  appState.itinerary.sort((a, b) => {
    if (a.date !== b.date) return (a.date || '').localeCompare(b.date || '');
    return (a.time || '').localeCompare(b.time || '');
  });
}

/**
 * Text export formatter for Screen 6
 */
function copyPlanAsText() {
  const trip = appState.trip;
  const stops = appState.itinerary;
  const days = trip.days || 2;
  const nights = Math.max(1, days - 1);
  const minBudget = trip.budgetMin || 1500;
  const maxBudget = trip.budgetMax || 3500;

  const totalFees = stops.reduce((sum, s) => {
    const d = sampleDestinations.find(dest => dest.id === s.destinationId);
    return sum + (d ? Number(d.fee) || 0 : (Number(s.fee) || 0));
  }, 0);

  let text = `=================================================\n`;
  text += `LAKBAY PH — ${(trip.name || 'BAGUIO MOUNTAIN HOLIDAY').toUpperCase()}\n`;
  text += `=================================================\n`;
  text += `Destination: ${trip.city || 'Baguio City'}\n`;
  text += `Duration: ${days} Day(s) (${nights} Night(s))\n`;
  text += `Budget Limit: ₱${formatNumber(minBudget)} – ₱${formatNumber(maxBudget)}\n`;
  text += `Total Entrance Fees: ₱${formatNumber(totalFees)}\n`;
  text += `=================================================\n\n`;

  if (stops.length === 0) {
    text += `No stops scheduled yet.\n`;
  } else {
    const uniqueDates = [...new Set(stops.map(s => s.date))].sort();
    uniqueDates.forEach((dateStr, idx) => {
      const dayStops = stops.filter(s => s.date === dateStr);
      text += `Day ${idx + 1} (${formatDate(dateStr)}):\n`;
      dayStops.forEach((s, sIdx) => {
        const d = sampleDestinations.find(item => item.id === s.destinationId);
        const feeStr = (d && d.fee > 0) ? `₱${d.fee}` : 'Free';
        const end = minutesToTime(timeToMinutes(s.time) + (s.duration || 90));
        text += `  ${sIdx + 1}. ${s.time} – ${end} | ${s.destinationName} (${feeStr})\n`;
        if (s.activity) text += `     Activity: ${s.activity}\n`;
      });
      text += `\n`;
    });
  }

  if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
    navigator.clipboard.writeText(text).then(() => {
      showToast('Travel plan copied to clipboard!', 'success');
    }).catch(() => {
      fallbackCopyText(text);
    });
  } else {
    fallbackCopyText(text);
  }
}

function fallbackCopyText(text) {
  const textarea = document.createElement('textarea');
  textarea.value = text;
  textarea.style.position = 'fixed';
  textarea.style.left = '-9999px';
  document.body.appendChild(textarea);
  textarea.select();
  try {
    document.execCommand('copy');
    showToast('Travel plan copied to clipboard!', 'success');
  } catch (err) {
    showToast('Failed to copy to clipboard.', 'danger');
  }
  document.body.removeChild(textarea);
}

JS;

$newContent = substr($content, 0, $posStart) . $newScreen4 . "\n\n" . substr($content, $posEnd);

file_put_contents($jsPath, $newContent);
echo "Successfully updated Screen 4 in $jsPath! New size: " . strlen($newContent) . " bytes\n";
