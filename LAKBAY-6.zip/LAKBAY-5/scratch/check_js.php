<?php
$js = file_get_contents('c:/xampp/htdocs/LAKBAY-5/js/app.js');
$open = substr_count($js, '{');
$close = substr_count($js, '}');
echo 'Opening braces: ' . $open . PHP_EOL;
echo 'Closing braces: ' . $close . PHP_EOL;
echo 'Difference: ' . ($open - $close) . PHP_EOL;
$lines = count(explode(PHP_EOL, $js));
echo 'Total lines: ' . $lines . PHP_EOL;
echo 'File size: ' . strlen($js) . ' bytes' . PHP_EOL;

// Check for common issues
$parens_open = substr_count($js, '(');
$parens_close = substr_count($js, ')');
echo 'Parens open: ' . $parens_open . PHP_EOL;
echo 'Parens close: ' . $parens_close . PHP_EOL;
echo 'Parens diff: ' . ($parens_open - $parens_close) . PHP_EOL;
