<?php
$html = file_get_contents('index.html');

// 1. Replace placeholder inside budget-confirmed-view
$oldConfirmedPattern = '/<!-- 2\. CONFIRMED BUDGET STATE VIEW.*?<div class="card budget-confirmed-card" id="budget-confirmed-view".*?<\/div>\s*<\/div>\s*<\/section>/s';

$newConfirmedView = <<<'HTML'
        <!-- 2. CONFIRMED BUDGET & ITINERARY PLANNING WORKSPACE -->
        <div class="card budget-confirmed-card" id="budget-confirmed-view" style="display: none;">
          
          <!-- Top Row: Status, Trip Duration & Actions -->
          <div class="confirmed-badge-row">
            <div class="confirmed-status-group">
              <span class="confirmed-badge">&#10003; Budget Established</span>
              <span class="confirmed-trip-title" id="confirmed-trip-title">Baguio City Trip</span>
            </div>
            <div class="confirmed-actions-group">
              <button type="button" class="btn btn-outline btn-sm" id="btn-edit-confirmed-budget" title="Change your minimum and maximum budget">
                &#9998; Edit Budget
              </button>
              <button type="button" class="btn btn-outline btn-sm" id="btn-load-sample-itinerary" title="Load sample 2-day plan">
                &#10024; Load Sample Plan
              </button>
              <button type="button" class="btn btn-outline btn-sm text-danger" id="btn-clear-itinerary" title="Clear all stops">
                &#128465; Clear All
              </button>
            </div>
          </div>

          <!-- Live Integrated Budget Tracker Panel -->
          <div class="budget-tracker-panel">
            <div class="budget-tracker-stats-grid">
              <div class="tracker-stat-box">
                <span class="tracker-stat-label">SELECTED BUDGET RANGE</span>
                <strong class="tracker-stat-val" id="confirmed-budget-display">&#8369;1,500 – &#8369;3,500</strong>
                <span class="tracker-stat-sub" id="confirmed-days-display">2 Days</span>
              </div>
              <div class="tracker-stat-box">
                <span class="tracker-stat-label">STOPS ENTRANCE FEES</span>
                <strong class="tracker-stat-val text-primary" id="tracker-stops-fees">&#8369;0</strong>
                <span class="tracker-stat-sub" id="tracker-stops-count">0 stops planned</span>
              </div>
              <div class="tracker-stat-box">
                <span class="tracker-stat-label">EST. BASE LIVING COST</span>
                <strong class="tracker-stat-val" id="tracker-base-living">&#8369;2,800</strong>
                <span class="tracker-stat-sub">Food, stays &amp; transit</span>
              </div>
              <div class="tracker-stat-box highlight-box" id="tracker-remaining-box">
                <span class="tracker-stat-label">REMAINING BUDGET</span>
                <strong class="tracker-stat-val" id="tracker-remaining-budget">&#8369;700</strong>
                <span class="tracker-stat-sub" id="tracker-remaining-status">Within Budget &#10003;</span>
              </div>
            </div>

            <!-- Progress Meter & Alert -->
            <div class="budget-meter-wrap">
              <div class="meter-labels-row">
                <span class="meter-text-left">Budget Allocation: <strong id="tracker-meter-percent">80%</strong></span>
                <span class="meter-text-right" id="tracker-meter-ceiling">Max Ceiling: &#8369;3,500</span>
              </div>
              <div class="meter-track">
                <div class="meter-fill" id="tracker-meter-fill" style="width: 80%;"></div>
              </div>
              <div class="budget-alert-banner" id="tracker-budget-alert" style="display: none;">
                <span class="alert-icon">&#9888;&#65039;</span>
                <span class="alert-message" id="tracker-alert-message">Planned expenses exceed your maximum budget limit.</span>
              </div>
            </div>
          </div>

          <!-- Planner Workspace Header & Day Filter Tabs -->
          <div class="itinerary-workspace-header">
            <div class="day-filter-tabs" id="itinerary-day-tabs">
              <button type="button" class="day-tab-pill active" data-day="all">All Days</button>
              <button type="button" class="day-tab-pill" data-day="1">Day 1</button>
              <button type="button" class="day-tab-pill" data-day="2">Day 2</button>
            </div>
            <button type="button" class="btn btn-primary" id="btn-open-add-stop-modal">
              + Add Stop to Plan
            </button>
          </div>

          <!-- Day-by-Day Stops Container -->
          <div class="itinerary-days-container" id="itinerary-days-list">
            <!-- Dynamically populated by renderTimelineDays() -->
          </div>

        </div>

      </div>
    </section>
HTML;

$html = preg_replace($oldConfirmedPattern, $newConfirmedView, $html, 1, $c1);
echo "Confirmed view replacement count: $c1\n";

// 2. Add Stop Editor Modal before <!-- Toast Notification Center
$modalHtml = <<<'MODAL'
  <!-- ==================== ADD / EDIT ITINERARY STOP MODAL ==================== -->
  <div class="modal-overlay" id="stop-editor-modal" role="dialog" aria-modal="true" aria-hidden="true" style="display: none;">
    <div class="modal-backdrop" id="stop-editor-backdrop"></div>
    <div class="modal-dialog modal-dialog-md">
      <div class="modal-content">
        <div class="modal-header">
          <h3 class="modal-title" id="stop-modal-title">Add Stop to Itinerary</h3>
          <button type="button" class="modal-close-btn" id="stop-modal-close" aria-label="Close dialog">&times;</button>
        </div>
        
        <form id="stop-editor-form" novalidate onsubmit="return false;">
          <input type="hidden" id="stop-edit-id" value="">

          <!-- Destination Selector -->
          <div class="form-group">
            <div class="dest-picker-header">
              <label for="stop-destination-select" class="form-label">Destination</label>
              <div class="dest-filter-toggle">
                <button type="button" class="dest-toggle-pill active" id="btn-dest-filter-all">All Baguio Spots (20)</button>
                <button type="button" class="dest-toggle-pill" id="btn-dest-filter-favs">Favorites (<span id="stop-modal-favs-count">0</span>)</button>
              </div>
            </div>
            <select id="stop-destination-select" class="form-select form-input-lg" required>
              <!-- Populated dynamically -->
            </select>
          </div>

          <!-- Selected Destination Preview Strip -->
          <div class="dest-preview-strip" id="stop-dest-preview-strip" style="display: none;">
            <img id="stop-preview-img" src="" alt="Destination photo" class="dest-preview-thumb">
            <div class="dest-preview-meta">
              <strong id="stop-preview-name">Destination Name</strong>
              <div class="dest-preview-tags">
                <span class="badge" id="stop-preview-category">Category</span>
                <span class="badge badge-fee" id="stop-preview-fee">Free</span>
                <span class="preview-area-text" id="stop-preview-area">Area</span>
              </div>
            </div>
          </div>

          <!-- Schedule Grid: Day, Date, Time, Duration -->
          <div class="form-row-2col">
            <div class="form-group">
              <label for="stop-day-select" class="form-label">Trip Day</label>
              <select id="stop-day-select" class="form-select">
                <!-- Populated dynamically: Day 1, Day 2... -->
              </select>
            </div>
            <div class="form-group">
              <label for="stop-date-input" class="form-label">Scheduled Date</label>
              <input type="date" id="stop-date-input" class="form-input" required>
            </div>
          </div>

          <div class="form-row-2col">
            <div class="form-group">
              <label for="stop-time-input" class="form-label">Start Time</label>
              <input type="time" id="stop-time-input" class="form-input" value="09:00" required>
            </div>
            <div class="form-group">
              <label for="stop-duration-input" class="form-label">Duration (Minutes)</label>
              <div class="duration-input-wrap">
                <input type="number" id="stop-duration-input" class="form-input" value="90" min="15" max="480" step="15" required>
                <div class="duration-quick-chips">
                  <button type="button" class="duration-chip" data-dur="45">45m</button>
                  <button type="button" class="duration-chip" data-dur="60">1h</button>
                  <button type="button" class="duration-chip active" data-dur="90">1.5h</button>
                  <button type="button" class="duration-chip" data-dur="120">2h</button>
                </div>
              </div>
            </div>
          </div>

          <!-- Activity / Notes -->
          <div class="form-group">
            <label for="stop-activity-input" class="form-label">
              Planned Activity / Notes <span class="form-optional">(Optional)</span>
            </label>
            <input type="text" id="stop-activity-input" class="form-input" placeholder="e.g. Boating on Burnham Lake, photography, local food...">
            <!-- Quick suggestions from destination's signature activities -->
            <div class="activity-suggestions-row" id="stop-activity-suggestions" style="display: none;">
              <span class="sugg-label">Suggested:</span>
              <div class="sugg-chips-wrap" id="stop-suggestions-chips"></div>
            </div>
          </div>

          <!-- Budget Impact Alert in Modal -->
          <div class="modal-budget-impact" id="stop-budget-impact">
            <span class="impact-fee-tag">Entrance Fee: <strong id="modal-impact-fee">&#8369;0</strong></span>
            <span class="impact-remaining-tag">Est. Remaining Budget: <strong id="modal-impact-remaining">&#8369;700</strong></span>
          </div>

          <!-- Actions -->
          <div class="modal-actions-footer">
            <button type="button" class="btn btn-outline" id="btn-cancel-stop-modal">Cancel</button>
            <button type="submit" class="btn btn-primary" id="btn-save-stop">Save Stop to Itinerary</button>
          </div>
        </form>
      </div>
    </div>
  </div>

MODAL;

if (strpos($html, 'id="stop-editor-modal"') === false) {
    $html = str_replace('<!-- Toast Notification Center', $modalHtml . "\n  <!-- Toast Notification Center", $html);
    echo "Added stop-editor-modal!\n";
}

file_put_contents('index.html', $html);
echo "Successfully updated index.html! New length: " . strlen($html) . "\n";
