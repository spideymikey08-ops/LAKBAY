/**
 * Lakbay | Screen 3: Destination Details Modal
 * Details dialog with focus trap and focus restore.
 */
'use strict';

/* ==========================================================================
   SCREEN 3: DESTINATION DETAILS MODAL (Focus Trap & Information Rich)
   ========================================================================== */
function setupModalControls() {
  const modal = document.getElementById('destination-modal');
  const closeBtn = document.getElementById('modal-close-btn');
  const backdrop = document.getElementById('modal-backdrop');
  const itineraryBtn = document.getElementById('modal-itinerary-btn');

  if (closeBtn) closeBtn.addEventListener('click', closeDetails);
  if (backdrop) backdrop.addEventListener('click', closeDetails);

  // Accessible Escape & Focus Trap
  document.addEventListener('keydown', (e) => {
    if (modal && modal.style.display !== 'none') {
      if (e.key === 'Escape') {
        closeDetails();
        return;
      }
      if (e.key === 'Tab') {
        trapFocusInDialog(modal, e);
      }
    }
  });

  // Modal Add to Itinerary
  if (itineraryBtn) {
    itineraryBtn.addEventListener('click', () => {
      if (appState.modalDestinationId !== null) {
        const destId = appState.modalDestinationId;
        closeDetails();
        prefillItineraryForm(destId);
      }
    });
  }
}

function trapFocusInDialog(dialogElement, e) {
  const focusable = dialogElement.querySelectorAll(
    'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
  );
  if (focusable.length === 0) return;

  const first = focusable[0];
  const last = focusable[focusable.length - 1];

  if (e.shiftKey) {
    if (document.activeElement === first) {
      last.focus();
      e.preventDefault();
    }
  } else {
    if (document.activeElement === last) {
      first.focus();
      e.preventDefault();
    }
  }
}

function showDetails(id) {
  const dest = sampleDestinations.find(d => d.id === id);
  if (!dest) return;

  appState.lastFocusedElement = document.activeElement;
  appState.modalDestinationId = id;

  const modal = document.getElementById('destination-modal');
  const img = document.getElementById('modal-img');
  const title = document.getElementById('modal-title');
  const categoryBadge = document.getElementById('modal-category');
  const feeBadge = document.getElementById('modal-fee');
  const ratingText = document.getElementById('modal-rating-text');
  const locText = document.getElementById('modal-location-text');
  const desc = document.getElementById('modal-description');
  const activitiesWrap = document.getElementById('modal-activities');
  const areaEl = document.getElementById('modal-area');
  const hoursEl = document.getElementById('modal-hours');
  const bestTimeEl = document.getElementById('modal-best-time');
  const howToGetThereEl = document.getElementById('modal-how-to-get-there');
  const tipEl = document.getElementById('modal-tip');
  const gmapsLink = document.getElementById('modal-gmaps-link');

  if (img) {
    img.src = escapeHTML(dest.image);
    img.alt = escapeHTML(dest.name);
  }
  if (title) title.textContent = dest.name;
  if (locText) locText.textContent = dest.location;
  if (desc) desc.textContent = dest.description;
  if (ratingText) ratingText.textContent = dest.rating;

  if (areaEl) areaEl.textContent = dest.area || 'Baguio City';
  if (hoursEl) hoursEl.textContent = dest.openingHours || 'Open daily';
  if (bestTimeEl) bestTimeEl.textContent = dest.bestTimeToVisit || 'Morning to early afternoon';
  if (howToGetThereEl) howToGetThereEl.textContent = dest.howToGetThere || 'Accessible via jeepney or taxi from downtown Baguio.';
  if (tipEl) tipEl.textContent = dest.tip || 'Bring a light jacket as Baguio temperatures can drop suddenly.';

  if (gmapsLink) {
    gmapsLink.href = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(dest.name + ' Baguio City')}`;
  }

  if (categoryBadge) {
    categoryBadge.textContent = dest.category;
    const categorySlug = dest.category.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    categoryBadge.className = `badge badge-${categorySlug}`;
  }

  if (feeBadge) {
    feeBadge.textContent = dest.fee === 0 ? 'Free Entry' : `Entrance Fee: ₱${dest.fee}`;
  }

  if (activitiesWrap) {
    activitiesWrap.innerHTML = dest.activities
      .map(act => `<span class="activity-tag">${escapeHTML(act)}</span>`)
      .join('');
  }

  if (modal) {
    modal.style.display = 'flex';
    modal.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';

    const closeBtn = document.getElementById('modal-close-btn');
    if (closeBtn) closeBtn.focus();
  }
}

function closeDetails() {
  const modal = document.getElementById('destination-modal');
  if (modal) {
    modal.style.display = 'none';
    modal.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  }
  appState.modalDestinationId = null;

  if (appState.lastFocusedElement && typeof appState.lastFocusedElement.focus === 'function') {
    appState.lastFocusedElement.focus();
  }
}
