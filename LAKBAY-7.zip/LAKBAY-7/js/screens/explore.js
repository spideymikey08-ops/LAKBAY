/**
 * Lakbay | Screen 2: Explore
 * Search, category/price/rating filters, sorting, and destination cards.
 */
'use strict';

/* ==========================================================================
   SCREEN 2: EXPLORE (Filtering, Search, Rating, Map View, Cards)
   ========================================================================== */
function setupExploreControls() {
  const searchInput = document.getElementById('search-input');
  const searchClearBtn = document.getElementById('search-clear-btn');
  const chipsContainer = document.getElementById('category-chips-container');
  const priceContainer = document.getElementById('price-filters-container');
  const ratingFilter = document.getElementById('filter-rating');
  const sortDropdown = document.getElementById('sort-dropdown');
  const mapToggleBtn = document.getElementById('btn-toggle-explore-map');
  const clearBtn = document.getElementById('btn-clear-explore-filters');
  const resetBtn = document.getElementById('btn-reset-explore-filters');

  // Restore stored session preferences in UI controls
  if (chipsContainer) {
    chipsContainer.querySelectorAll('.chip').forEach(chip => {
      chip.classList.toggle('active', chip.getAttribute('data-category') === appState.activeCategory);
    });
  }
  if (priceContainer) {
    priceContainer.querySelectorAll('.price-chip').forEach(btn => {
      btn.classList.toggle('active', btn.getAttribute('data-price') === appState.priceFilter);
    });
  }
  if (ratingFilter) {
    ratingFilter.value = appState.ratingFilter || 'all';
  }
  if (sortDropdown) {
    sortDropdown.value = appState.sortOrder || 'name-asc';
  }

  // 1. Search input
  if (searchInput) {
    searchInput.addEventListener('input', () => {
      appState.searchQuery = searchInput.value.trim().toLowerCase();
      if (searchClearBtn) {
        searchClearBtn.style.display = searchInput.value ? 'block' : 'none';
      }
      renderExploreGallery();
    });
  }

  // 2. Search clear button
  if (searchClearBtn) {
    searchClearBtn.addEventListener('click', () => {
      if (searchInput) {
        searchInput.value = '';
        searchInput.focus();
      }
      searchClearBtn.style.display = 'none';
      appState.searchQuery = '';
      renderExploreGallery();
    });
  }

  // 3. Category chips
  if (chipsContainer) {
    chipsContainer.addEventListener('click', (e) => {
      const chip = e.target.closest('.chip');
      if (!chip) return;

      chipsContainer.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
      chip.classList.add('active');

      appState.activeCategory = chip.getAttribute('data-category') || 'All';
      saveFilterPrefs();
      renderExploreGallery();
    });
  }

  // 4. Price filter chips
  if (priceContainer) {
    priceContainer.addEventListener('click', (e) => {
      const priceChip = e.target.closest('.price-chip');
      if (!priceChip) return;

      priceContainer.querySelectorAll('.price-chip').forEach(b => b.classList.remove('active'));
      priceChip.classList.add('active');

      appState.priceFilter = priceChip.getAttribute('data-price') || 'all';
      saveFilterPrefs();
      renderExploreGallery();
    });
  }

  // 5. Rating filter dropdown
  if (ratingFilter) {
    ratingFilter.addEventListener('change', (e) => {
      appState.ratingFilter = e.target.value;
      saveFilterPrefs();
      renderExploreGallery();
    });
  }

  // 7. Sort dropdown
  if (sortDropdown) {
    sortDropdown.addEventListener('change', (e) => {
      appState.sortOrder = e.target.value;
      saveFilterPrefs();
      renderExploreGallery();
    });
  }

  // 8. Map view toggle
  if (mapToggleBtn) {
    mapToggleBtn.addEventListener('click', () => {
      const container = document.getElementById('explore-map-container');
      const textSpan = document.getElementById('btn-toggle-explore-map-text');
      if (!container) return;

      const isHidden = container.style.display === 'none';
      if (isHidden) {
        container.style.display = 'block';
        if (textSpan) textSpan.textContent = 'Hide Map';
        initOrUpdateBaguioMap();
      } else {
        container.style.display = 'none';
        if (textSpan) textSpan.textContent = 'Show Map';
      }
    });
  }

  // 9. Reset and Clear Filters
  const resetAllFilters = () => {
    if (searchInput) searchInput.value = '';
    if (searchClearBtn) searchClearBtn.style.display = 'none';
    appState.searchQuery = '';
    appState.activeCategory = 'All';
    appState.priceFilter = 'all';
    appState.ratingFilter = 'all';
    appState.sortOrder = 'name-asc';

    if (chipsContainer) {
      chipsContainer.querySelectorAll('.chip').forEach(c => {
        c.classList.toggle('active', c.getAttribute('data-category') === 'All');
      });
    }

    if (priceContainer) {
      priceContainer.querySelectorAll('.price-chip').forEach(b => {
        b.classList.toggle('active', b.getAttribute('data-price') === 'all');
      });
    }

    if (ratingFilter) ratingFilter.value = 'all';
    if (sortDropdown) sortDropdown.value = 'name-asc';

    saveFilterPrefs();
    renderExploreGallery();
  };

  if (clearBtn) clearBtn.addEventListener('click', resetAllFilters);
  if (resetBtn) resetBtn.addEventListener('click', resetAllFilters);

  // Gallery Card Event Delegation
  const exploreGrid = document.getElementById('explore-cards-grid');
  if (exploreGrid) {
    exploreGrid.addEventListener('click', handleCardActions);
  }

  const homeGrid = document.getElementById('home-featured-grid');
  if (homeGrid) {
    homeGrid.addEventListener('click', handleCardActions);
  }
}

function handleCardActions(e) {
  // 1. Details Modal
  const detailsBtn = e.target.closest('.btn-show-details');
  if (detailsBtn) {
    e.stopPropagation();
    const id = parseInt(detailsBtn.getAttribute('data-id'), 10);
    showDetails(id);
    return;
  }

  // 2. Quick-Add Popover
  const quickItineraryBtn = e.target.closest('.btn-quick-itinerary');
  if (quickItineraryBtn) {
    e.stopPropagation();
    const id = parseInt(quickItineraryBtn.getAttribute('data-id'), 10);
    openQuickAddPopover(id, quickItineraryBtn);
  }
}

function renderExploreGallery() {
  const grid = document.getElementById('explore-cards-grid');
  const emptyState = document.getElementById('explore-empty-state');
  const countText = document.getElementById('results-count-text');
  if (!grid) return;

  // 1. Category Filter
  let list = sampleDestinations.filter(item => {
    if (appState.activeCategory === 'All') return true;
    return item.category.toLowerCase() === appState.activeCategory.toLowerCase();
  });

  // 2. Price Filter
  if (appState.priceFilter === 'free') {
    list = list.filter(item => item.fee === 0);
  } else if (appState.priceFilter === '50') {
    list = list.filter(item => item.fee <= 50);
  } else if (appState.priceFilter === '100') {
    list = list.filter(item => item.fee <= 100);
  }

  // 3. Rating Filter
  if (appState.ratingFilter === '4.7') {
    list = list.filter(item => item.rating >= 4.7);
  } else if (appState.ratingFilter === '4.8') {
    list = list.filter(item => item.rating >= 4.8);
  }

  // 4. Search Query Filter
  if (appState.searchQuery) {
    const q = appState.searchQuery;
    list = list.filter(item => {
      const matchName = item.name.toLowerCase().includes(q);
      const matchLocation = item.location.toLowerCase().includes(q);
      const matchArea = item.area ? item.area.toLowerCase().includes(q) : false;
      const matchDesc = item.description.toLowerCase().includes(q);
      const matchActivities = item.activities.some(act => act.toLowerCase().includes(q));
      return matchName || matchLocation || matchArea || matchDesc || matchActivities;
    });
  }

  // 6. Sort
  list.sort((a, b) => {
    if (appState.sortOrder === 'name-asc') {
      return a.name.localeCompare(b.name);
    } else if (appState.sortOrder === 'name-desc') {
      return b.name.localeCompare(a.name);
    } else if (appState.sortOrder === 'rating-desc') {
      return b.rating - a.rating;
    } else if (appState.sortOrder === 'fee-asc') {
      return a.fee - b.fee;
    } else if (appState.sortOrder === 'fee-desc') {
      return b.fee - a.fee;
    }
    return 0;
  });

  // 7. Results Counter
  if (countText) {
    countText.textContent = `Showing ${list.length} destination${list.length === 1 ? '' : 's'}`;
  }

  // 8. Output
  if (list.length === 0) {
    grid.innerHTML = '';
    if (emptyState) emptyState.style.display = 'block';
  } else {
    if (emptyState) emptyState.style.display = 'none';
    grid.innerHTML = list.map(dest => createDestinationCardHTML(dest)).join('');
  }
}

function createDestinationCardHTML(dest, isFeatured = false) {
  const isPlanned = appState.itinerary.some(s => s.destinationId === dest.id);

  const categorySlug = dest.category.toLowerCase().replace(/[^a-z0-9]+/g, '-');
  const badgeClass = `badge-${categorySlug}`;
  const feeText = dest.fee === 0 ? 'Free Entry' : `₱${dest.fee}`;

  return `
    <article class="destination-card" data-id="${dest.id}">
      <div class="card-image-wrap">
        <img 
          src="${escapeHTML(dest.image)}" 
          alt="${escapeHTML(dest.name)}" 
          class="card-img" 
          loading="lazy"
          onerror="this.src='assets/images/burnham-park.jpg'"
        >
        ${isPlanned ? `<span class="card-planned-indicator"><svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"></polyline></svg> In itinerary</span>` : ''}
      </div>
      <div class="card-content">
        <div class="card-meta-row">
          <div class="card-meta-badges">
            <span class="badge ${badgeClass}">${escapeHTML(dest.category)}</span>
            <span class="badge rating-badge">
              <svg viewBox="0 0 24 24" width="12" height="12" fill="#f59e0b" stroke="#f59e0b"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
              ${dest.rating}
            </span>
          </div>
          <span class="card-fee-text ${dest.fee === 0 ? '' : 'card-fee-highlight'}">${feeText}</span>
        </div>
        <h3 class="card-title">${escapeHTML(dest.name)}</h3>
        <p class="card-location">
          <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
          <span>${escapeHTML(dest.area || dest.location)}</span>
        </p>
        <p class="card-desc">${dest.description ? escapeHTML(dest.description.substring(0, 85)) + '...' : ''}</p>
        <div class="card-actions">
          <button type="button" class="btn btn-outline btn-sm btn-show-details" data-id="${dest.id}">
            Details
          </button>
          <button type="button" class="btn btn-primary btn-sm btn-quick-itinerary ${isPlanned ? 'btn-outline' : ''}" data-id="${dest.id}">
            ${isPlanned ? 'Added' : '+ Itinerary'}
          </button>
        </div>
      </div>
    </article>
  `;
}
