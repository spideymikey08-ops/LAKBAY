/**
 * Lakbay | Screen 4: Itinerary - Controls
 * Event listeners for budget setup and planner, plus Explore-to-Itinerary hand-off helpers.
 */
'use strict';

/**
 * Event listeners and controls for Step 1 Budget Setup & Itinerary Planner
 */
function setupItineraryControls() {
  const sliderMin = document.getElementById('budget-slider-min');
  const sliderMax = document.getElementById('budget-slider-max');
  const numMin = document.getElementById('budget-num-min');
  const numMax = document.getElementById('budget-num-max');
  const daysInput = document.getElementById('budget-trip-days');
  const presetButtons = document.querySelectorAll('#budget-preset-buttons .btn-preset');
  const btnConfirm = document.getElementById('btn-confirm-budget');
  const btnEdit = document.getElementById('btn-edit-confirmed-budget');

  const btnOpenAddStop = document.getElementById('btn-open-add-stop-modal');
  const btnLoadSample = document.getElementById('btn-load-sample-itinerary');
  const btnClearItin = document.getElementById('btn-clear-itinerary');

  // Setup stop editor modal listeners
  setupStopEditorModal();

  // Planner Workspace Buttons
  if (btnOpenAddStop) {
    btnOpenAddStop.addEventListener('click', () => {
      openStopEditor();
    });
  }

  if (btnLoadSample) {
    btnLoadSample.addEventListener('click', loadSampleItinerary);
  }

  if (btnClearItin) {
    btnClearItin.addEventListener('click', clearItinerary);
  }

  // 1. Min Slider Input
  if (sliderMin && sliderMax && numMin && numMax) {
    sliderMin.addEventListener('pointerdown', () => {
      sliderMin.style.zIndex = '5';
      sliderMax.style.zIndex = '4';
    });
    sliderMax.addEventListener('pointerdown', () => {
      sliderMax.style.zIndex = '5';
      sliderMin.style.zIndex = '4';
    });

    sliderMin.addEventListener('input', () => {
      sliderMin.style.zIndex = '5';
      sliderMax.style.zIndex = '4';
      let minVal = parseInt(sliderMin.value, 10);
      const maxVal = parseInt(sliderMax.value, 10);

      if (minVal > maxVal - BUDGET_SLIDER_CONFIG.MIN_GAP) {
        minVal = maxVal - BUDGET_SLIDER_CONFIG.MIN_GAP;
        sliderMin.value = minVal;
      }

      numMin.value = minVal;
      const days = daysInput ? parseInt(daysInput.value, 10) || 2 : 2;
      updateBudgetCalculations(minVal, maxVal, days);
      updateSliderTrackHighlight(minVal, maxVal);
      highlightMatchingPreset(minVal, maxVal);
    });

    // 2. Max Slider Input
    sliderMax.addEventListener('input', () => {
      sliderMax.style.zIndex = '5';
      sliderMin.style.zIndex = '4';
      const minVal = parseInt(sliderMin.value, 10);
      let maxVal = parseInt(sliderMax.value, 10);

      if (maxVal < minVal + BUDGET_SLIDER_CONFIG.MIN_GAP) {
        maxVal = minVal + BUDGET_SLIDER_CONFIG.MIN_GAP;
        sliderMax.value = maxVal;
      }

      numMax.value = maxVal;
      const days = daysInput ? parseInt(daysInput.value, 10) || 2 : 2;
      updateBudgetCalculations(minVal, maxVal, days);
      updateSliderTrackHighlight(minVal, maxVal);
      highlightMatchingPreset(minVal, maxVal);
    });

    // 3. Min Number Input
    const handleMinNumChange = () => {
      let minVal = parseInt(numMin.value, 10) || BUDGET_SLIDER_CONFIG.MIN_ALLOWED;
      const maxVal = parseInt(numMax.value, 10) || 3500;

      if (minVal < BUDGET_SLIDER_CONFIG.MIN_ALLOWED) {
        minVal = BUDGET_SLIDER_CONFIG.MIN_ALLOWED;
      }
      if (minVal > maxVal - BUDGET_SLIDER_CONFIG.MIN_GAP) {
        minVal = maxVal - BUDGET_SLIDER_CONFIG.MIN_GAP;
      }

      numMin.value = minVal;
      sliderMin.value = minVal;
      const days = daysInput ? parseInt(daysInput.value, 10) || 2 : 2;
      updateBudgetCalculations(minVal, maxVal, days);
      updateSliderTrackHighlight(minVal, maxVal);
      highlightMatchingPreset(minVal, maxVal);
    };
    numMin.addEventListener('change', handleMinNumChange);
    numMin.addEventListener('blur', handleMinNumChange);

    // 4. Max Number Input
    const handleMaxNumChange = () => {
      const minVal = parseInt(numMin.value, 10) || BUDGET_SLIDER_CONFIG.MIN_ALLOWED;
      let maxVal = parseInt(numMax.value, 10) || 3500;

      if (maxVal > BUDGET_SLIDER_CONFIG.MAX_ALLOWED) {
        maxVal = BUDGET_SLIDER_CONFIG.MAX_ALLOWED;
      }
      if (maxVal < minVal + BUDGET_SLIDER_CONFIG.MIN_GAP) {
        maxVal = minVal + BUDGET_SLIDER_CONFIG.MIN_GAP;
      }

      numMax.value = maxVal;
      sliderMax.value = maxVal;
      const days = daysInput ? parseInt(daysInput.value, 10) || 2 : 2;
      updateBudgetCalculations(minVal, maxVal, days);
      updateSliderTrackHighlight(minVal, maxVal);
      highlightMatchingPreset(minVal, maxVal);
    };
    numMax.addEventListener('change', handleMaxNumChange);
    numMax.addEventListener('blur', handleMaxNumChange);
  }

  // 5. Trip Days Input
  if (daysInput) {
    const handleDaysChange = () => {
      let days = parseInt(daysInput.value, 10) || 2;
      if (days < 1) days = 1;
      if (days > 30) days = 30;
      daysInput.value = days;

      const minVal = numMin ? parseInt(numMin.value, 10) || 1500 : 1500;
      const maxVal = numMax ? parseInt(numMax.value, 10) || 3500 : 3500;
      updateBudgetCalculations(minVal, maxVal, days);
    };
    daysInput.addEventListener('input', handleDaysChange);
    daysInput.addEventListener('change', handleDaysChange);
  }

  // 6. Preset Buttons
  presetButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const pMin = parseInt(btn.getAttribute('data-min'), 10);
      const pMax = parseInt(btn.getAttribute('data-max'), 10);
      if (!pMin || !pMax) return;

      if (sliderMin) sliderMin.value = pMin;
      if (sliderMax) sliderMax.value = pMax;
      if (numMin) numMin.value = pMin;
      if (numMax) numMax.value = pMax;

      const days = daysInput ? parseInt(daysInput.value, 10) || 2 : 2;
      updateBudgetCalculations(pMin, pMax, days);
      updateSliderTrackHighlight(pMin, pMax);
      highlightMatchingPreset(pMin, pMax);
    });
  });

  // 7. Confirm Budget Action
  if (btnConfirm) {
    btnConfirm.addEventListener('click', () => {
      const minVal = numMin ? parseInt(numMin.value, 10) || 1500 : 1500;
      const maxVal = numMax ? parseInt(numMax.value, 10) || 3500 : 3500;
      const days = daysInput ? parseInt(daysInput.value, 10) || 2 : 2;

      if (minVal > maxVal) {
        showToast('Minimum budget cannot exceed maximum budget.', 'warning');
        return;
      }

      appState.trip.budgetMin = minVal;
      appState.trip.budgetMax = maxVal;
      appState.trip.days = days;
      appState.trip.budgetConfirmed = true;
      appState.hasConfirmedBudget = true;

      saveData();
      localStorage.setItem('lakbay_budget_range', JSON.stringify({
        min: minVal,
        max: maxVal,
        days: days,
        confirmed: true
      }));

      renderItineraryList();
      showToast(`Budget established: ₱${formatNumber(minVal)} – ₱${formatNumber(maxVal)} (${days} Days)`, 'success');
    });
  }

  // 8. Edit Confirmed Budget Action
  if (btnEdit) {
    btnEdit.addEventListener('click', () => {
      appState.hasConfirmedBudget = false;
      appState.trip.budgetConfirmed = false;
      saveData();

      const selectorView = document.getElementById('budget-selector-view');
      const confirmedView = document.getElementById('budget-confirmed-view');
      if (selectorView) selectorView.style.display = 'block';
      if (confirmedView) confirmedView.style.display = 'none';

      syncBudgetInputsFromState();

      if (numMin) numMin.focus();
    });
  }
}

/**
 * Integration Stubs for Other Screens (Explore / Details / Summary)
 */
function prefillItineraryForm(destId) {
  showSection('itinerary');
  const dest = sampleDestinations.find(d => d.id === destId);
  const destName = dest ? dest.name : 'Destination';

  if (!appState.hasConfirmedBudget) {
    showToast(`Please confirm your estimated budget first before planning "${destName}".`, 'info');
  } else {
    openStopEditor({ destinationId: destId });
  }
}

function openQuickAddPopover(destId, anchorBtn) {
  prefillItineraryForm(destId);
}

function setupQuickAddPopover() {
  // Integrated into stop-editor-modal
}

function setupDestinationDropdown() {
  // Handled inside stop editor
}

function sortItineraryChronologically() {
  if (!Array.isArray(appState.itinerary)) return;
  appState.itinerary.sort((a, b) => {
    if (a.date !== b.date) return (a.date || '').localeCompare(b.date || '');
    return (a.time || '').localeCompare(b.time || '');
  });
}
