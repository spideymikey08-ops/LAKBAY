/**
 * Lakbay | Screen 4: Itinerary - Stop Editor Modal
 * Add / edit stop dialog and its inspector logic.
 */
'use strict';

/**
 * Setup Stop Editor Modal dialog and controls
 */
function setupStopEditorModal() {
  const modal = document.getElementById('stop-editor-modal');
  const backdrop = document.getElementById('stop-editor-backdrop');
  const closeBtn = document.getElementById('stop-modal-close');
  const cancelBtn = document.getElementById('btn-cancel-stop-modal');
  const form = document.getElementById('stop-editor-form');

  const destSelect = document.getElementById('stop-destination-select');
  const daySelect = document.getElementById('stop-day-select');
  const dateInput = document.getElementById('stop-date-input');
  const timeInput = document.getElementById('stop-time-input');
  const durInput = document.getElementById('stop-duration-input');
  const activityInput = document.getElementById('stop-activity-input');

  const previewStrip = document.getElementById('stop-dest-preview-strip');
  const previewImg = document.getElementById('stop-preview-img');
  const previewName = document.getElementById('stop-preview-name');
  const previewCat = document.getElementById('stop-preview-category');
  const previewFee = document.getElementById('stop-preview-fee');
  const previewArea = document.getElementById('stop-preview-area');

  const suggRow = document.getElementById('stop-activity-suggestions');
  const suggChipsWrap = document.getElementById('stop-suggestions-chips');

  const impactFee = document.getElementById('modal-impact-fee');
  const impactRemaining = document.getElementById('modal-impact-remaining');

  const populateDestPicker = (selectedId = null) => {
    if (!destSelect) return;
    const list = sampleDestinations;

    destSelect.innerHTML = '<option value="">-- Choose a Baguio Destination --</option>' +
      list.map(d => {
        const feeStr = d.fee > 0 ? `₱${d.fee}` : 'Free';
        return `<option value="${d.id}">${escapeHTML(d.name)} (${escapeHTML(d.category)}) — ${feeStr}</option>`;
      }).join('');

    if (selectedId) {
      destSelect.value = selectedId;
    }
  };

  const updateDestPreview = () => {
    const destId = Number(destSelect.value);
    const dest = sampleDestinations.find(d => d.id === destId);
    if (!dest) {
      if (previewStrip) previewStrip.style.display = 'none';
      if (suggRow) suggRow.style.display = 'none';
      if (impactFee) impactFee.textContent = '₱0';
      return;
    }

    if (previewStrip) previewStrip.style.display = 'flex';
    if (previewImg) previewImg.src = dest.image;
    if (previewName) previewName.textContent = dest.name;
    if (previewCat) previewCat.textContent = dest.category;
    if (previewFee) {
      previewFee.textContent = dest.fee > 0 ? `₱${dest.fee}` : 'Free Entry';
      previewFee.className = `badge ${dest.fee > 0 ? 'badge-fee-paid' : 'badge-fee-free'}`;
    }
    if (previewArea) previewArea.textContent = dest.area || dest.location;

    // Suggestions chips
    if (suggRow && suggChipsWrap) {
      if (dest.activities && dest.activities.length) {
        suggRow.style.display = 'flex';
        suggChipsWrap.innerHTML = dest.activities.map(act => `
          <button type="button" class="sugg-chip" data-act="${escapeHTML(act)}">${escapeHTML(act)}</button>
        `).join('');

        suggChipsWrap.querySelectorAll('.sugg-chip').forEach(chip => {
          chip.addEventListener('click', () => {
            activityInput.value = chip.getAttribute('data-act');
          });
        });
      } else {
        suggRow.style.display = 'none';
      }
    }

    // Modal Budget Impact
    const currentFee = dest.fee || 0;
    if (impactFee) impactFee.textContent = currentFee > 0 ? `₱${formatNumber(currentFee)}` : 'Free Entry';

    const maxBudget = appState.trip.budgetMax || 3500;
    const baseCost = Math.round(maxBudget * 0.80);
    const currentStopsFees = appState.itinerary
      .filter(s => s.id !== stopEditorTargetId)
      .reduce((sum, s) => {
        const d = sampleDestinations.find(item => item.id === s.destinationId);
        return sum + (d ? Number(d.fee) || 0 : (Number(s.fee) || 0));
      }, 0);

    const projectedRemaining = maxBudget - (baseCost + currentStopsFees + currentFee);
    if (impactRemaining) {
      impactRemaining.textContent = projectedRemaining >= 0 ? `₱${formatNumber(projectedRemaining)}` : `-₱${formatNumber(Math.abs(projectedRemaining))} (Over Limit)`;
      impactRemaining.style.color = projectedRemaining >= 0 ? '#10352b' : '#b91c1c';
    }
  };

  if (destSelect) {
    destSelect.addEventListener('change', updateDestPreview);
  }

  if (daySelect && dateInput) {
    daySelect.addEventListener('change', () => {
      const dayNum = parseInt(daySelect.value, 10) || 1;
      dateInput.value = getDateForDay(dayNum);
    });

    dateInput.addEventListener('change', () => {
      const dayNum = getStopDayIndex(dateInput.value);
      daySelect.value = String(dayNum);
    });
  }

  const durChips = document.querySelectorAll('.duration-chip');
  durChips.forEach(chip => {
    chip.addEventListener('click', () => {
      durChips.forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      if (durInput) durInput.value = chip.getAttribute('data-dur');
    });
  });

  const closeModal = () => {
    if (modal) modal.style.display = 'none';
    stopEditorTargetId = null;
  };

  if (closeBtn) closeBtn.addEventListener('click', closeModal);
  if (backdrop) backdrop.addEventListener('click', closeModal);
  if (cancelBtn) cancelBtn.addEventListener('click', closeModal);

  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const destId = Number(destSelect.value);
      if (!destId) {
        showToast('Please select a destination.', 'warning');
        return;
      }

      const dest = sampleDestinations.find(d => d.id === destId);
      const scheduledDate = dateInput.value || getDateForDay(1);
      const startTime = timeInput.value || '09:00';
      const duration = Math.max(15, parseInt(durInput.value, 10) || 90);
      const activity = (activityInput.value || '').trim();

      if (stopEditorTargetId) {
        const stop = appState.itinerary.find(s => s.id === stopEditorTargetId);
        if (stop) {
          stop.destinationId = destId;
          stop.destinationName = dest.name;
          stop.category = dest.category;
          stop.fee = dest.fee || 0;
          stop.date = scheduledDate;
          stop.time = startTime;
          stop.duration = duration;
          stop.activity = activity;
          showToast(`Updated "${dest.name}"!`, 'success');
        }
      } else {
        const newStop = {
          id: generateUniqueId(),
          destinationId: destId,
          destinationName: dest.name,
          category: dest.category,
          fee: dest.fee || 0,
          date: scheduledDate,
          time: startTime,
          duration: duration,
          activity: activity
        };
        appState.itinerary.push(newStop);
        showToast(`Added "${dest.name}" to Day ${getStopDayIndex(scheduledDate)}!`, 'success');
      }

      sortItineraryChronologically();
      saveData();
      renderItineraryWorkspace();
      closeModal();
    });
  }
}

/**
 * Opens Stop Editor Modal for adding or editing
 */
function openStopEditor(options = {}) {
  const modal = document.getElementById('stop-editor-modal');
  if (!modal) return;

  const titleEl = document.getElementById('stop-modal-title');
  const destSelect = document.getElementById('stop-destination-select');
  const daySelect = document.getElementById('stop-day-select');
  const dateInput = document.getElementById('stop-date-input');
  const timeInput = document.getElementById('stop-time-input');
  const durInput = document.getElementById('stop-duration-input');
  const activityInput = document.getElementById('stop-activity-input');

  const daysCount = appState.trip.days || 2;
  if (daySelect) {
    daySelect.innerHTML = Array.from({ length: daysCount }, (_, i) => i + 1)
      .map(d => `<option value="${d}">Day ${d}</option>`)
      .join('');
  }

  destSelect.innerHTML = '<option value="">-- Choose a Baguio Destination --</option>' +
    sampleDestinations.map(d => {
      const feeStr = d.fee > 0 ? `₱${d.fee}` : 'Free';
      return `<option value="${d.id}">${escapeHTML(d.name)} (${escapeHTML(d.category)}) — ${feeStr}</option>`;
    }).join('');

  if (options.stopId) {
    stopEditorTargetId = options.stopId;
    if (titleEl) titleEl.textContent = 'Edit Itinerary Stop';
    const stop = appState.itinerary.find(s => s.id === options.stopId);
    if (stop) {
      if (destSelect) destSelect.value = stop.destinationId;
      const dayNum = getStopDayIndex(stop.date);
      if (daySelect) daySelect.value = String(dayNum);
      if (dateInput) dateInput.value = stop.date;
      if (timeInput) timeInput.value = stop.time;
      if (durInput) durInput.value = stop.duration || 90;
      if (activityInput) activityInput.value = stop.activity || '';
    }
  } else {
    stopEditorTargetId = null;
    if (titleEl) titleEl.textContent = 'Add Stop to Itinerary';
    const targetDay = options.day ? Number(options.day) : 1;
    if (daySelect) daySelect.value = String(targetDay);
    if (dateInput) dateInput.value = getDateForDay(targetDay);

    if (options.destinationId && destSelect) {
      destSelect.value = options.destinationId;
    } else if (destSelect) {
      destSelect.value = '';
    }

    if (timeInput) timeInput.value = '09:00';
    if (durInput) durInput.value = '90';
    if (activityInput) activityInput.value = '';
  }

  destSelect.dispatchEvent(new Event('change'));
  modal.style.display = 'flex';
}
