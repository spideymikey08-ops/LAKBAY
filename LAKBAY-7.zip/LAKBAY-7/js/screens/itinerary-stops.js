/**
 * Lakbay | Screen 4: Itinerary - Stop Actions
 * Delete/undo, reorder, sample plan loader, clear itinerary.
 */
'use strict';

/**
 * Removes a stop and offers an Undo toast
 */
function deleteStop(stopId) {
  const index = appState.itinerary.findIndex(s => s.id === stopId);
  if (index === -1) return;

  const deleted = appState.itinerary.splice(index, 1)[0];
  appState.lastDeletedStop = deleted;
  saveData();
  renderItineraryWorkspace();

  showToast(`Removed "${deleted.destinationName || 'stop'}".`, 'info', true);
}

/**
 * Undoes previous delete
 */
function undoDeleteStop() {
  if (!appState.lastDeletedStop) return;
  appState.itinerary.push(appState.lastDeletedStop);
  appState.lastDeletedStop = null;
  sortItineraryChronologically();
  saveData();
  renderItineraryWorkspace();
  showToast('Restored stop.', 'success');
}

/**
 * Reorders a stop earlier or later in time
 */
function reorderStop(stopId, direction) {
  const stop = appState.itinerary.find(s => s.id === stopId);
  if (!stop) return;

  const currentMins = timeToMinutes(stop.time);
  const delta = direction === 'up' ? -30 : 30;
  const newMins = Math.max(360, Math.min(1380, currentMins + delta)); // between 06:00 and 23:00

  stop.time = minutesToTime(newMins);
  sortItineraryChronologically();
  saveData();
  renderItineraryWorkspace();
}

/**
 * Loads a curated 2-day Baguio itinerary that fits within the budget
 */
function loadSampleItinerary() {
  const startDate = appState.trip.startDate || getTodayDateString();
  const dateDay1 = getDateForDay(1);
  const dateDay2 = getDateForDay(2);

  appState.trip.days = Math.max(2, appState.trip.days || 2);

  appState.itinerary = [
    // Day 1
    {
      id: generateUniqueId(),
      destinationId: 3, // Wright Park
      destinationName: 'Wright Park',
      category: 'Nature & Parks',
      fee: 0,
      date: dateDay1,
      time: '09:00',
      duration: 60,
      activity: 'Morning stroll along the Pool of Pines'
    },
    {
      id: generateUniqueId(),
      destinationId: 4, // The Mansion
      destinationName: 'The Mansion',
      category: 'Culture & Heritage',
      fee: 0,
      date: dateDay1,
      time: '10:15',
      duration: 45,
      activity: 'Sightseeing at the presidential summer palace gates'
    },
    {
      id: generateUniqueId(),
      destinationId: 2, // Mines View Park
      destinationName: 'Mines View Park',
      category: 'Viewpoints',
      fee: 10,
      date: dateDay1,
      time: '11:30',
      duration: 90,
      activity: 'Panoramic ridge views and buying Good Shepherd strawberry jam'
    },
    {
      id: generateUniqueId(),
      destinationId: 15, // Baguio Night Market (actual ID 15)
      destinationName: 'Baguio Night Market',
      category: 'Food & Shopping',
      fee: 0,
      date: dateDay1,
      time: '21:00',
      duration: 90,
      activity: 'Street food tasting, strawberry taho, and thrift shopping'
    },
    // Day 2
    {
      id: generateUniqueId(),
      destinationId: 1, // Burnham Park
      destinationName: 'Burnham Park',
      category: 'Nature & Parks',
      fee: 0,
      date: dateDay2,
      time: '09:00',
      duration: 90,
      activity: 'Swan paddleboat lagoon rowing and rose garden walk'
    },
    {
      id: generateUniqueId(),
      destinationId: 6, // Camp John Hay (actual ID 6)
      destinationName: 'Camp John Hay',
      category: 'Nature & Parks',
      fee: 80,
      date: dateDay2,
      time: '11:00',
      duration: 120,
      activity: 'Trekking the Yellow Trail and visiting Bell Amphitheater'
    },
    {
      id: generateUniqueId(),
      destinationId: 5, // Baguio Botanical Garden (actual ID 5)
      destinationName: 'Baguio Botanical Garden',
      category: 'Nature & Parks',
      fee: 10,
      date: dateDay2,
      time: '14:30',
      duration: 60,
      activity: 'Exploring Igorot cultural village replicas and indigenous pines'
    }
  ];

  sortItineraryChronologically();
  saveData();
  renderItineraryWorkspace();

  showToast('Loaded sample 2-day Baguio itinerary!', 'success');
}

/**
 * Clears all itinerary stops after user confirmation
 */
function clearItinerary() {
  openConfirmDialog(
    'Clear All Itinerary Stops?',
    'Are you sure you want to remove all planned stops? Your established budget settings will remain intact.',
    () => {
      appState.itinerary = [];
      saveData();
      renderItineraryWorkspace();
      showToast('Itinerary stops cleared.', 'info');
    }
  );
}
