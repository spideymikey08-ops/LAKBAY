/**
 * Lakbay | Screen 4: Itinerary - Timeline
 * Day/stop index helpers, schedule clash detection and the hourly timeline grid.
 */
'use strict';

/**
 * Calculates day index (1-based) from stop date and trip startDate
 */
function getStopDayIndex(stopDateStr) {
  const startDateStr = appState.trip.startDate || getTodayDateString();
  const start = new Date(startDateStr);
  const stopDate = new Date(stopDateStr);
  const diffDays = Math.floor((stopDate - start) / (1000 * 60 * 60 * 24));
  return Math.max(1, Math.min(appState.trip.days || 2, diffDays + 1));
}

/**
 * Computes calendar date string for Day N
 */
function getDateForDay(dayIndex) {
  const startDateStr = appState.trip.startDate || getTodayDateString();
  const date = new Date(startDateStr);
  date.setDate(date.getDate() + (dayIndex - 1));
  return date.toISOString().split('T')[0];
}

/**
 * Clash detector: identifies overlapping time windows on the same date
 */
function findItineraryClashes(stops) {
  const clashMap = {};
  for (let i = 0; i < stops.length; i++) {
    const s1 = stops[i];
    const start1 = timeToMinutes(s1.time);
    const end1 = start1 + (Number(s1.duration) || 90);

    for (let j = i + 1; j < stops.length; j++) {
      const s2 = stops[j];
      if (s1.date !== s2.date) continue;

      const start2 = timeToMinutes(s2.time);
      const end2 = start2 + (Number(s2.duration) || 90);

      if (start1 < end2 && start2 < end1) {
        clashMap[s1.id] = {
          withName: s2.destinationName || 'Another Stop',
          timeRange: `${s2.time} – ${minutesToTime(end2)}`
        };
        clashMap[s2.id] = {
          withName: s1.destinationName || 'Another Stop',
          timeRange: `${s1.time} – ${minutesToTime(end1)}`
        };
      }
    }
  }
  return clashMap;
}

/**
 * Renders the day sections and timeline stop cards
 */
function renderTimelineDays(daysCount, stops) {
  const container = document.getElementById('itinerary-days-list');
  if (!container) return;

  sortItineraryChronologically();
  const clashesMap = findItineraryClashes(stops);

  let html = '';

  for (let dayNum = 1; dayNum <= daysCount; dayNum++) {
    if (activeDayFilter !== 'all' && activeDayFilter !== String(dayNum)) {
      continue;
    }

    const dayDateStr = getDateForDay(dayNum);
    const formattedDate = formatDate(dayDateStr);

    const dayStops = stops.filter(s => {
      if (s.date === dayDateStr) return true;
      return getStopDayIndex(s.date) === dayNum;
    });

    const dayFeesSum = dayStops.reduce((sum, s) => {
      const d = sampleDestinations.find(dest => dest.id === s.destinationId);
      return sum + (d ? Number(d.fee) || 0 : (Number(s.fee) || 0));
    }, 0);

    const totalMinutes = dayStops.reduce((sum, s) => sum + (Number(s.duration) || 90), 0);
    const hours = Math.floor(totalMinutes / 60);
    const mins = totalMinutes % 60;
    const timeTotalStr = hours > 0 ? `${hours}h ${mins > 0 ? mins + 'm' : ''}` : `${mins}m`;

    html += `
      <section class="itinerary-day-section" data-day="${dayNum}">
        <div class="day-section-header">
          <div class="day-section-title-wrap">
            <h3 class="day-section-title">Day ${dayNum}</h3>
            <span class="day-section-date">· ${formattedDate}</span>
            <div class="day-meta-pills">
              <span class="day-meta-pill">${dayStops.length} Stop${dayStops.length === 1 ? '' : 's'}</span>
              <span class="day-meta-pill">⏱️ ${timeTotalStr}</span>
              <span class="day-meta-pill">🎟️ ${dayFeesSum === 0 ? 'Free Entry' : '₱' + formatNumber(dayFeesSum)}</span>
            </div>
          </div>
          <button type="button" class="day-add-stop-btn" data-day="${dayNum}">
            + Add to Day ${dayNum}
          </button>
        </div>

        <div class="day-stops-list">
    `;

    if (dayStops.length === 0) {
      html += `
        <div class="empty-day-banner">
          <p class="empty-day-text">No planned destinations scheduled for Day ${dayNum} yet.</p>
          <button type="button" class="btn btn-sm btn-outline day-add-stop-btn" data-day="${dayNum}">
            + Add First Stop to Day ${dayNum}
          </button>
        </div>
      `;
    } else {
      dayStops.forEach((stop) => {
        const dest = sampleDestinations.find(d => d.id === stop.destinationId) || {
          name: stop.destinationName || 'Destination',
          category: stop.category || 'Sightseeing',
          fee: stop.fee || 0,
          image: 'assets/images/burnham-park.jpg',
          area: 'Baguio City'
        };

        const duration = Number(stop.duration) || 90;
        const startMins = timeToMinutes(stop.time);
        const endMins = startMins + duration;
        const startTimeStr = stop.time || '09:00';
        const endTimeStr = minutesToTime(endMins);

        const fee = dest.fee || 0;
        const clashInfo = clashesMap[stop.id];

        html += `
          <div class="itinerary-stop-card" data-stop-id="${stop.id}">
            <!-- Time Col -->
            <div class="stop-time-col">
              <span class="stop-time-val">${startTimeStr}</span>
              <span class="stop-time-end">to ${endTimeStr}</span>
              <span class="stop-dur-pill">${duration}m</span>
            </div>

            <!-- Thumbnail -->
            <img src="${dest.image}" alt="${escapeHTML(dest.name)}" class="stop-thumb-img" loading="lazy">

            <!-- Content Col -->
            <div class="stop-info-col">
              <div class="stop-title-row">
                <h4 class="stop-dest-title">${escapeHTML(dest.name)}</h4>
                <span class="${fee > 0 ? 'badge-fee-paid' : 'badge-fee-free'}">
                  ${fee > 0 ? '₱' + formatNumber(fee) : 'Free Entry'}
                </span>
              </div>
              <div class="stop-meta-tags">
                <span class="stop-category-tag">${escapeHTML(dest.category)}</span>
                <span class="stop-area-tag">📍 ${escapeHTML(dest.area || dest.location || 'Baguio')}</span>
              </div>
              ${stop.activity ? `<p class="stop-activity-text">🎯 ${escapeHTML(stop.activity)}</p>` : ''}
              ${clashInfo ? `<div class="stop-clash-warning">⚠️ Overlaps with ${escapeHTML(clashInfo.withName)} (${clashInfo.timeRange})</div>` : ''}
            </div>

            <!-- Actions Col -->
            <div class="stop-actions-col">
              <button type="button" class="btn-icon-action btn-move-stop" data-dir="up" data-stop-id="${stop.id}" title="Move earlier in time">↑</button>
              <button type="button" class="btn-icon-action btn-move-stop" data-dir="down" data-stop-id="${stop.id}" title="Move later in time">↓</button>
              <button type="button" class="btn-icon-action btn-edit-stop" data-stop-id="${stop.id}" title="Edit stop details">✏️</button>
              <button type="button" class="btn-icon-action action-delete btn-delete-stop" data-stop-id="${stop.id}" title="Remove stop">🗑️</button>
            </div>
          </div>
        `;
      });
    }

    html += `
        </div>
      </section>
    `;
  }

  container.innerHTML = html;

  // Attach card event listeners
  container.querySelectorAll('.day-add-stop-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const day = btn.getAttribute('data-day');
      openStopEditor({ day });
    });
  });

  container.querySelectorAll('.btn-edit-stop').forEach(btn => {
    btn.addEventListener('click', () => {
      const stopId = btn.getAttribute('data-stop-id');
      openStopEditor({ stopId });
    });
  });

  container.querySelectorAll('.btn-delete-stop').forEach(btn => {
    btn.addEventListener('click', () => {
      const stopId = btn.getAttribute('data-stop-id');
      deleteStop(stopId);
    });
  });

  container.querySelectorAll('.btn-move-stop').forEach(btn => {
    btn.addEventListener('click', () => {
      const stopId = btn.getAttribute('data-stop-id');
      const dir = btn.getAttribute('data-dir');
      reorderStop(stopId, dir);
    });
  });
}
