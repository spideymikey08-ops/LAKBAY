/**
 * Lakbay | Screen 4: Itinerary - Budget & Workspace
 * Budget range selector (step 1), workspace health toolbar and day filter tabs (step 2).
 */
'use strict';

/* ==========================================================================
   SCREEN 4: ITINERARY PLANNER (Budget Selection & Day-by-Day Timeline)
   ========================================================================== */

const BUDGET_SLIDER_CONFIG = {
  MIN_ALLOWED: 500,
  MAX_ALLOWED: 25000,
  STEP: 100,
  MIN_GAP: 100
};

let stopEditorTargetId = null;
let activeDayFilter = 'all';

/**
 * Main itinerary renderer: toggles between View 1 (Budget Selector) and View 2 (Confirmed Workspace)
 */
function renderItineraryList() {
  const selectorView = document.getElementById('budget-selector-view');
  const confirmedView = document.getElementById('budget-confirmed-view');
  if (!selectorView || !confirmedView) return;

  if (appState.hasConfirmedBudget) {
    selectorView.style.display = 'none';
    confirmedView.style.display = 'block';
    renderItineraryWorkspace();
  } else {
    selectorView.style.display = 'block';
    confirmedView.style.display = 'none';
    syncBudgetInputsFromState();
  }
}

/**
 * Synchronizes inputs and UI elements from current appState.trip
 */
function syncBudgetInputsFromState() {
  const minVal = appState.trip.budgetMin || 1500;
  const maxVal = appState.trip.budgetMax || 3500;
  const daysVal = appState.trip.days || 2;

  const sliderMin = document.getElementById('budget-slider-min');
  const sliderMax = document.getElementById('budget-slider-max');
  const numMin = document.getElementById('budget-num-min');
  const numMax = document.getElementById('budget-num-max');
  const daysInput = document.getElementById('budget-trip-days');

  if (sliderMin) sliderMin.value = minVal;
  if (sliderMax) sliderMax.value = maxVal;
  if (numMin) numMin.value = minVal;
  if (numMax) numMax.value = maxVal;
  if (daysInput) daysInput.value = daysVal;

  updateBudgetCalculations(minVal, maxVal, daysVal);
  updateSliderTrackHighlight(minVal, maxVal);
  highlightMatchingPreset(minVal, maxVal);
}

/**
 * Updates the highlight bar on the dual-range track
 */
function updateSliderTrackHighlight(minVal, maxVal) {
  const highlightBar = document.getElementById('budget-highlight-track');
  if (!highlightBar) return;

  const totalRange = BUDGET_SLIDER_CONFIG.MAX_ALLOWED - BUDGET_SLIDER_CONFIG.MIN_ALLOWED;
  const leftPct = Math.max(0, Math.min(100, ((minVal - BUDGET_SLIDER_CONFIG.MIN_ALLOWED) / totalRange) * 100));
  const widthPct = Math.max(0, Math.min(100 - leftPct, ((maxVal - minVal) / totalRange) * 100));

  highlightBar.style.left = `${leftPct.toFixed(2)}%`;
  highlightBar.style.width = `${widthPct.toFixed(2)}%`;
}

/**
 * Calculates live daily allowance and projected category allocations
 */
function updateBudgetCalculations(minVal, maxVal, days) {
  const safeDays = Math.max(1, parseInt(days, 10) || 1);
  const minDaily = Math.round(minVal / safeDays);
  const maxDaily = Math.round(maxVal / safeDays);

  const dailyEl = document.getElementById('budget-calc-daily');
  const maxEl = document.getElementById('budget-calc-max');
  const lodgingEl = document.getElementById('alloc-lodging');
  const foodEl = document.getElementById('alloc-food');
  const transpoEl = document.getElementById('alloc-transpo');
  const activitiesEl = document.getElementById('alloc-activities');
  const otherEl = document.getElementById('alloc-other');

  if (dailyEl) dailyEl.textContent = `₱${formatNumber(minDaily)} – ₱${formatNumber(maxDaily)} / day`;
  if (maxEl) maxEl.textContent = formatNumber(maxVal);

  if (lodgingEl) lodgingEl.textContent = `₱${formatNumber(Math.round(maxVal * 0.40))}`;
  if (foodEl) foodEl.textContent = `₱${formatNumber(Math.round(maxVal * 0.25))}`;
  if (transpoEl) transpoEl.textContent = `₱${formatNumber(Math.round(maxVal * 0.15))}`;
  if (activitiesEl) activitiesEl.textContent = `₱${formatNumber(Math.round(maxVal * 0.10))}`;
  if (otherEl) otherEl.textContent = `₱${formatNumber(Math.round(maxVal * 0.10))}`;
}

/**
 * Highlights a preset button if current values match
 */
function highlightMatchingPreset(minVal, maxVal) {
  const presetBtns = document.querySelectorAll('#budget-preset-buttons .btn-preset');
  presetBtns.forEach(btn => {
    const pMin = parseInt(btn.getAttribute('data-min'), 10);
    const pMax = parseInt(btn.getAttribute('data-max'), 10);
    if (pMin === minVal && pMax === maxVal) {
      btn.classList.add('active');
    } else {
      btn.classList.remove('active');
    }
  });
}

/**
 * Renders the confirmed workspace: Live budget tracker meter, day tabs, and stops timeline
 */
function renderItineraryWorkspace() {
  const trip = appState.trip;
  const days = trip.days || 2;
  const minBudget = trip.budgetMin || 1500;
  const maxBudget = trip.budgetMax || 3500;
  const stops = appState.itinerary || [];

  // 1. Top Badges & Trip Title
  const tripTitleEl = document.getElementById('confirmed-trip-title');
  const budgetDisplay = document.getElementById('confirmed-budget-display');
  const daysDisplay = document.getElementById('confirmed-days-display');

  if (tripTitleEl) tripTitleEl.textContent = `${trip.city || 'Baguio City'} · ${days} Day${days > 1 ? 's' : ''}`;
  if (budgetDisplay) budgetDisplay.textContent = `₱${formatNumber(minBudget)} – ₱${formatNumber(maxBudget)}`;
  if (daysDisplay) daysDisplay.textContent = `${days} Day${days > 1 ? 's' : ''}`;

  // 2. Budget Utilization Calculations
  const stopsFees = stops.reduce((sum, s) => {
    const d = sampleDestinations.find(dest => dest.id === s.destinationId);
    return sum + (d ? Number(d.fee) || 0 : (Number(s.fee) || 0));
  }, 0);

  const baseLivingCost = Math.round(maxBudget * 0.80);
  const totalPlannedSpent = baseLivingCost + stopsFees;
  const remainingBudget = maxBudget - totalPlannedSpent;

  // Update Tracker Metrics
  const feesEl = document.getElementById('tracker-stops-fees');
  const countEl = document.getElementById('tracker-stops-count');
  const baseEl = document.getElementById('tracker-base-living');
  const remBox = document.getElementById('tracker-remaining-box');
  const remEl = document.getElementById('tracker-remaining-budget');
  const remStatusEl = document.getElementById('tracker-remaining-status');

  if (feesEl) feesEl.textContent = `₱${formatNumber(stopsFees)}`;
  if (countEl) countEl.textContent = `${stops.length} stop${stops.length === 1 ? '' : 's'} planned`;
  if (baseEl) baseEl.textContent = `₱${formatNumber(baseLivingCost)}`;

  if (remEl) {
    if (remainingBudget >= 0) {
      remEl.textContent = `₱${formatNumber(remainingBudget)}`;
      remEl.style.color = '#10352b';
      if (remBox) {
        remBox.style.background = '#f0fdf4';
        remBox.style.borderColor = '#bbf7d0';
      }
      if (remStatusEl) {
        remStatusEl.textContent = 'Within Budget ✓';
        remStatusEl.style.color = '#15803d';
      }
    } else {
      remEl.textContent = `-₱${formatNumber(Math.abs(remainingBudget))}`;
      remEl.style.color = '#b91c1c';
      if (remBox) {
        remBox.style.background = '#fef2f2';
        remBox.style.borderColor = '#fecaca';
      }
      if (remStatusEl) {
        remStatusEl.textContent = 'Over Ceiling ⚠️';
        remStatusEl.style.color = '#b91c1c';
      }
    }
  }

  // Meter Bar
  const meterPercent = Math.min(100, Math.round((totalPlannedSpent / maxBudget) * 100));
  const meterPercentEl = document.getElementById('tracker-meter-percent');
  const meterCeilingEl = document.getElementById('tracker-meter-ceiling');
  const meterFill = document.getElementById('tracker-meter-fill');
  const alertBanner = document.getElementById('tracker-budget-alert');
  const alertMsg = document.getElementById('tracker-alert-message');

  if (meterPercentEl) meterPercentEl.textContent = `${meterPercent}%`;
  if (meterCeilingEl) meterCeilingEl.textContent = `Max Ceiling: ₱${formatNumber(maxBudget)}`;
  if (meterFill) {
    meterFill.style.width = `${meterPercent}%`;
    meterFill.className = 'meter-fill' + (meterPercent >= 100 ? ' overflow' : (meterPercent >= 85 ? ' warning' : ''));
  }

  if (alertBanner) {
    if (remainingBudget < 0) {
      alertBanner.style.display = 'flex';
      if (alertMsg) {
        alertMsg.textContent = `Planned expenses (₱${formatNumber(totalPlannedSpent)}) exceed your ₱${formatNumber(maxBudget)} ceiling by ₱${formatNumber(Math.abs(remainingBudget))}. Consider swapping paid attractions for free favorites like Burnham Park, Wright Park, or The Mansion!`;
      }
    } else {
      alertBanner.style.display = 'none';
    }
  }

  // 3. Render Day Filter Tabs
  renderDayFilterTabs(days);

  // 4. Render Chronological Day-by-Day Timeline
  renderTimelineDays(days, stops);
}

/**
 * Generates Day Tabs ("All Days", "Day 1", "Day 2"...)
 */
function renderDayFilterTabs(daysCount) {
  const tabsContainer = document.getElementById('itinerary-day-tabs');
  if (!tabsContainer) return;

  let tabsHTML = `<button type="button" class="day-tab-pill ${activeDayFilter === 'all' ? 'active' : ''}" data-day="all">All Days (${daysCount})</button>`;
  for (let i = 1; i <= daysCount; i++) {
    const isActive = activeDayFilter === String(i);
    tabsHTML += `<button type="button" class="day-tab-pill ${isActive ? 'active' : ''}" data-day="${i}">Day ${i}</button>`;
  }

  tabsContainer.innerHTML = tabsHTML;

  tabsContainer.querySelectorAll('.day-tab-pill').forEach(btn => {
    btn.addEventListener('click', () => {
      activeDayFilter = btn.getAttribute('data-day');
      renderItineraryWorkspace();
    });
  });
}
