/**
 * Lakbay | Explore: Leaflet Map
 * Interactive Baguio map with destination pins.
 */
'use strict';

/* ==========================================================================
   INTERACTIVE BAGUIO LEAFLET MAP
   ========================================================================== */
function initOrUpdateBaguioMap() {
  const mapEl = document.getElementById('baguio-map');
  if (!mapEl) return;

  if (typeof L === 'undefined') {
    mapEl.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:center;height:100%;padding:2rem;text-align:center;color:#10352b;background:rgba(255,255,255,0.75);">
        <div>
          <h4 style="margin-bottom:0.4rem;font-weight:800;">📍 Baguio City Tourist Map</h4>
          <p style="font-size:0.9rem;color:#38554d;max-width:420px;margin:0 auto 0.75rem;">
            To view live interactive map tiles, connect to the internet. All 20 Baguio destinations have precise GPS coordinates configured!
          </p>
          <p style="font-size:0.85rem;color:#5f7e75;">
            You can also click "Open in Google Maps" inside any destination details modal.
          </p>
        </div>
      </div>
    `;
    return;
  }

  if (!appState.mapInstance) {
    appState.mapInstance = L.map('baguio-map').setView([16.4124, 120.5937], 13);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; OpenStreetMap contributors'
    }).addTo(appState.mapInstance);
  }

  // Clear existing markers
  appState.mapMarkers.forEach(m => appState.mapInstance.removeLayer(m));
  appState.mapMarkers = [];

  // Plot all 20 destinations
  sampleDestinations.forEach(dest => {
    if (!dest.lat || !dest.lng) return;
    const isPlanned = appState.itinerary.some(s => s.destinationId === dest.id);
    const marker = L.marker([dest.lat, dest.lng]).addTo(appState.mapInstance);

    const popupHtml = `
      <div class="map-popup-wrap">
        <strong class="map-popup-title">${escapeHTML(dest.name)}</strong>
        <span class="map-popup-meta">${escapeHTML(dest.category)} · ${dest.fee === 0 ? 'Free' : '₱' + dest.fee}</span>
        <span class="map-popup-meta">📍 ${escapeHTML(dest.area || dest.location)}</span>
        <button type="button" class="map-popup-btn" onclick="showDetails(${dest.id})">
          ${isPlanned ? 'View Stop Details' : 'View Details'}
        </button>
      </div>
    `;
    marker.bindPopup(popupHtml);
    appState.mapMarkers.push(marker);
  });

  setTimeout(() => {
    if (appState.mapInstance) {
      appState.mapInstance.invalidateSize();
    }
  }, 250);
}
