/**
 * Lakbay | Core: Navigation
 * Sidebar navigation and section (screen) switching.
 */
'use strict';

let tripDialogLastFocusedElement = null;
let tripDialogIsEdit = false;

/* ==========================================================================
   NAVIGATION & SECTION SWITCHING (ANI-12 Left Sidebar Layout)
   ========================================================================== */
function setupNavigation() {
  const navContainer = document.getElementById('main-nav');
  const mobileToggle = document.getElementById('mobile-toggle');

  // Event Delegation for nav-items and data-section buttons
  document.addEventListener('click', (e) => {
    const navBtn = e.target.closest('[data-section]');
    if (navBtn) {
      const section = navBtn.getAttribute('data-section');
      if (section) {
        showSection(section);
      }
    }
  });

  // Mobile toggle
  if (mobileToggle) {
    mobileToggle.addEventListener('click', () => {
      if (navContainer) {
        navContainer.classList.toggle('nav-open');
      }
    });
  }

  // Close mobile nav on resize
  window.addEventListener('resize', () => {
    if (window.innerWidth > 900 && navContainer && navContainer.classList.contains('nav-open')) {
      navContainer.classList.remove('nav-open');
    }
  });

  // Popstate hash change
  window.addEventListener('hashchange', () => {
    const hash = window.location.hash.replace('#', '');
    if (hash) {
      showSection(hash, false);
    }
  });
}

/**
 * Sidebar expand/collapse toggle: full module names when open, icons only
 * when collapsed. The choice persists across reloads.
 */
function setupSidebarCollapse() {
  const toggle = document.getElementById('sidebar-toggle');
  if (!toggle) return;

  const STORAGE_KEY = 'lakbaySidebarCollapsed';
  let collapsed = false;
  try {
    collapsed = localStorage.getItem(STORAGE_KEY) === 'true';
  } catch (error) {
    collapsed = false;
  }

  const applyState = () => {
    document.body.classList.toggle('sidebar-collapsed', collapsed);
    toggle.setAttribute('aria-expanded', String(!collapsed));
    toggle.setAttribute('aria-label', collapsed ? 'Expand sidebar labels' : 'Collapse sidebar labels');
    toggle.title = collapsed ? 'Expand sidebar' : 'Collapse sidebar';
  };

  applyState();

  toggle.addEventListener('click', () => {
    collapsed = !collapsed;
    try {
      localStorage.setItem(STORAGE_KEY, String(collapsed));
    } catch (error) {
      /* Persistence is optional; the toggle still works for this session. */
    }
    applyState();
  });
}

/**
 * Validates a whole-number field in the trip overview popup.
 * Returns the value, or null when the input is not allowed.
 */
function validateTripOverviewNumber(input, label, min, max) {
  if (!input) return min;

  const raw = String(input.value).trim();
  const value = Number(raw);
  const isValid = raw !== '' && Number.isInteger(value) && value >= min && value <= max;

  input.classList.toggle('is-invalid', !isValid);

  if (!isValid) {
    showToast(`${label} must be ${min} or above (maximum ${max}).`, 'danger');
    input.focus();
    return null;
  }

  return value;
}

/**
 * Saves edits made in the trip overview popup and refreshes dependent views.
 * Returns false when validation fails so the popup stays open.
 */
function applyTripOverviewChanges() {
  const dateInput = document.getElementById('trip-details-date');
  const daysInput = document.getElementById('trip-details-days');
  const travelersInput = document.getElementById('trip-details-travelers');

  const days = validateTripOverviewNumber(daysInput, 'Number of days', 1, 30);
  const travelers = validateTripOverviewNumber(travelersInput, 'Travelers', 1, 100);
  if (days === null || travelers === null) return false;

  daysInput.classList.remove('is-invalid');
  travelersInput.classList.remove('is-invalid');

  // Keep each stop on its relative day when the start date or duration changes.
  const relativeDays = appState.itinerary.map(stop => getStopDayIndex(stop.date));

  if (dateInput && dateInput.value) {
    appState.trip.startDate = dateInput.value;
  }

  appState.trip.days = days;
  appState.budget.travelers = travelers;

  appState.itinerary.forEach((stop, index) => {
    const day = Math.min(relativeDays[index] || 1, appState.trip.days || 2);
    stop.date = getDateForDay(day);
  });
  sortItineraryChronologically();

  saveData();
  syncBudgetInputsFromState();
  if (appState.hasConfirmedBudget) {
    activeDayFilter = 'all';
    renderItineraryWorkspace();
  }
  showToast('Trip overview updated.', 'success');
  return true;
}

/**
 * Editable trip overview popup. Opens automatically with the itinerary and
 * can be reopened later from the edit button on the trip summary strip.
 */
function setupTripDetailsDialog() {
  const modal = document.getElementById('trip-details-modal');
  const backdrop = document.getElementById('trip-details-backdrop');
  const closeBtn = document.getElementById('trip-details-close-btn');
  const continueBtn = document.getElementById('trip-details-continue-btn');
  const editBtn = document.getElementById('btn-edit-trip-overview');

  const closeDialog = (saveChanges = false) => {
    // Keep the popup open when the entered values fail validation.
    if (saveChanges && applyTripOverviewChanges() === false) return false;
    if (modal) {
      modal.style.display = 'none';
      modal.setAttribute('aria-hidden', 'true');
      document.body.style.overflow = '';
    }
    if (tripDialogLastFocusedElement && typeof tripDialogLastFocusedElement.focus === 'function') {
      tripDialogLastFocusedElement.focus();
    }
    tripDialogLastFocusedElement = null;
    return true;
  };

  if (backdrop) backdrop.addEventListener('click', () => closeDialog(false));
  if (closeBtn) closeBtn.addEventListener('click', () => closeDialog(false));
  if (continueBtn) {
    continueBtn.addEventListener('click', () => {
      // The first "Continue" lands on the budget step; "Save changes" from
      // the edit flow keeps the user on their current planning view.
      const returnToBudget = !tripDialogIsEdit;
      const saved = closeDialog(true);
      if (saved && returnToBudget) {
        itineraryActiveTab = 'budget';
        renderItineraryList();
      }
    });
  }
  if (editBtn) editBtn.addEventListener('click', () => showTripDetailsDialog(true));

  document.addEventListener('keydown', (e) => {
    if (!modal || modal.style.display === 'none') return;
    if (e.key === 'Escape') {
      closeDialog(false);
    } else if (e.key === 'Tab') {
      trapFocusInDialog(modal, e);
    }
  });
}

function showTripDetailsDialog(isEdit = false) {
  const modal = document.getElementById('trip-details-modal');
  if (!modal) return;

  tripDialogIsEdit = isEdit;

  if (typeof syncTripOverviewFromState === 'function') syncTripOverviewFromState();

  const titleEl = document.getElementById('trip-details-title');
  const continueBtn = document.getElementById('trip-details-continue-btn');
  const closeBtn = document.getElementById('trip-details-close-btn');
  const dateInput = document.getElementById('trip-details-date');

  if (titleEl) titleEl.textContent = isEdit ? 'Edit your trip overview' : 'Your trip at a glance';
  if (continueBtn) continueBtn.textContent = isEdit ? 'Save changes' : 'Continue';
  if (closeBtn) closeBtn.textContent = isEdit ? 'Cancel' : 'Close';

  tripDialogLastFocusedElement = document.activeElement;
  modal.style.display = 'flex';
  modal.setAttribute('aria-hidden', 'false');
  document.body.style.overflow = 'hidden';
  if (dateInput) dateInput.focus();
  else if (continueBtn) continueBtn.focus();
}

function showSection(sectionId, updateHash = true) {
  const validSections = ['home', 'explore', 'itinerary', 'budget', 'summary'];
  const targetId = validSections.includes(sectionId) ? sectionId : 'home';

  // Hide all screens
  document.querySelectorAll('.app-screen').forEach(screen => {
    screen.classList.remove('active');
  });

  // Show target screen
  const targetScreen = document.getElementById(`section-${targetId}`);
  if (targetScreen) {
    targetScreen.classList.add('active');
  }

  // Update active state in sidebar nav items
  document.querySelectorAll('.sidebar .nav-item').forEach(item => {
    item.classList.toggle('active', item.getAttribute('data-section') === targetId);
  });

  appState.currentSection = targetId;

  if (updateHash) {
    history.replaceState(null, '', `#${targetId}`);
  }

  // Close mobile navigation drawer if open
  const navContainer = document.getElementById('main-nav');
  if (navContainer && navContainer.classList.contains('nav-open')) {
    navContainer.classList.remove('nav-open');
  }

  // Section-specific triggers
  if (targetId === 'summary') {
    buildSummary();
  } else if (targetId === 'explore') {
    renderExploreGallery();
  } else if (targetId === 'itinerary') {
    renderItineraryList();
    showTripDetailsDialog();
  }

  // Scroll viewport smoothly to top
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function handleInitialHash() {
  const hash = window.location.hash.replace('#', '');
  if (hash) {
    showSection(hash, false);
  }
}
